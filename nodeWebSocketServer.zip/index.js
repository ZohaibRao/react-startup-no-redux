const WebSocket = require("ws"); // require npm

const wss = new WebSocket.Server({port : 8080}); // server at specific port 

// now we want event listener when new clients get connected to us
// following methods gonna fire up when new clients get connected

const sockets = [];

//wss is websocket server and we hi the emiiter as wss.on
wss.on("connection" , (ws, req) => {
    const ip = req.socket.remoteAddress;
    console.log("welcome at server");
    console.log("new clients connected! ");
    console.log("ip "+ ip.toString() );
    sockets.push(ws);
    console.log(`total connected clients are:  ${sockets.length}`);

    //basically when you will refresh the page this callback function expact to execute
    // ws refers to single connection to server side, 
    //if you have multiple Tabs opened / many users connected at once
    // then many wss.on methods is fired up and many ws obects are opened
    // ws referes to single connection and wss server to actuall server
    
    //ws is a connection to wss server
    ws.on("message", data => {
       
        console.log(`this is the clients data: ${data}`);
        ws.send(data.toUpperCase()); // this is server respone / server sending data to connected clients
    });




    
    
    ws.on("close", () => {
        console.log("client disconnected!");
        sockets.pop();
    });

});
