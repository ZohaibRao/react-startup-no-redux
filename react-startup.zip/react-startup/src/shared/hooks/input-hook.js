import { useCallback, useReducer } from 'react';

const inputReducer = (state, action) => {
    switch (action.type) {
        case 'CHANGE':
            return {
                ...state,
                value: action.val,

            };
        case 'TOUCH': {
            return {
                ...state,
                isTouched: true
            };
        }
        default:
            return state;
    }
};


export const useInput = (initialInputs) => {
    const [inputState, dispatch] = useReducer(inputReducer, {
        value: initialInputs || '',
        //isTouched: false,
        
    });

    const changeHandler = useCallback( (id, value) =>{
        dispatch({
        type:"CHANGE",
        value: value,
        id: id
        })
    }, []);

    return [inputState, changeHandler]

}