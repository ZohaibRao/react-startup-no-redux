import React from 'react';

import MyModal from './MyModal';

import {Button} from 'react-bootstrap'

const ErrorModal = props => {
  return (
    <MyModal
      onCancel={props.onClear}
      header="An Error Occurred!"
      show={!!props.error}
    >
      <p>{props.error}</p>
    </MyModal>
  );
};

export default ErrorModal;
