import React from 'react';
import ReactDOM from 'react-dom';
import { CSSTransition } from 'react-transition-group';

import { Modal,Button } from 'react-bootstrap';

//import './Modal.css';

// const ModalOverlay = props => {
//   const content = (
//     <div className={`modal ${props.className}`} style={props.style}>
//       <header className={`modal__header ${props.headerClass}`}>
//         <h2>{props.header}</h2>
//       </header>
//       <form
//         onSubmit={
//           props.onSubmit ? props.onSubmit : event => event.preventDefault()
//         }
//       >
//         <div className={`modal__content ${props.contentClass}`}>
//           {props.children}
//         </div>
//         <footer className={`modal__footer ${props.footerClass}`}>
//           {props.footer}
//         </footer>
//       </form>
//     </div>
//   );
//   return ReactDOM.createPortal(content, document.getElementById('modal-hook'));
// };

const MyModal = props => {
  //console.log(props.show)
  return (
     
      <Modal show={props.show} onHide={props.onCancel}>
        <Modal.Header >
          <Modal.Title>Encountered an Error!</Modal.Title>
        </Modal.Header>
        <Modal.Body>{props.children}</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={props.onCancel}>
            Close
          </Button>
          <Button variant="primary" onClick={props.onCancel}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
    
  );
};

export default MyModal;
