import React from 'react';
import {
  BrowserRouter as Router,
  Route,
  Redirect,
  Switch
} from 'react-router-dom';

import Users from './user/pages/Users';
import NewPlace from './places/pages/NewPlace';
import UserPlaces from './places/pages/UserPlaces';
import UpdatePlace from './places/pages/UpdatePlace';
import Auth from './user/pages/Auth';
import MainNavigation from './shared/components/Navigation/MainNavigation';
import { AuthContext } from './shared/context/auth-context';
import { useAuth } from './shared/hooks/auth-hook';
import Chat from './components/Chat';
import Join from './components/Join';
import BSImages from './components/bootstrapPractice/BS4.images';
import BSTables from './components/bootstrapPractice/BS4.tables';
import BSjumbotron from './components/bootstrapPractice/BS4.jumbotron';
import BS4Alert from './components/bootstrapPractice/BS4.alerts';
import BS4Badges from './components/bootstrapPractice/badges';
import BSpinner from './components/bootstrapPractice/spinners';
import BSPagination from './components/bootstrapPractice/pagination';
import Buttons from './components/bootstrapPractice/button';
import ListGroup from './components/bootstrapPractice/listGroup';
import Cards from './components/bootstrapPractice/cards';
import DropDown from './components/bootstrapPractice/dropdown';
import BSForms from './components/bootstrapPractice/forms';
import BSCollasp from './components/bootstrapPractice/collasp';
import BSInput from './components/bootstrapPractice/inputs';
import BSCarousal from './components/bootstrapPractice/carousal';
import BSFlex from './components/bootstrapPractice/flex';
import BSGrids from './components/bootstrapPractice/BSGrids';
import BSTemplate from './components/bootstrapPractice/BSTemplate'; 
import CssMain from './components/cssPractice/main'; 
import BSDashboard from './components/bootstrapPractice/Dashboard';
import SimpleMap from './components/bootstrapPractice/googlemap';
import AjaxCall from './components/reactPractice/ajaxAndApiCalls';
import Alerts from './components/reactBootstrapPractice/Alerts'
import Screen1 from './components/reactBootstrapPractice/Screen1'
import ScreenBadges from './components/reactBootstrapPractice/Badge';
import LoadingButton from './components/reactBootstrapPractice/LoadingButton';
import CarousalReact  from './components/reactBootstrapPractice/CarousalReact';
import Loginpage from './mimAdmins/pages/LoginPage';
import LoginPage1 from './mimAdmins/pages/LoginPage1';
import Login from './mimAdmins/pages/Login';
import CssPractice from './components/cssPractice/CssPractice';

const App = () => {
  const { token, login, logout, userId } = useAuth();
  const permission = true;

  let routes;

  if (permission) {
    routes = (
      <Switch>
        <Route path="/" exact>
          <Users />
        </Route>
        <Route path="/:userId/places" exact>
          <UserPlaces />
        </Route>
        <Route path="/places/new" exact>
          <NewPlace />
        </Route>
        <Route path="/chat" component={Chat} >
        </Route>
        <Route path="/join" >
          <Join />
        </Route>
        <Route path="/bsimages" >
          <BSImages />
        </Route>
        <Route path="/bstables" >
          <BSTables />
        </Route>
        <Route path="/bsjumbotron" >
          <BSjumbotron />
        </Route>
        <Route path="/bsalerts" >
          <BS4Alert />
        </Route>
        <Route path="/bsbadges" >
          <BS4Badges />
        </Route>
        <Route path="/spinner" >
          <BSpinner />
        </Route>
        <Route path="/pagination" >
          <BSPagination />
        </Route>
        <Route path="/Buttons" >
          <Buttons />
        </Route>
        <Route path="/listGroup" >
          <ListGroup />
        </Route>
        <Route path="/cards" >
          <Cards />
        </Route>
        <Route path="/dropdown" >
          <DropDown />
        </Route>
        <Route path="/collaps" >
          <BSCollasp />
        </Route>
        <Route path="/bsforms" >
          <BSForms />
        </Route>
        <Route path="/bsinputs" >
          <BSInput />
        </Route>
        <Route path="/BSCarousal" >
          <BSCarousal />
        </Route>
        <Route path="/BSFlex" >
          <BSFlex />
        </Route>
        <Route path="/BSGrids" >
          <BSGrids />
        </Route>
        <Route path="/BSTemplate" >
          < BSTemplate />
        </Route>

        <Route path="/CssMain" >
          < CssMain />
        </Route>
        <Route path="/CssPart1" >
          < CssPractice />
        </Route>
        <Route path="/bsdashboard" >
          < BSDashboard />
        </Route>
        <Route path="/simpleMap" >
          < SimpleMap />
        </Route>
        <Route path="/ajaxCall" >
          < AjaxCall />
        </Route>
        <Route path=" ">
          <Alerts />
        </Route>
        <Route path="/Screen1">
        <Screen1 />
        </Route>
        <Route path="/ScreenBadges">
          <ScreenBadges />
        </Route>
        <Route path="/LoadingButton">
          <LoadingButton />
        </Route>
        <Route path="/CarousalReact">
          <CarousalReact />
        </Route>
        <Route path="/loginMIM">
          <Loginpage />
        </Route>
        <Route path="/places/:placeId">
          <UpdatePlace />
        </Route>
        <Route path="/loginPage1">
          <LoginPage1 />
        </ Route >
        <Route path="/login2">
          <Login />
        </Route>
        <Redirect to="/" />
      </Switch>
    );
  } else {
    routes = (
      <Switch>
        <Route path="/" exact>
          <Users />
        </Route>
        <Route path="/:userId/places" exact>
          <UserPlaces />
        </Route>
        <Route path="/auth">
          <Auth />
        </Route>
        <Redirect to="/auth" />
      </Switch>
    );
  }

  return (
    <AuthContext.Provider
      value={{
        isLoggedIn: !!token,
        token: permission,
        userId: userId,
        login: login,
        logout: logout
      }}
    >
      <Router>
        <main>{routes}</main>
      </Router>
    </AuthContext.Provider>
  );
};

export default App;
