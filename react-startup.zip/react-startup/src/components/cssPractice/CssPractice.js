import React from 'react';


import './style.css';

const CssPractice = () => {

    return (

        <>

            <div className="row divHeight"  style={{backgroundImage:`url("https://upload.wikimedia.org/wikipedia/commons/5/5e/Minar_e_Pakistan_night_image.jpg")`}} >
                <div className="col-md-3 " style={{border:'2px solid red'}}>
                    <div className="center">
                        <h3>Hello CSS</h3>
                    </div>
                </div>
                <div className="col-md-9" style={{border:'2px solid red'}}>
                    <div className="center">
                        <h3>Hello CSS</h3>
                    </div>

                </div>

            </div>

        </>

    );

}


export default CssPractice;