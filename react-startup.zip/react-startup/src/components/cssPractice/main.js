import React from 'react';

//import './icon.css';

import './list.css';

const CssMain = () => {
    return <div className="container">
        <h1>Hello from Css Tutorial</h1>
        <i className=" glyphicon glyph"></i>

        <div className="row col-sm-6">
            <h1>links</h1>
            <a href="#" >this is a link</a>
        </div>

        <div className="row" >
            <text> Text decoration</text>
            <a href="#" > This is a link with text decoration</a>
        </div>

        <div className="row-cols-1">

            <p>Mouse over the words to change the cursor.</p>
            <span style={{cursor:"auto"}}>auto</span><br />
            <span style={{cursor:"crosshair"}}>crosshair</span><br />
            <span style={{cursor:"e-resize"}}>e-resize</span><br />
            <span style={{cursor:"help"}}>help</span><br />
            <span style={{cursor:"move"}}>move</span><br />
            <span style={{cursor:"n-resize"}}>n-resize</span><br />
            <span style={{cursor:"ne-resize"}}>ne-resize</span><br />
            <span style={{cursor:"nw-resize"}}>nw-resize</span><br />
            <span style={{cursor:"pointer"}}>pointer</span><br />
            <span style={{cursor:"progress"}}>progress</span><br />
            <span style={{cursor:"s-resize"}}>s-resize</span><br />
            <span style={{cursor:"se-resize"}}>se-resize</span><br />
            <span style={{cursor:"sw-resize"}}>sw-resize</span><br />
            <span style={{cursor:"text"}}>text</span><br />
            <span style={{cursor:"w-resize"}}>w-resize</span><br />
            <span style={{cursor:"wait"}}>wait</span><br />

        </div>

        <div className="row">
            <div className="col-sm-3">
                <ul className="a">
                    <li>apple</li>
                    <li>banana</li>
                    <li>mango</li>
                    <li>mango</li>
                </ul>
            </div>
            <div className="col-sm-3">
                <ul className="b">
                    <li>apple</li>
                    <li>banana</li>
                    <li>mango</li>
                    <li>mango</li>
                </ul>

            </div>
            <div className="col-sm-3">
                <ol className="a">
                    <li>apple</li>
                    <li>banana</li>
                    <li>mango</li>
                    <li>mango</li>
                </ol>
            </div>
            <div className="col-sm-3">
                <ol className="b">
                    <li>apple</li>
                    <li>banana</li>
                    <li>mango</li>
                    <li>mango</li>
                </ol>
                
            </div>
        </div>
    </div>
}

export default CssMain;