import React, {useState, useEffect} from 'react';
import queryS from 'query-string'
import io from 'socket.io-client';

import TextContainer from './TextContainer/TextContainer';
import Messages from './Messages/Messages';
import InfoBar from './InfoBar/InfoBar';
import Input from './Input/Input';
//import '../../node_modules/bootstrap/dist/css/bootstrap.min.css';

let connectedClients; //its a veriable 
let socket;

const Chat = ({location})=>{

    const ENDPOINT = 'localhost:5001';   //where the server is running 
    const [users, setUsers] = useState('');  //to manages the users and send to DB
    const [message, setMessage] = useState(''); // current user messages
    const [messages, setMessages] = useState([]); //array of messages from all participient
    const [room, setRoom] = useState(''); // list of perticular Room
    const [name, setName] = useState(''); //userName
    const [recepientId, setRecepientId] = useState('');
  
    
    useEffect(()=>{
        const {name, room} = queryS.parse(location.search);

        //establish the connection with sockets running at localhost:5000
        socket = io(ENDPOINT);
  
        //now we need to fire an event with the specific name at server listing
        // like we ll emit for 'join'
  
        //we are emitting measns we are sending req to server and we will get response form there
        // it can be error from server side 
        //sending array object at socketIO server

        socket.emit('join', {name:name, room: room}, (error)=>{
              //we can have error from response
              //console.log(room, name);
              alert(JSON.stringify(error));
        });

        
  
        socket.on('broadcast', (data)=>{
              connectedClients = data.description;
              console.log(connectedClients)
          })
          
        socket.on('newclientconnection', (data)=>{
              console.log(data.description);
        })

        

        socket.on('listOfOnlineUsers', (dataList)=>{
            console.log(dataList);
            
        } )
        //socket.on('saveItsRoom')
        return () => {
              socket.emit('dicsonnet');
              socket.off();
        }
  
    },[ENDPOINT, location.search] ); // when ever localhost:address / parameters in URL is changes this useEffect will triggered

    useEffect(() => {

     

        socket.on('message', message => {
          setMessages(messages => [ ...messages, message ]);
          console.log(message);
        });

      socket.on('msg', (data)=>{
        data = 'hello';
      })
        
        socket.on("roomData", ({ users }) => {
          setUsers(users);
        });

        // socket.emit('askForUserId', name, ()=>{

        //   console.log('this is a CB');
        //   //socket.emit(userId);
        // });
        //socket.on('sentMessage')
    }, []);


    const sendMessage = (event) => {
        event.preventDefault();
        //for sending message in one to one you need SocketId of that user
        //socket.emit('checkIfUserExist', "0300");
        // console.log(checkIfUserExist);

        socket.emit('askForUserId', '03007396317'  );
    
        if(message) {
          socket.emit('sentMessage', message, name, () => setMessage(''));
        }

      }

    const sendRecepientId= (event)=>{
      event.preventDefault();
      socket.emit('askForUserId', recepientId, ()=>setRecepientId('') );
      
    }


    return (
        <div >
          <div >
              <InfoBar room={room} />
              <Messages messages={messages} name={name} />
              <Input message={message} setMessage={setMessage} sendMessage={sendMessage} />
          </div>
          <TextContainer users={users}/>
        </div>
      );

}

export default Chat;
