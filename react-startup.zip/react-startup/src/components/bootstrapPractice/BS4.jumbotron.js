import React from 'react';
import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';

const BSjumbotron = () => {
    return <div className="jumbotron-fluid">

        <div className="container backgroundLight">
            <h1>
                This is jumbotron
            </h1>

            <p>here we go..</p>
        </div>

    </div>;
}

export default BSjumbotron;