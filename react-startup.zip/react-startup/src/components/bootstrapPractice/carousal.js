import React, { useEffect } from 'react';


const BSCarousal = () => {

    return <div className="container-fluid">

        <h1 class="mx-auto bg-warning" style={{ width: 200 + "px" }}>Bootstrap Utilities</h1>

        <a href="#" data-toggle="tooltip" title="Hooray!">Hover over me</a>
        <a href="#" data-toggle="tooltip" data-placement="top" title="Hooray!">Hover</a>
        <a href="#" data-toggle="tooltip" data-placement="bottom" title="Hooray!">Hover</a>
        <a href="#" data-toggle="tooltip" data-placement="left" title="Hooray!">Hover</a>
        <a href="#" data-toggle="tooltip" data-placement="right" title="Hooray!">Hover</a>
        <a href="#" data-toggle="popover" title="Popover Header" data-content="Some content inside the popover">Toggle popover</a>
        <div class="toast">
            <div class="toast-header">
                Toast Header
             </div>
            <div class="toast-body">
                Some text inside the toast body
            </div>
        </div>


        <div class="clearfix">
            <span class="float-left">Float left</span>
            <span class="float-right">Float right</span>
        </div>

        


        <h1>responseiveness explained with sm md devices</h1>
        <div class="float-sm-right">Float right on small screens or wider</div><br />
        <div class="float-md-right">Float right on medium screens or wider</div><br />
        <div class="float-lg-right">Float right on large screens or wider</div><br />
        <div class="float-xl-right">Float right on extra large screens or wider</div><br />
        <div class="float-none">Float none</div>

        <div class="mx-auto bg-warning" style={{ width: 150 + "px" }}>Centered</div>

        <div class="w-25 bg-warning">Width 25%</div>
        <div class="w-50 bg-warning">Width 50%</div>
        <div class="w-75 bg-warning">Width 75%</div>
        <div class="w-100 bg-warning">Width 100%</div>
        <div class="mw-100 bg-warning">Max Width 100%</div>

        


<div class="pt-4 bg-warning">I only have a top padding (1.5rem = 24px)</div>
<div class="pt-0 bg-success">I have a padding on all sides (3rem = 48px)</div>
<div class="m-5 pb-5 bg-info">I have a margin on all sides (3rem = 48px) and a bottom padding (3rem = 48px)</div>

<div class="shadow-none p-4 mb-4 bg-light">No shadow</div>
<div class="shadow-sm p-4 mb-4 bg-white">Small shadow</div>
<div class="shadow p-4 mb-4 bg-white">Default shadow</div>
<div class="shadow-lg p-4 mb-4 bg-white">Large shadow</div>


<div className="row">

<span className="border">text</span>
<span className="border border-0">text</span>
<span className="border border-top-0">text</span>
<span className="border border-right-0">text</span>
<span className="border border-bottom-0">text</span>
<span className="border border-left-0">text</span>
</div>

<span className="rounded-sm">maths</span>
<span className="rounded">maths</span>
<span className="rounded-lg">maths</span>
<span className="rounded-top">maths</span>
<span className="rounded-right">maths</span>
<span className="rounded-bottom">maths</span>
<span className="rounded-left">mathds</span>
<span className="rounded-circle"></span>
<span className="rounded-0"></span>

    </div>;

}

export default BSCarousal;