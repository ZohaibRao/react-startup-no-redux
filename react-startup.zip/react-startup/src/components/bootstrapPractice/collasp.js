import React from 'react';
import { useState } from 'react/cjs/react.development';

const BSCollasp = () => {
    const [show, setShow] = useState(true);
    return <div className="container-fluid">
        <div className="container">
            <h1>bootstrap 4 Collapse</h1>
            <button style={show ? { display: "block" } : { display: 'none' }} className={"collapse "} data-toggle="collapse" data-target="#demo">Collapsible</button>

            <div id="demo" className="collapse">
                Lorem ipsum dolor text....
            </div>

        </div>
        <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
            <a class="navbar-brand" href="#">
                <img src="https://lh3.googleusercontent.com/ogw/ADGmqu-9FpgMj-ukrP9vlpaeu4_VW37Z03R6qzshOqEn2A=s83-c-mo" alt="Logo" style={{ width: 40 + 'px' }} />
            </a>
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="#">Link 1</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Link 2</a>
                </li>


                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                        Dropdown link
      </a>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="#">Link 1</a>
                        <a class="dropdown-item" href="#">Link 2</a>
                        <a class="dropdown-item" href="#">Link 3</a>
                    </div>
                </li>
            </ul>
        </nav>

        <div className="row">
            <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
                <form class="form-inline" action="/action_page.php">
                    <input class="form-control mr-sm-2" type="text" placeholder="Search" />
                    <button class="btn btn-success" type="submit">Search</button>
                </form>
            </nav>

        </div>

        <div className="row">
            <nav className="navbar navbar-expand-sm bg-dark navbar-dark">
                <form className="form-inline" action="">
                    <div className="input-group">
                        <div className="input-group-prepend">
                            <span className="input-group-text" style={{width: 2+"px"}}>@</span>
                        </div>
                        <input type="text" className="form-control" placeholder="Username" />
                    </div>
                </form>
            </nav>

        </div>
    </div>

}

export default BSCollasp;