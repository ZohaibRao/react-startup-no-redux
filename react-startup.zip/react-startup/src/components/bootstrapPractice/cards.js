import React from 'react';

const Cards = () => {

    return <div className="container-fluid">
        <div className="row container">
            <div className=" col col-sm">
                <div class="card" style={{ width: 400 + 'px' }}>
                    <img class="card-img-top" src="https://lh3.googleusercontent.com/ogw/ADGmqu-9FpgMj-ukrP9vlpaeu4_VW37Z03R6qzshOqEn2A=s83-c-mo" alt="Card image" />
                    <div class="card-body">
                        <h4 class="card-title">Zohaib Rao</h4>
                        <p class="card-text">Google profile.</p>
                        <a href="#" class="btn btn-primary">See Profile</a>
                        <a href="https://myaccount.google.com/personal-info?gar=1" className="btn btn-primary stretched-link" style={{ marginLeft: 2 + 'px' }} >See Profile</a>
                    </div>
                </div>
            </div>

            <div className="col-sm col">
                <div class="card" style={{ width: 400 + 'px' }}>
                    <div class="card-body">
                        <h4 class="card-title">Zohaib Rao</h4>
                        <p class="card-text">Google profile.</p>
                        <a href="#" class="btn btn-primary">See Profile</a>
                        <a href="https://myaccount.google.com/personal-info?gar=1" className="btn btn-primary stretched-link" style={{ marginLeft: 2 + 'px' }} >See Profile</a>
                    </div>
                    <img class="card-img-top" src="https://lh3.googleusercontent.com/ogw/ADGmqu-9FpgMj-ukrP9vlpaeu4_VW37Z03R6qzshOqEn2A=s83-c-mo" alt="Card image" />

                </div>
            </div>
        </div>
        <div className="row mr-lg-4">
            <div className="col">
                <h1>
                    Bootstrap Cards
                </h1>
                <div class="card">
                    <div class="card-header">Header</div>
                    <div class="card-body">Content</div>
                    <div class="card-footer">Footer</div>
                </div>


            </div>
        </div>
        <div className="row">
            <div className="col">
                <h1> Card Overlay</h1>

                <div class="card" style={{ width: 400 + 'px' }} >

                    <img class="card-img-top" src="https://lh3.googleusercontent.com/ogw/ADGmqu-9FpgMj-ukrP9vlpaeu4_VW37Z03R6qzshOqEn2A=s83-c-mo" alt="Card image" />

                    <div class="card-img-overlay">
                        <h4 class="card-title">John Doe</h4>
                        <p class="card-text">Some example text.</p>
                        <a href="#" class="btn btn-primary">See Profile</a>
                    </div>
                </div>

            </div>
        </div>

        <div className="row">
            <div className="col-sm" >
                <h1>Cards Coloum</h1>
                <div className=" card-columns">
                    <div class="card bg-primary">
                        <div class="card-body text-center">
                            <p class="card-text">Some text inside the first card</p>
                        </div>
                    </div>
                    <div class="card bg-warning">
                        <div class="card-body text-center">
                            <p class="card-text">Some text inside the second card</p>
                        </div>
                    </div>
                    <div class="card bg-success">
                        <div class="card-body text-center">
                            <p class="card-text">Some text inside the third card</p>
                        </div>
                    </div>
                    <div class="card bg-danger">
                        <div class="card-body text-center">
                            <p class="card-text">Some text inside the fourth card</p>
                        </div>
                    </div>
                    <div class="card bg-light">
                        <div class="card-body text-center">
                            <p class="card-text">Some text inside the fifth card</p>
                        </div>
                    </div>
                    <div class="card bg-info">
                        <div class="card-body text-center">
                            <p class="card-text">Some text inside the sixth card</p>
                        </div>
                    </div>

                </div>
            </div>

        </div>
        <div className="container ">
            <h1>Card Group Deck</h1>

            <div class="card-group">
                <div class="card bg-primary mr-1">
                    <div class="card-body text-center">
                        <p class="card-text">Some text inside the first card</p>
                    </div>
                </div>
                <div class="card bg-warning mr-1">
                    <div class="card-body text-center">
                        <p class="card-text">Some text inside the second card</p>
                    </div>
                </div>
                <div class="card bg-success mr-1">
                    <div class="card-body text-center">
                        <p class="card-text">Some text inside the third card</p>
                    </div>
                </div>
                <div class="card bg-danger mr-1">
                    <div class="card-body text-center">
                        <p class="card-text">Some text inside the fourth card</p>
                    </div>
                </div>
            </div>

        </div>
    </div>
}

export default Cards;