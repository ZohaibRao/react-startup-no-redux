
import React from 'react';
import {
    Card,
    Button,
} from 'react-bootstrap';


const BSPagination = () => {
    return (
        <>

            <nav class="navbar navbar-light navbar-expand-md fixed-top gradient portfolio-navbar">
                <div class="container-fluid"><a class="navbar-brand logo" href="#">Brand</a><button data-toggle="collapse" data-target="#navcol-1" class="navbar-toggler"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse p-2 justify-content-end" id="navcol-1">
                        <ul class="navbar-nav ">
                            <li class="nav-item"><a class="nav-link active" href="#">First Item</a></li>
                            <li class="nav-item"><a class="nav-link" href="#">Second Item</a></li>
                            <li class="nav-item"><a class="nav-link" href="#">Third Item</a></li>
                        </ul>
                    </div>
                </div>
            </nav>
            <main className="page landing-page">
                <section className="portfolio-block block-intro" >
                    <div className="container">
                        <img className='avatar' src='https://upload.wikimedia.org/wikipedia/commons/5/5e/Minar_e_Pakistan_night_image.jpg' />
                    </div>
                    <div className="about-me">
                        <p>
                            Hello <strong>Zohaib Nasir </strong>
                            Is it already dark there? It is already dark here. There are a large number of stars in the sky. The rising sun always brightens my morning. The cool soothing breeze in the evening cools my thoughts. I want you to know that you are the most important thing in my life. You're the reason I do everything.
                        </p>
                        <a className=" btn btn-outline-primary" role="button" >Hire Me</a>
                    </div>
                </section>
                <section className="portfolio-block photography">
                    <div className="container">
                        <div className="row no-gutters">

                            <div className=" col-md-6 col-lg-4 zoom-on-hover item">
                                <a>
                                    <img className=' img-fluid image' src="https://mvslim.com/wp-content/uploads/2017/08/the-shah-faisal-mosque-islamabad-80985.jpg" />
                                </a>
                            </div>
                            <div className=" col-md-6 col-lg-4 zoom-on-hover item">
                                <a>
                                    <img className=' img-fluid image' src="https://i.pinimg.com/originals/a4/8e/49/a48e49ef3888b9894195fc4967f0c7dd.jpg" />
                                </a>
                            </div>
                            <div className=" col-md-6 col-lg-4 zoom-on-hover item">
                                <a>
                                    <img className=' img-fluid image' src="https://i.pinimg.com/originals/95/88/43/958843182e0c4350d5a5a107b164d191.jpg" />
                                </a>
                            </div>

                        </div>

                    </div>
                </section>
                <section className="portfolio-block call-to-action border-bottom">

                    <div className="container">
                        <div className=" d-flex justify-content-center align-items-center">
                            <h3>Like what you see!</h3>
                            <button className="btn btn-outline-primary btn-lg" type="button" style={{ marginLeft: 30 + 'px' }} >Hire me</button>
                        </div>

                    </div>

                </section>
                <section className="portfolio-block">
                    <div className="container bg-white">
                        <div className="align-items-center">
                            <h2 className=' text-center'>Speacial skills</h2>
                        </div>
                        <div className="row">
                            <div className=" col-md-4">
                                <Card className="special-skill-item border-0" style={{ width: '18rem' }}>
                                    <Card.Header>
                                        <i className=""></i>
                                    </Card.Header>
                                    <Card.Img variant="top" src="holder.js/100px180" />
                                    <Card.Body>
                                        <Card.Title>Card Title</Card.Title>
                                        <Card.Text>
                                            Some quick example text to build on the card title and make up the bulk of
                                            the card's content.
                                        </Card.Text>
                                        <Button variant="primary">Go somewhere</Button>
                                    </Card.Body>
                                </Card>
                            </div>
                            <div className=" col-md-4">
                                <Card className="special-skill-item border-0" style={{ width: '18rem' }}>
                                    <Card.Header>
                                        <i className=""></i>
                                    </Card.Header>
                                    <Card.Img variant="top" src="holder.js/100px180" />
                                    <Card.Body>
                                        <Card.Title>Card Title</Card.Title>
                                        <Card.Text>
                                            Some quick example text to build on the card title and make up the bulk of
                                            the card's content.
                                        </Card.Text>
                                        <Button variant="primary">Go somewhere</Button>
                                    </Card.Body>
                                </Card>
                            </div>
                            <div className=" col-md-4">
                                <Card className="special-skill-item border-0" style={{ width: '18rem' }}>
                                    <Card.Header>
                                        <i className=""></i>
                                    </Card.Header>
                                    <Card.Img variant="top" src="holder.js/100px180" />
                                    <Card.Body>
                                        <Card.Title>Card Title</Card.Title>
                                        <Card.Text>
                                            Some quick example text to build on the card title and make up the bulk of
                                            the card's content.
                                        </Card.Text>
                                        <Button variant="primary">Go somewhere</Button>
                                    </Card.Body>
                                </Card>
                            </div>

                        </div>

                    </div>
                </section>

                <section class="portfolio-block website gradient">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-md-12 col-lg-5 offset-lg-1 text">
                                <h3>Website Project</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean eget velit ultricies, feugiat est sed, efr nunc, vivamus vel accumsan dui. Quisque ac dolor cursus, volutpat nisl vel, porttitor eros.</p>
                            </div>
                            <div class="col-md-12 col-lg-5">
                                <div class="portfolio-laptop-mockup">
                                    <div class="screen">
                                        <div class="screen-content ">
                                            <img className=" image-fluid image" src="https://upload.wikimedia.org/wikipedia/commons/5/5e/Minar_e_Pakistan_night_image.jpg" style={{ width: 100 + "%" }} />
                                        </div>
                                    </div>
                                    <div class="keyboard"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <footer className="page-footer">
                    <div class="container">
                        <div class="links"><a href="#">About me</a><a href="#">Contact me</a><a href="#">Projects</a></div>
                        <i class="fab fa-bootstrap"></i>
                        
                    </div>
                </footer>



            </main>

        </>
    );

}

export default BSPagination;