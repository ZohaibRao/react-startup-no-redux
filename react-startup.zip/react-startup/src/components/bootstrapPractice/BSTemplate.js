import React from 'react';

import './style.css'

const BSTemplate = () => {
    return <React.Fragment>
        <div className="jumbotron jumbotron-fluid text-center bgk" style={{ marginBottom: 0 + "px" }}>
            <h1>Bootstrap</h1>
            <p>Here we go</p>
        </div>
        <div className="navbar navbar-expand-sm bg-dark navbar-dark" >

            <a class="navbar-brand" href="#">Navbar</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                <span className=" navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="collapsibleNavbar">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="#">Link</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Link</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Link</a>
                    </li>
                </ul>
            </div>
        </div>
        <div className="container" style={{ marginTop: 30 + 'px' }}>

            <div className="row">
                <div className="col-sm-4">
                    <h1>About Me</h1>
                    <h5>Photo of Me</h5>
                    <div className="image">
                        <img src="https://lh3.googleusercontent.com/ogw/ADGmqu-9FpgMj-ukrP9vlpaeu4_VW37Z03R6qzshOqEn2A=s83-c-mo" height="300px" width="100%" />
                    </div>
                    <p>Some text about me in culpa qui officia deserunt mollit anim..</p>
                    <h3>Some Links</h3>
                    <p>Lorem ipsum dolor sit ame.</p>
                    <ul class="nav nav-pills flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="#">Active</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Link</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Link</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link disabled" href="#">Disabled</a>
                        </li>
                    </ul>
                    <hr class="d-sm-none"></hr>
                </div>

                <div className="col-sm-8">
                    <h1>Title Heading</h1>
                    <h5>Title Description, April, 6, 2021</h5>
                    <div className="image">
                        <img src = "https://www.almanac.com/sites/default/files/image_nodes/earth-tree.jpg" height="300px" width="100%" />
                    </div>
                    <p>some Text</p>
                    <p>kind of big text a quick brown fox jumps over the lazy dog.</p>

                    <h1>Title Heading 2</h1>
                    <h5>Title Description, April, 6, 2021 2</h5>
                    <div className="image">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/97/The_Earth_seen_from_Apollo_17.jpg/1200px-The_Earth_seen_from_Apollo_17.jpg" height="300px"  width="100%"/>
                    </div>
                    <p>some Text 2</p>
                    <p>kind of big text a quick brown fox jumps over the lazy dog. 2</p>

                </div>

            
            </div>
        </div>

        <div className="jumbotron text-center" style={{ marginTop: 10 + "px" }}>
            <h1>This is footer</h1>
            <p>Here we go</p>
            </div>
    </React.Fragment>;
}

export default BSTemplate;