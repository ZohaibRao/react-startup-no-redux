import React, { useState } from 'react';
import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';

const BS4Badges = () => {

    const [click, setClick] = useState(false);

    const onClickHandler = ()=>{
        setClick(true);
    }


    return <div className="container-fluid">
        <div className="row">

            <div className='col-4 col-sm-3'>
            <h1>Example heading <span className="badge badge-secondary">New</span></h1>
            <h2>Example heading <span className="badge badge-secondary">New</span></h2>
        

            </div>
            <div className='col-4 col-sm-3'>
            <h3>Example heading <span className="badge badge-secondary">New</span></h3>
            <h4>Example heading <span className="badge badge-secondary">New</span></h4>
        

            </div>
            <div className='col-4 col-sm-3'>
                <h5>Example heading <span className="badge badge-secondary">New</span></h5>
                    <h6>Example heading <span className="badge badge-secondary">New</span></h6>
        
        

            </div>
                </div>

            <div className="row">
            <span className="badge badge-primary font-weight-bold">Primary</span>
            <span className="badge badge-secondary">Secondary</span>
            <span className="badge badge-success">Success</span>
            <span className="badge badge-danger">Danger</span>
            <span className="badge badge-warning">Warning</span>
            <span className="badge badge-info">Info</span>
            <span className="badge badge-light">Light</span>
            <span className="badge badge-dark">Dark</span>

            </div>
            <button type="button" class="btn btn-primary mr-auto">
            Messages <span class="badge badge-light">4</span>
            </button>

            <div className="progress">
            <div className="progress-bar bg-light" bsStyle="width:30%"></div>
            </div>

            <div className="progress colorDark " styles="height:20px">
            <div className="progress-bar" styles="width:40%;height:20px"></div>
            </div>
            <br />
            
            <div className="progress">
            <div className="progress-bar bg-success" styleName="width:20%"></div>
            </div>

            <div>
                <input type="input" value="You name"  type="text"
                label="Title" />
                <div>
                <button className="btn btn-primary btn-lg " disabled  onClick={onClickHandler} >Submit</button>
                </div>
                
                { click &&  <div className="alert alert-success" >
            <strong>Success!</strong> your application has been submitted.
            </div>
              }
              </div>

              
            <div class="alert alert-success alert-dismissible">
                <button type="button" className="close" data-dismiss="alert">&times;</button>
                <strong>Success!</strong> Indicates a successful or positive action.
            </div>
            <div class="alert alert-danger alert-dismissible fade show">hello</div>
            

            
    </div>;

}

export default BS4Badges;