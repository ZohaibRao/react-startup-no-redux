//import { Dropdown } from 'bootstrap';
import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import React from 'react';
import Dropdown from '../../../node_modules/react';
import { Button, Collapse } from 'mdbreact';
import { MDBBox } from 'mdbreact';
import { MDBContainer, MDBRow, MDBCol } from 'mdb-react-ui-kit';

const DropDown = () => {

    return  <MDBContainer>
    <MDBRow>
      <MDBCol size='md' className='col-example'>
        One of three columns
      </MDBCol>
      <MDBCol size='md' className='col-example'>
        One of three columns
      </MDBCol>
      <MDBCol size='md' className='col-example'>
        One of three columns
      </MDBCol>
    </MDBRow>
  </MDBContainer>
}

export default DropDown;


{/* <div className="container">
            <h1>DropDown</h1>
            
            <p>A dropdown menu is a toggleable menu that allows the user to choose one value from a predefined list</p>

            <div className='row col-2'>
                <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                    Dropdown button
                 </button>
                <div class="dropdown-menu">
                <div class="dropdown-header">Dropdown header 1</div>
                    <a class="dropdown-item" href="#">Link 1</a>
                    <a class="dropdown-item" href="#">Link 2</a>
                    <a class="dropdown-item" href="#">Link 3</a>
                </div>
               
            </div>
         
        </div> */}