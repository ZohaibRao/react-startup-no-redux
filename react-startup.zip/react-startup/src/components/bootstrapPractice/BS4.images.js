import React from 'react';
import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';

const BSImages = () => {
    return <div className="container" >
        <div className="row">
            <img src="https://upload.wikimedia.org/wikipedia/commons/5/5e/Minar_e_Pakistan_night_image.jpg" className="rounded" height="300" width="300" />
            <img src="https://upload.wikimedia.org/wikipedia/commons/5/5e/Minar_e_Pakistan_night_image.jpg" className="rounded-circle" height="300" width="300" />
        </div>

        <div className="row">
            <div className="col-4">
                <h1 className="backgroundLight">class1</h1>
                <div>
                <img src="https://upload.wikimedia.org/wikipedia/commons/5/5e/Minar_e_Pakistan_night_image.jpg" className="rounded" height="300" width="300" />
                </div>
            </div>
            <div className="col-2">
                <h1 className="backgroundBlue">class2</h1>
                <div>
                <img src="https://upload.wikimedia.org/wikipedia/commons/5/5e/Minar_e_Pakistan_night_image.jpg" className="rounded p-5" height="300" width="300" />
                </div>
            </div>
            <div className="col-6">
                <h1 className="backgroundBlue">class2</h1>
                <div>
                <img src="https://upload.wikimedia.org/wikipedia/commons/5/5e/Minar_e_Pakistan_night_image.jpg" className="rounded " height="300" width="300" />
                </div>
            </div>

        </div>

        <div className="row">
            <h1>Head1</h1>

        </div>

    </div>;
}

export default BSImages;