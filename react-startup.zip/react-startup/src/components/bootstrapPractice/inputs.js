import React from 'react';

const BSInput = () => {
    return <div className="container-fluid">
        <h1>Bootstrap Inputs</h1>
        <ul>
            <li>
                input
            </li>
            <li>
                textarea
            </li>
            <li>
                checkbox
            </li>
            <li>
                radio
            </li>
            <li>
                select
            </li>
        </ul>

        <h1>basic inputs</h1>
        <div className="row">

            <div class="form-group">
                <label for="usr">Name:</label>
                <input type="text" class="form-control" id="usr" />
            </div>
            <div class="form-group">
                <label for="pwd">Password:</label>
                <input type="password" class="form-control" id="pwd" />
            </div>
            <div class="form-group">
                <label for="comment">Comment:</label>
                <textarea class="form-control" rows="5" id="comment"></textarea>
            </div>
        </div>

        <div className="row">
            <h1> Bootstrap vertical checkboxes</h1>
            <div className="col" >
                <div class="form-check">
                    <label class="form-check-label">
                        <input type="checkbox" class="form-check-input" value="" />Option 1
                    </label>
                </div>
                <div class="form-check">
                    <label class="form-check-label">
                        <input type="checkbox" class="form-check-input" value="" />Option 2
                </label>
                </div>
                <div class="form-check">
                    <label class="form-check-label">
                        <input type="checkbox" class="form-check-input" value="" disabled />Option 3
                </label>
                </div>
            </div>

        </div>

        <div className="row">
            <h1> Bootstrap inline checkboxes</h1>
            <div className="col" >
                <div class="form-check-inline">
                    <label class="form-check-label">
                        <input type="checkbox" class="form-check-input" value="" />Option 1
                    </label>
                </div>
                <div class="form-check-inline">
                    <label class="form-check-label">
                        <input type="checkbox" class="form-check-input" value="" />Option 2
                </label>
                </div>
                <div class="form-check-inline">
                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" value="" />Option 3
                </label>
                </div>
            </div>

        </div>
        <div className="row">
            <h1> Bootstrap select list</h1>
            <div class="form-group">
                <label for="sel1">Select list:</label>
                <select class="form-control" id="sel1">
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                </select>
            </div>
            <input type="text" class="form-control form-control-sm" />
            <input type="text" class="form-control form-control" />
            <input type="text" class="form-control form-control-lg" />

            <div>
                <h1>Form Control File and Range</h1>
                <input type="range" class="form-control-range" />
                <input type="file" class="form-control-file border"></input>
            </div>


        </div>

        <div className="row">
            <h1>Bootstrap 4 Input Groups</h1>
            <p>The .input-group class is a container to enhance an input by adding an ic1on, text or a button in front or behind the input field as a "help text".</p>

            <div className="col">
                <form>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text input-group-text">@</span>
                        </div>
                        <input type="text" class="form-control" placeholder="Username" />
                    </div>

                    <div class="input-group mb-3">
                        <input type="text" class="form-control" placeholder="Your Email" />
                        <div class="input-group-append">
                            <span class="input-group-text">@example.com</span>
                        </div>
                    </div>
                </form>

            </div>

        </div>



    </div>
}

export default BSInput;