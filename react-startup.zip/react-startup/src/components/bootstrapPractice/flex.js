import React from 'react';

const BSFlex = () => {

    return <div className="container-fluid">

        <div className="flex-container">
            <div>1</div>
            <div>2</div>
            <div>3</div>
        </div>

        <p>To create a flexbox container and to transform direct children into flex items, use the d-flex class:</p>
        <div class="d-flex p-3 bg-secondary  text-white">
            <div class="p-2 bg-info">Flex item 1</div>
            <div class="p-2 bg-warning">Flex item 2</div>
            <div class="p-2 bg-primary">Flex item 3</div>
        </div>

        <p>To create an inline flexbox container, use the d-inline-flex class:</p>
        <div class="d-inline-flex p-3 bg-secondary text-white">
            <div class="p-2 bg-info">Flex item 1</div>
            <div class="p-2 bg-warning">Flex item 2</div>
            <div class="p-2 bg-primary">Flex item 3</div>
        </div>

        <h1>Media object</h1>
        <div class="media border p-3">
            <img src="https://lh3.googleusercontent.com/ogw/ADGmqu-9FpgMj-ukrP9vlpaeu4_VW37Z03R6qzshOqEn2A=s83-c-mo" alt="John Doe" class="mr-3 mt-3 rounded-circle" style={{ width: 60 + 'px' }} />
            <div class="media-body">
                <h4>John Doe <small><i>Posted on February 19, 2016</i></small></h4>
                <p>Lorem ipsum...</p>
            </div>
        </div>

        <div className="flex-container">
            <h1 style={{ backgroundColor: 'blue' }} >Hellob</h1>
            <h1 style={{ backgroundColor: 'red' }} >Hellob</h1>
            <h1 style={{ backgroundColor: 'orange' }} >Hellob</h1>
        </div>


        <h1>The flex-wrap Property</h1>

        <p>The "flex-wrap: wrap;" specifies that the flex items will wrap if necessary:</p>

        <div className="flex-container">
            <div>1</div>
            <div>2</div>
            <div>3</div>
            <div>4</div>
            <div>5</div>
            <div>6</div>
            <div>7</div>
            <div>8</div>
            <div>9</div>
            <div>10</div>
            <div>11</div>
            <div>12</div>
        </div>

        <p>Try resizing the browser window.</p>


        <div className="flex-container " style={{ justifyContent: 'space-around' }} >

            <p>Hello World</p>

        </div>


        <div class="flex-container">
            <div style={{ order: 4 }}>1</div>
            <div style={{ order: 3 }}>2</div>
            <div style={{ order: 2 }}>3</div>
            <div style={{ order: 1 }}>4</div>
        </div>


        <div className="row">
            <div class="col-sm">1 of 2</div>
            <div class="col-sm bgk">2 of 2</div>

        </div>

        <div className="row">
            <div class="col-sm bgk">1 of 4</div>
            <div class="col-sm">2 of 4</div>
            <div class="col-sm bgk">3 of 4</div>
            <div class="col-sm">4 of 4</div>

        </div>

        <div class="container-fluid">
            <div class="row stack">
                <div class="col-3 bg-success">
                    <p>other than col-sm to stack the items</p>
                </div>
                <div class="col-9 bg-warning">
                    <p>Sed ut perspiciatis...</p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-8">
                .col-8 nested
            <div class="row">
                    <div class="col-6">.col-6</div>
                    <div class="col-6">.col-6</div>
                </div>
            </div>
            <div class="col-4">.col-4</div>
        </div>



    </div>
}

export default BSFlex;