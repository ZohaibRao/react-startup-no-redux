import React from 'react';

import './style.css';

const BSGrids = () =>{
    return <div className="container-fluid" >
        <div className="row">
            <div className="col-sm-4">
            <p>letsee</p>
            </div>
            <div className="col-sm-4" >
            <h1 style={{backgroundColor:'red'}}>Rules of Grid system</h1>
            </div>
            
           
            
        </div>

        <div className="flex-container">
            <h1 style={{backgroundColor:'blue'}} >Hellob</h1>
            <h1 style={{backgroundColor:'red'}} >Hellob</h1>
            <h1 style={{backgroundColor:'orange'}} >Hellob</h1>
        </div>
        
    </div>;
}

export default BSGrids;