import React from 'react';


const ListGroup = () => {
    return <div className="container-fluid"  style={{ marginLeft: 2 + '% ' }} >
        <div className="row">


            <div className="col-sm ">
                <ul class="list-group">
                    <li class="list-group-item">First item</li>
                    <li class="list-group-item">Second item</li>
                    <li class="list-group-item">Third item</li>
                </ul>

            </div>



            <div className="col-sm ">
                <h1>Actice state</h1>
                <ul class="list-group">
                    <li class="list-group-item active">Active item</li>
                    <li class="list-group-item">Second item</li>
                    <li class="list-group-item">Third item</li>
                </ul>
            </div>




            <div className="col-sm ">
                <h1>List Group With Linked Items</h1>
                <div class="list-group">
                    <a href="#" class="list-group-item list-group-item-action">First item</a>
                    <a href="#" class="list-group-item list-group-item-action">Second item</a>
                    <a href="#" class="list-group-item list-group-item-action">Third item</a>
                </div>
            </div>

            <div className="col-sm">
                <h1>Disabled Items</h1>
                <div class="list-group">
                    <a href="#" class="list-group-item list-group-item-action">First item</a>
                    <a href="#" class="list-group-item list-group-item-action">Second item</a>
                    <a href="#" class="list-group-item list-group-item-action">Third item</a>
                </div>
            </div>

        </div>

        <div className="row" style={{ marginLeft: 2 + '% ' }}>
            <div className="col-6 col-sm">
                <h1>Flush / Remove Borders</h1>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">First item</li>
                    <li class="list-group-item">Second item</li>
                    <li class="list-group-item">Third item</li>
                    <li class="list-group-item">Fourth item</li>
                </ul>
            </div>

            <div className="col-6 col-sm">
                <h1>Horizontal list groups</h1>
                <ul class="list-group list-group-horizontal">
                    <li class="list-group-item">First item</li>
                    <li class="list-group-item">Second item</li>
                    <li class="list-group-item">Third item</li>
                    <li class="list-group-item">Fourth item</li>
                </ul>
            </div>
        </div>

        <div className="row mr-lg-4" >
            <div className="col">
            <h1>Contextual classess</h1>
            <ul class="list-group">
            <li class="list-group-item list-group-item-success">Success item</li>
            <li class="list-group-item list-group-item-secondary">Secondary item</li>
            <li class="list-group-item list-group-item-info">Info item</li>
            <li class="list-group-item list-group-item-warning">Warning item</li>
            <li class="list-group-item list-group-item-danger">Danger item</li>
            <li class="list-group-item list-group-item-primary">Primary item</li>
            <li class="list-group-item list-group-item-dark">Dark item</li>
            <li class="list-group-item list-group-item-light">Light item</li>
            </ul>

            </div>
            

        </div>

        <div className="row">
            <div className="col-10 mr-lg-4">
                <h1>List Group with badges</h1>
                <ul class="list-group">
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Inbox
                    <span class="badge badge-primary badge-pill">12</span>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Ads
                    <span class="badge badge-primary badge-pill">50</span>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Junk
                    <span class="badge badge-primary badge-pill">99</span>
                </li>
                </ul>
            </div>
        </div>
        
        


    </div>;
}

export default ListGroup;