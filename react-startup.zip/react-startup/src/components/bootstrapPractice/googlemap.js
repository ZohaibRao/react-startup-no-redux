import React from "react";
import GoogleMapReact from 'google-map-react';
import {
  Row,
  Container
} from 'react-bootstrap';


const AnyReactComponent = ({ text }) => <div>{text}</div>;

const SimpleMap = () => {
  const defaultProps = {
    center: {
      lat: 31.476397525416186,
      lng: 74.30774661233649
    },
    zoom: 10
  };
  return (
    // Important! Always set the container height explicitly
    <div style={{ height: '100vh', width: '100%' }}>
      <GoogleMapReact
        bootstrapURLKeys={{ key: "AIzaSyCH005p0kBP7EqnOccT04sQmg7oR1XEz68", language: "en" }}
        defaultCenter={defaultProps.center}
        defaultZoom={defaultProps.zoom}
      >
        <Container >
          <AnyReactComponent
            lat={31.476397525416186}
            lng={74.30774661233649}
            text="My Marker"
            
          />
        </Container>

      </GoogleMapReact>
    </div>
  );
}

export default SimpleMap;