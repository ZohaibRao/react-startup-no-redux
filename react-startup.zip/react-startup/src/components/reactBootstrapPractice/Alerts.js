import React, { useState } from 'react';
import { Container } from 'react-bootstrap';

import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import {
  Card,
  Button,
  Row,
  Col,
  Media,
  Alert,
} from 'react-bootstrap';

import './style.css';


const Alerts =() =>{
    const [state, setState] = useState(true);

    const setDismissFunction = ()=>{
        setState(true)
    }

    const setDissmissFunctionFalse = ()=>{
        setState(false)
    }
    return <>

  <Alert variant="primary">
    This is a Primay alert—check it out!
  </Alert>
  <Alert variant="danger">
    This is a Primay alert—check it out!
  </Alert>

  <Alert variant="danger">
    This is a Alert with {' '}
    <Alert.Link href="#">
        Click me
    </Alert.Link>
  </Alert>

  <Alert variant="success" className="m-1">
  <Alert.Heading>Hey, nice to see you</Alert.Heading>
  <p>
    Aww yeah, you successfully read this important alert message. This example
    text is going to run a bit longer so that you can see how spacing within an
    alert works with this kind of content.
  </p>
  <hr />
  <p className="mb-0">
    Whenever you need to, be sure to use margin utilities to keep things nice
    and tidy.
  </p>
</Alert>

    {state ? <Alert variant="danger" onClose={setDissmissFunctionFalse} dismissible>
        <Alert.Heading>Oh snap! You got an error!</Alert.Heading>
        <p>
          Change this and that and try again. Duis mollis, est non commodo
          luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit.
          Cras mattis consectetur purus sit amet fermentum.
        </p>
      </Alert> : null }
    

      { !state &&  <Button class="inverse"  onClick = {setDismissFunction}> show alert</Button>}

      {state ? <Alert variant="danger" onClose={setDissmissFunctionFalse} dismissible transition ='Fade'>
        <Alert.Heading>Oh snap! You got an error!</Alert.Heading>
        <p>
          Change this and that and try again. Duis mollis, est non commodo
          luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit.
          Cras mattis consectetur purus sit amet fermentum.
        </p>

        <hr />
        <div className="d-flex justify-content-end">
        { !state &&  <Button className="inverse"  onClick = {setDismissFunction} className="outline-success"> show alert</Button> }
        </div>
        

      </Alert> : null }
    

     

    </>
}


export default Alerts;