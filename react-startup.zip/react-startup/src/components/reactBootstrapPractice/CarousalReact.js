import React from 'react';

import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import {
    Carousel
} from 'react-bootstrap';


const CarousalReact = () => {

    return <>
        <Carousel >
            <Carousel.Item>
                <img
                    className="ustify-content-center"
                    src="https://upload.wikimedia.org/wikipedia/commons/5/5e/Minar_e_Pakistan_night_image.jpg"
                    alt="Minar e Pakistan"
                    
                />

                <Carousel.Caption>
                    <h3>First slide label</h3>
                    <p>Minar e Pakistan a Historic place to visit located in Lahore.</p>
                </Carousel.Caption>
            </Carousel.Item>
            <Carousel.Item>
                <img
                    className=" justify-content-center"
                    src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/01/%27Minar-e-Pakistan%27.jpg/1200px-%27Minar-e-Pakistan%27.jpg"
                    alt="Minar e Pakistan"
                    
                />

                <Carousel.Caption>
                    <h3>First slide label</h3>
                    <p>Minar e Pakistan a Historic place to visit located in Lahore.</p>
                </Carousel.Caption>
            </Carousel.Item>    
        </Carousel>
    </>

}

export default CarousalReact;