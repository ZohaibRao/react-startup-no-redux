import React from 'react';
import { Container } from 'react-bootstrap';

import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import {
    Card,
    Button,
    Row,
    Col,
    Media,
    Badge,
    Breadcrumb,
    Nav
} from 'react-bootstrap';

import './Screen1.css';
import { contains } from 'jquery';


const ScreenBadges = () => {
    return <>

        <h5 >Hello React Bootstrap</h5>
        <div>
            <h6>
                Example Heading <Badge variant="primary" style={{ border: "groove" }}>New</Badge>
            </h6>

            <Button variant="primary">
                Profile <Badge variant="light">9</Badge>
                <span className="sr-only">unread messages</span>
            </Button>
        </div>

        <Breadcrumb >
            <Breadcrumb.Item href="#">Home</Breadcrumb.Item>
            <Breadcrumb.Item href="https://getbootstrap.com/docs/4.0/components/breadcrumb/">
                Library
            </Breadcrumb.Item>
            <Breadcrumb.Item active>Data</Breadcrumb.Item>
        </Breadcrumb>

        <div>
            <Badge variant="primary">Primary</Badge>{' '}
            <Badge variant="secondary">Secondary</Badge>{' '}
            <Badge variant="success">Success</Badge>{' '}
            <Badge variant="danger">Danger</Badge>{' '}
            <Badge variant="warning">Warning</Badge> <Badge variant="info">Info</Badge>{' '}
            <Badge variant="light">Light</Badge> <Badge variant="dark">Dark</Badge>

            <Badge as={Button} variant="primary">
                Primary
            </Badge>{' '}

            <button type="button" size="lg" class="btn btn-primary disabled" >Primary</button>{' '}
            <Button variant="priamy" size="sm" active>Primary</Button>
        </div>
    </>
}


export default ScreenBadges;