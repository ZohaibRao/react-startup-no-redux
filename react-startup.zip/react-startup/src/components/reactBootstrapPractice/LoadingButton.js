import React, { useEffect, useState } from 'react';
import { Container } from 'react-bootstrap';

import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import {
    Card,
    Button,
    Row,
    Col,
    Media,
    Badge,
    Breadcrumb,
    Nav,
    ButtonGroup,
    ButtonToolbar
} from 'react-bootstrap';

import './Screen1.css';
import { contains } from 'jquery';


const LoadingButton = () => {
    const [isLoading, setIsLoading] = useState(false);

    const simulateNetworkRequest = () => {
        return new Promise((resolve) => setTimeout(resolve, 2000));
    }
    useEffect(() => {
        if (isLoading) {
            simulateNetworkRequest().then(() => {
                setIsLoading(false);
            });
        }
    }, [isLoading]);

    const clickHandler = () => {
        setIsLoading(true);
    }
    return <>

        <h5 >Hello is Loading Button state</h5>

        <Button variant="primary" onClick={!isLoading ? clickHandler : null} disabled={isLoading}>

            {isLoading ? 'is Loading..' : 'Click to Load'}
        </Button>

        <div>
            <ButtonGroup aria-label="Basic example">
                <Button variant="secondary">Left</Button>
                <Button variant="secondary">Middle</Button>
                <Button variant="secondary">Right</Button>
            </ButtonGroup>

            <ButtonToolbar aria-label="Toolbar with button groups">
                <ButtonGroup className="mr-2" aria-label="First group">
                    <Button>1</Button> <Button>2</Button> <Button>3</Button> <Button>4</Button>
                </ButtonGroup>
                <ButtonGroup className="mr-2" aria-label="Second group">
                    <Button>5</Button> <Button>6</Button> <Button>7</Button>
                </ButtonGroup>
                <ButtonGroup aria-label="Third group">
                    <Button>8</Button>
                </ButtonGroup>
            </ButtonToolbar>
        </div>
    </>
}


export default LoadingButton;