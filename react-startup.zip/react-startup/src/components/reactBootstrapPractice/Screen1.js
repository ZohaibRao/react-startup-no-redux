import React from 'react';
import { Container } from 'react-bootstrap';

import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import {
    Button,
    Jumbotron
} from 'react-bootstrap';

import './Screen1.css';
import { contains } from 'jquery';


const Screen1 = () => {
    return <>

        <h5 className="nav">Hello React Bootstrap</h5>
        <Jumbotron fluid>
            <h1>Hello, world!</h1>
            <p>
                This is a simple hero unit, a simple jumbotron-style component for calling
                extra attention to featured content or information.
            </p>
            <p>
                <Button variant="primary">Learn more</Button>
            </p>
        </Jumbotron>
    </>
}


export default Screen1;