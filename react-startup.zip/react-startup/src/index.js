import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import 'bootstrap-css-only/css/bootstrap.min.css';

import $ from 'jquery';
import Popper from 'popper.js';

import React from 'react';
import ReactDOM from 'react-dom';

import '../node_modules/@fortawesome/fontawesome-common-types/attribution'
import '@fortawesome/fontawesome-free/css/all.min.css';

import 'mdbreact/dist/css/mdb.css';
import 'mdb-react-ui-kit/dist/css/mdb.min.css'

import './index.css';
import App from './App';

ReactDOM.render(<App />, document.getElementById('root'));
