import React, { useState, useReducer } from 'react';

import Input from '../../shared/components/FormElements/Input';
import { useForm } from '../../shared/hooks/form-hook';
import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';

import {
    Form,
    Button,
    Card
} from 'react-bootstrap';


import './LoginPage.css';

const GroceryRequest = ()=>{

    const [isLoginMode, setIsLoginMode] = useState(false);
    const [reqeustId, setRequestId] =  useState("");

    const [formState, inputHandler, setFormData] = useForm(
        {
          email: {
            value: '',
            isValid: false
          },
          password: {
            value: '',
            isValid: false
          }
        },
        false
      );

    const switchModeHandler = ()=>{
        setIsLoginMode(prevMode => !prevMode);
    }


    const submitHanlder = event =>{
        event.prevetDefault();
        console.log("submitted")
    }

    return <>
        <Card className="authentication">
            <h2>Login</h2>
            <hr />
            <form  onSubmit={submitHanlder}>
                {!isLoginMode && 
                <div class="form-group">
                <label for="exampleInputEmail1" className="float-left" >Name</label>
                <input type="text" class="form-control" id="name" aria-describedby="emailHelp" onChange={inputHandler} />
                </div>
                }
                <div class="form-group">
                    <label for="exampleInputEmail1" class="float-left">Email address</label>
                    <input type="email" class="form-control" id="email" aria-describedby="emailHelp" onChange={inputHandler} />
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1" class="float-left" >Password</label>
                    <input type="password" class="form-control" id="password" onInput={inputHandler} />
                </div>
                <button type="submit" className="btn btn-primary" >Submit</button>
            </form>
            <Button variant="outline-primary" type="submit" onClick={switchModeHandler}>
                SWITCH TO {isLoginMode ? 'SIGNUP' : 'LOGIN'}
            </Button>
        </Card>
    </>
}


export default GroceryRequest;