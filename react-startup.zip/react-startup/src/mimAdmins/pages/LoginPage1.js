import React, { useState, useReducer } from 'react';

import Input from '../../shared/components/FormElements/Input';
import { useForm } from '../../shared/hooks/form-hook';
import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';

import {
    Form,
    Button,
    Card
} from 'react-bootstrap';


import './LoginPage.css';

const LoginPage1 = ()=>{

    const [isLoginMode, setIsLoginMode] = useState(false);

    const [formState, inputHandler, setFormData] = useForm(
        {
          email: {
            value: '',
            isValid: false
          },
          password: {
            value: '',
            isValid: false
          }
        },
        false
      );

    const switchModeHandler = ()=>{
        setIsLoginMode(prevMode => !prevMode);
    }

    const submitHanlder = event =>{
        event.prevetDefault();
        console.log("submitted")
    }

    return <>
        <Card className="authentication">
            <h2>Login</h2>
            <hr />
            <Button variant="outline-primary" type="submit" onClick={switchModeHandler}>
                SWITCH TO {isLoginMode ? 'SIGNUP' : 'LOGIN'}
            </Button>
        </Card>
    </>
}


export default LoginPage1;