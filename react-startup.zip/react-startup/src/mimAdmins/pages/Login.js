import React, { useState, useReducer } from 'react';

import Input from '../../shared/components/FormElements/Input';
import { useInput } from '../../shared/hooks/input-hook';
import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';

import {
    Form,
    Button,
    Card
} from 'react-bootstrap';


import './LoginPage.css';

const Login = ()=>{

    const [isLoginMode, setIsLoginMode] = useState(false);
    const [val, setVal] =  useState();

    const [inputState, changeHandler] = useInput(
        {
          email: {
            value: '',
          },
          password: {
            value: '',
          }
        }
      );

    const switchModeHandler = ()=>{
        setIsLoginMode(prevMode => !prevMode);
    }


    const submitHanlder = event =>{
        event.prevetDefault();
        console.log("submitted")
    }

    return <>
        <Card className="authentication">
            <h2>Login</h2>
            <hr />
            <form className="" onSubmit={submitHanlder}>
                {!isLoginMode && 
                <div class="form-group">
                <label for="exampleInputEmail1" className="float-left" >Name</label>
                <input type="text" class="form-control" id="name" aria-describedby="emailHelp" onChange={changeHandler} />
                </div>
                }
                <div class="form-group">
                    <label for="exampleInputEmail1" class="float-left">Email address</label>
                    <input type="email" class="form-control" id="email" aria-describedby="emailHelp" value={val} onChange={e => setVal(e.target.value)} />
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1" class="float-left" >Password</label>
                    <input type="password" class="form-control" id="password" value={val} onChange={e => setVal(e.target.value)} />
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
            <Button variant="outline-primary" type="submit" onClick={switchModeHandler}>
                SWITCH TO {isLoginMode ? 'SIGNUP' : 'LOGIN'}
            </Button>
        </Card>
    </>
}


export default Login;