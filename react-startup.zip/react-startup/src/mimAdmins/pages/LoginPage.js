import React, { useState, useReducer } from 'react';


import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';

import {
    Form,
    Button,
    Card,
    Modal
} from 'react-bootstrap';

import './LoginPage.css';


const inputReducer = (state, action) => {
    switch (action.type) {
        case 'ON_CHANGE':
            return {
                ...state,
                inputs: {
                    ...state.inputs,
                    [action.id]: { value: action.val },
                }
            }
        default: {
            return { state }
        }
    }
}

const LoginPage = () => {

    const [email, setEmail] = useState();
    const [isLoginMode, setLoginMode] = useState(true);
    const [show, setShow] = useState(true);

    const changeHanler = (event) => {
        //console.log(event.target.id);
        dispatch({ type: "ON_CHANGE", val: event.target.value, id: event.target.id })

    }
    const closeModalHandler = () => setShow(false);

    const [inputState, dispatch] = useReducer(inputReducer, {
        inputs: {
            email: {
                value: '',
            },
            password: {
                value: '',
            },
        }
    });

    const switchModeHandler = () => {

        if (!isLoginMode) {
            inputState.inputs.name = undefined;
        }
        setLoginMode(prevMode => !prevMode);
    };

    const submitHandler = async (event) => {
        event.preventDefault();
        console.log("form submitted")
        if (isLoginMode) {
            try {


                console.log(inputState.inputs.password.value)
                console.log(inputState.inputs.email.value)
                //   const responseData = await sendRequest(
                //     'http://localhost:5000/api/users/login',
                //     'POST',
                //     JSON.stringify({
                //       email: formState.inputs.email.value,
                //       password: formState.inputs.password.value
                //     }),
                //     {
                //       'Content-Type': 'application/json'
                //     }
                //   );
                //   //console.log(responseData.data._id)
                //   auth.login(responseData._id, responseData.token);
            } catch (err) { }
        } else {
            try {

                console.log(inputState.inputs.name.value)
                console.log(inputState.inputs.password.value)
                console.log(inputState.inputs.email.value)
                //   const formData = new FormData();
                //   formData.append('email', formState.inputs.email.value);
                //   formData.append('name', formState.inputs.name.value);
                //   formData.append('password', formState.inputs.password.value);
                //   formData.append('image', formState.inputs.image.value);
                //   const responseData = await sendRequest(
                //     'http://localhost:5000/api/users/signup',
                //     'POST',
                //     formData
                //   );

                //   auth.login(responseData.userId, responseData.token);
            } catch (err) { }
        }

        //console.log(inputState.inputs.email.value);
    }
    return (
        <React.Fragment>
           
                <button
                    onClick={() => setShow(true)}
                >
                    trigger Modal
                </button>
            
                <Modal show={show} onHide={closeModalHandler}>
                    <Modal.Header >
                        <Modal.Title>Encountered an Error!</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>Hello Error</Modal.Body>
                    <Modal.Footer>
                        <Button variant="secondary" onClick={closeModalHandler}>
                            Close
                        </Button>
                        <Button variant="primary" onClick={closeModalHandler}>
                            Save Changes
                        </Button>
                    </Modal.Footer>
                </Modal>
            
        </React.Fragment>
    );
}

export default LoginPage;