
import {createApi, fetchBaseQuery} from '@reduxjs/toolkit/query/react'; // 6th redux

const cryptoApiHeaders = {
    "x-rapidapi-host": "coinranking1.p.rapidapi.com",
    "x-rapidapi-key": "33900c0557msh4e6602520439a1ap1a4316jsn03c8b621d658",
    "useQueryString": true
}

const baseUrl = 'https://coinranking1.p.rapidapi.com';

const createRequest = (url)=>({url, headers: cryptoApiHeaders});

export const cryptoApi = createApi({
    reducerPath: 'cryptoApi',
    baseQuery: fetchBaseQuery({baseUrl}),
    endpoints: (builder) =>({
        getCryptos: builder.query({
            query: (count)=> createRequest(`/coins?limit=${count}`)
        }),
        getCoinDetail: builder.query({
            query: (uuid)=> createRequest(`/coin/${uuid}`)
        }),
        getCrytoHistory: builder.query({
            query: ({uuid, timePeriod})=> createRequest(`/coin/${uuid}/history?&timePeriod=${timePeriod}`)
        })
    })
})

//9th
export const {
    useGetCryptosQuery,
    useGetCoinDetailQuery,
    useGetCrytoHistoryQuery
} = cryptoApi;