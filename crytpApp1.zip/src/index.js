import React from 'react';
import ReactDOM from 'react-dom';
import {BrowserRouter as Router} from 'react-router-dom';
import { Provider } from 'react-redux'; //4 redux

import App from './App';
import 'antd/dist/antd.css';
import store from './app/store'; //3 redux

//5th redux wrapping the App inside the <Provider>
ReactDOM.render(
    <Router>
        <Provider store={store}>
            <App />
        </Provider> 
    </Router>,
 document.getElementById('root'));
