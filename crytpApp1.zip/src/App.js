import React from 'react';

import {
    BrowserRouter as Router,
    Route,
    Redirect,
    Switch,
    Link
  } from 'react-router-dom';
  
import { Layout, Typography, Space } from 'antd';

import {Navbar, Homepage, Exchanges, Cryptocurrencies, CryptoDetails, News} from './components';
import './App.css';
const App = () => {
  return( 
      <div className='app'>
          <div className='navbar'>
              <Navbar />
          </div>
          <div className='main'>
              <Layout>
                  <div className="routes">
                      <Switch>
                          <Route exact path='/'>
                              <Homepage />
                          </Route>
                          <Route exact path='/exchanges'>
                              <Exchanges />
                          </Route>
                          <Route exact path='/cryptocurrencies'>
                              <Cryptocurrencies />
                          </Route>
                          <Route exact path='/crypto/:uuid'>
                              <CryptoDetails />
                          </Route>
                          <Route exact path='/news'>
                              <News />
                          </Route>
                      </Switch>
                  </div>
              </Layout>
          <div className='footer'>
              <Typography.Title level={5} style={{color: 'white', textAlign: 'center'}}>
                  Cryptocurrencies <br />
                  All rights reserved.
              </Typography.Title>
              <Space>
                  <Link to='/homepage'>Home</Link> <br />
                  <Link to='/exchanges'>Exchanges</Link> <br />
                  <Link to='/cryptocurrencies'>Crypto currencies</Link> <br />
              </Space>
          </div>
          </div>

      </div>
  );
};

export default App;
