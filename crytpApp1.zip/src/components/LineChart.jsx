import React from 'react';
import {Line} from 'react-chartjs-2';
import {Col, Row, Typography} from 'antd';

const {Title} = Typography;

const LineChart = ({coinHistory, coinPrice, coinName}) => {
    // const coinPriced =[];
    // const coinTimestamp =[];
    // for(let i=0; i<coinHistory?.data?.history.length; i++) {
    //     coinPriced.push(coinHistory?.data?.history[i].price)
    //     coinTimestamp.push(new Date(coinHistory?.data?.history[i].timestamp).toLocaleDateString(    ))
    // }
    // const data = {
    //     labels: coinTimestamp,
    //     datasets:[
    //         {
    //             label: 'Price in USD',
    //             data: coinPriced,
    //             fill: false,
    //             backgroundColor:'#0071bd',
    //             borderColor: '#0071bd'
    //         }
    //     ]
    // };

    // const options = {
    //   scales: {
    //     yAxes: [
    //       {
    //         ticks: {
    //           beginAtZero: true,
    //         },
    //       },
    //     ],
    //   },
    // };
    const data = {
        labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
        datasets: [
          {
            label: "First dataset",
            data: [33, 53, 85, 41, 44, 65],
            fill: true,
            backgroundColor: "rgba(75,192,192,0.2)",
            borderColor: "rgba(75,192,192,1)"
          },
          {
            label: "Second dataset",
            data: [33, 25, 35, 51, 54, 76],
            fill: false,
            borderColor: "#742774"
          }
        ]
      };
  return (
    <>
      {/* <Row>
        <Col className="chart-header">
          <Title level={2} className="chart-title" >{coinName} Price Chart</Title>
          <Col className='price-container'>
              <Title level ={5} className="price-change">
                  {coinHistory?.data?.change}%
              </Title>
              <Title level ={5} className="current-price">
                  Current {coinName} Price: $ {coinPrice}
              </Title>
          </Col>
        </Col>
      </Row> */}
      <Line data={data}/>
    </>
  );
};

export default LineChart;
