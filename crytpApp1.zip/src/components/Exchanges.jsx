import React from 'react';

const Exchanges = () => {
  return (
  <div>
      <h1>
          Exchanges
      </h1>
  </div>);
};

export default Exchanges;
