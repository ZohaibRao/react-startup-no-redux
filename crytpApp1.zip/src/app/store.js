import {configureStore} from '@reduxjs/toolkit'; //1

import {cryptoApi} from '../services/cryptoApi'; //7th
import {cryptoNewsApi} from '../services/cryptoNewsApi'; //7th

//2 need to export the configuredStore as function of objects
export default configureStore({

    reducer:{
        [cryptoApi.reducerPath]: cryptoApi.reducer, //8th
        [cryptoNewsApi.reducerPath]: cryptoNewsApi.reducer, //8th
    },
});

//exported the store successfully, now lets implement it App.js