const express = require('express');
const socketio = require('socket.io');
const http = require('http');
const router = require('./router');

const app = express();
const PORT = process.env.PORT || 5005;
const httpServer = http.createServer(app);
const io = socketio(httpServer);

io.on('connection', (socket)=>{
    console.log('we at server have a new connection');

    socket.on('disconnect', ()=>{
        console.log("user has left");
    })
})

app.use(router);

httpServer.listen(PORT, ()=>{console.log(`server is running at ${PORT}`)})
