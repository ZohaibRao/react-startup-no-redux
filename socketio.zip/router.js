const express = require('express');

router = express.Router();

router.get('/', (req, res)=>{
    res.json("Hi get request as middleware from express Router");
})


module.exports = router;