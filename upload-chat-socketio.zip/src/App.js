import React, {useEffect} from 'react';
import {BrowserRouter as Router, Route} from 'react-router-dom';
import io from 'socket.io-client';
import Join from './components/Chat/Chat';


import './App.css';


const ENDPOINT = 'localhost:5000';

let socket;
const App = () => {
// const corosGoal = [{id:'007', text: 'zohaib'},
//                   {id:'008', text: 'rehan' },
//                   {id:'009', text: 'Umar'} ];
// const pointToFunctionHandler = (newGoal)=>{
//       corosGoal.push(newGoal);
// //       console.log(corosGoal);
// <Goals onAddGoal = {pointToFunctionHandler} />
// <List temp = {corosGoal} />

let connectedClients;
useEffect(()=>{

      console.log("hello");

      //establish the connection with sockets running at localhost:5000
      socket = io(ENDPOINT);

      //now we need to fire an event with the specific name at server listing
      // like we ll emit for 'join'

      //we are emitting measns we are sending req to server and we will get response form there
      // it can be error from server side 
      socket.emit('join', {name:'zohaib'}, ({error})=>{
            //we can have error from response
            alert(error);
      });

      socket.on('broadcast', (data)=>{
            connectedClients = data.description;
            console.log(connectedClients)
        })
      socket.on('newclientconnection', (data)=>{
            console.log(data.description);
      })

      return () => {
            socket.emit('dicsonnet');
            socket.off();
      }



},[ENDPOINT])

  
return (

      
<Router>
      <Route  path="/" exact component={Join} >
      </Route>

</Router>
  
);

};

export default App;
