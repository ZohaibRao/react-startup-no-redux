import React from 'react';

import './NewGoals.css';

const Goals = props => {
    const pointToFunctionHandler = event => {
     event.preventDefault(); //we are preventing serverside submission
        //console.log("is every thing is fine");
        const newGoal = {
            id : Math.random().toString(),
            text : 'My written text form NewGoals',

        };
        
         props.onAddGoal(newGoal);
    };


    
    return (
     <form onSubmit = {pointToFunctionHandler} >
         <input type="text" />
         <button> click me</button>
     </form>
    );
    

    
}

export default Goals;

//this is a component which sends data back to App (parent) / 
// lower level to higher level 