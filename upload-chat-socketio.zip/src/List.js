import React from 'react';

import './List.css';

const List = props => {
    //console.log(props.temp);
    return (
        <ul className ="goal-list" >
            {props.temp.map((x) =>{
                return <li key={x.id} > {x.id} : {x.text}</li>
            })}
        </ul>
        
    );
};

export default List;

// this is a component which accepts the data using props
// higher level towwards lower, parent to childs
// couple of things : data container is props 
// props.temp.map..