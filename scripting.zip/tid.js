const incrementAlphaNumeric = (str) => {
  let iter, min, len;
  return [...str]
    .reduceRight((a, c, i) => {
      let code = c.charCodeAt();
      if (code >= 48 && code < 57) { // [0-8]
        min = 48;
        len = 10;
      }
      else if ((code >= 97 && code < 122)) { // [a-y]
        min = 97;
        len = 26;
      } else if ((code >= 65 && code < 90)) { // [A-Y]
        min = 65;
        len = 26;
      }
      else if ((code === 90)) { // for Z -> 0 
        let code1 = 48;
        let sum = 0;
        let min1 = 48;
        let len1 = 10;
        let iter1 = code1 - min1 + sum;  // 48 - 48 + 1 = 1
        a.res[i] = String.fromCharCode(iter1 % len1 + min1);  // 1 % 10 + 48 = 49
        a.sum = Math.floor(iter1 / len);
        iter = 66;
        min = 65;
        len = 26;
        a.sum = 1;
        return a;
      }
      else if ((code === 122)) { // for  z --> A
        let code1 = 65;
        let sum = 0;
        let min1 = 65;
        let len1 = 26;
        let iter1 = code1 - min1 + sum;  // 48 - 48 + 1 = 1
        a.res[i] = String.fromCharCode(iter1 % len1 + min1);  // 1 % 10 + 48 = 49
        a.sum = Math.floor(iter1 / len);
        iter = 65;
        min = 65;
        len = 26;
        a.sum = 0;
        return a;
      }
      else if ((code === 57)) { // for  9 -> a
        let code1 = 97;
        let sum = 0;
        let min1 = 97;
        let len1 = 26;
        let iter1 = code1 - min1 + sum;  // 48 - 48 + 1 = 1
        a.res[i] = String.fromCharCode(iter1 % len1 + min1);  // 1 % 10 + 48 = 49
        // console.log(a.res[i])
        a.sum = Math.floor(iter1 / len);
        iter = 98;
        min = 97;
        len = 26;
        a.sum = 0;
        return a;
      }
      iter = code - min + a.sum;  // 48 - 48 + 1 = 1 
      a.res[i] = String.fromCharCode(iter % len + min);  // 1 % 10 + 48 = 49
      // console.log(iter, code, min, a.sum, (iter % len), (iter % len + min), a.res[i], i)
      a.sum = Math.floor(iter / len);
      return a;
    }, { res: [], sum: 1 })
    .res
    .join('');
}


console.log(incrementAlphaNumeric('111235Z')); // AA1
// console.log(incrementAlphaNumeric('00001z')); // AA1
// console.log(incrementAlphaNumeric('00002Z')); // AA1

// for(let i=10 ; i>=0 ; i--){
//   let incrementedNumber = incrementAlphaNumeric(initialNumber)
//   console.log(incrementedNumber);
//   initialNumber = incrementAlphaNumeric(incrementedNumber)
// }

