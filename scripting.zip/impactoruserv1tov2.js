

const { MongoClient } = require('mongodb');
const {findOne, appendDb} = require('./crud/crud-services');
const moment = require('moment');
const { DataExchange } = require('aws-sdk');
let client;
var url = 'mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2_prod_test?retryWrites=true&w=majority';
let result;


 lastImpactivity = {
   date: new Date().getTime(),
   type: "OPEN VOUCHER"
 }

 let actionLogObject;
const dbFindOperation = async ()=>{
  try {
    result =  await findOne("mim_v2_prod_test", "impactors", {})
    
    result = result.forEach(async (x, index)=>{

      if(x.isUpdated == false ){
        !x.createdAt ? x.createdAt ="": x.createdAt;
        !x.longitude ? x.longitude = 0.0 : x.longitude;
        !x.latitude ? x.latitude = 0.0 : x.latitude;
        !x.onBoardScreens ? x.onBoardScreens = false : x.onBoardScreens;
        !x.active ? x.active = true: x.active;
        !x.createdBy ? x.createdBy = 'USER': x.createdBy;
        !x.email ? x.email = '' : x.email;
        !x.lastUpdatedBy ? x.lastUpdatedBy = 'admin': x.lastUpdatedBy;
        !x.lastUpdatedAt ? x.lastUpdatedAt = Date.now().toString() : x.lastUpdatedAt;
        !x.loginCounter ? x.loginCounter = 0: x.loginCounter;
        !x.transactionCounter ? x.transactionCounter = 0: x.transactionCounter;
        !x.lastModified ? x.lastModified = Date.now().toString() : x.lastModified;
        !x.lastLoginAt ? x.lastLoginAt = Date.now().toString() : x.lastLoginAt;
        !x.schoolPendingRequest ? x.schoolPendingRequest =[]: x.schoolPendingRequest;
        !x.profileStatus ? x.profileStatus = "approved": x.profileStatus;
        !x.dob ? x.dob = "": x.dob;
        !x.impactorBuddies ? x.impactorBuddies = []: x.impactorBuddies;
        !x.impactLevel ? x.impactLevel = 0: x.impactLevel;
        !x.impactCredits ? x.impactCredits = 0: x.impactCredits;
        !x.currency ? x.currency = "PKR": x.currency;
        !x.about ? x.about = "My Impact Meter": x.about;
        !x.totalAmount ? x.totalAmount = 0: x.totalAmount;
        !x.totalImpactPoints ? x.totalImpactPoints = "0": x.totalImpactPoints;
        !x.gender ? x.gender = "": x.gender;
        !x.accountDeleted ? x.accountDeleted = false: x.accountDeleted;
        !x.logout ? x.logout = false: x.logout;
        !x.isProfileCompleted ? x.isProfileCompleted = false: x.isProfileCompleted;
        !x.isEmailVerified ? x.isEmailVerified = false: x.isEmailVerified;
        !x.isUpdated ? x.isUpdated = false: x.isUpdated= true;
        !x.advancePaymentBalance ? x.advancePaymentBalance = 0: x.advancePaymentBalance= true;
        !x.familiesHelpled ? x.familiesHelpled = 0: x.familiesHelpled= true;

        // append this data to this request

         //  console.log(x)
         await appendDb("mim_v2_prod_test", "impactors", {_id: x._id}, x);
         console.log("done")
      } 
      // return ;
    })
    //  result.filter((x)=>{
     
    // })
    console.log(result)
  } catch (error) {
    console.log(error)
  }
}
// find impactees with
 dbFindOperation(); // got all impactees

// 
// /console.log("result: ", result)
  //FIND SCRIPTS
// MongoClient.connect(url, function(err, db) {
//     if (err) throw err;
//     var dbo = db.db("mim_v2_test");
//     dbo.collection("pakProvinceList").findOne({}, function(err, result) {
//       if (err) throw err;
//       console.log(result);
//       db.close();
//     });
//   });



// MongoClient.connect(url, function(err, db) {
//     if (err) throw err;
//     var dbo = db.db("mim_v2");
//     // dbo.createCollection("listbanks", function(err, res) {
//     //     if (err) throw err;
//     //     console.log("Collection created!");
//     //     db.close(); // need to end only once
//     //   });


//     // inserOne in monogoDb collection 
//     // dbo.collection("impactees").insertOne(lastImpactivity,  function(err, result) {
//     //   if (err) throw err;
//     //   console.log(result);
//     //   db.close();
//     // });

//     // try{
//     //     dbo.collection("grocerybundleitems").findOne({"bundleIndex":2},  function(err, result) {
//     //       if (err) throw err;
//     //       for(let i =0; i< result.item.length ; i++){
//     //           console.log(result.item[i].price)
//     //       }
//     //       db.close();
//     //     });
//     // }catch(err){
//     //     console.log(err)
//     // }
    
   
//     let ids = [];
//     result = findOne("mim_v2_test", "impactees", {})
//   //   try{
//   //       dbo.collection("impactees").find().limit(20).forEach( x => 
//   //      { ids.push(x._id)}
//   //      )
//   //       // dbo.collection("impactees").find({_id},  function(err, result) {
//   //       //   if (err) throw err;
//   //       //   console.log(result, '\n')
//   //       // //   for( let i =0; i< result.item.length; i++ ){
//   //       // //       console.log(result.item[i]._id, '\n')
//   //       // //   }
//   //       //   db.close();
//   //       // });
//   //       console.log(ids)
//   //       //db.close();
//   //   }catch(err){
//   //       console.log(err)
//   //   }
//   });

