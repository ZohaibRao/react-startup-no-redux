

const { MongoClient } = require('mongodb');
let client;


var url = 'mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2_test?retryWrites=true&w=majority';

 doctorSpecialities = {
   specialities: [
    { ID: 1, Name: 'Allergy and immunology', icon:'' } ,
    { ID: 2, Name: 'Anesthesiology', icon:'' } ,
    { ID: 3, Name: 'Dermatology', icon:'' } ,
    { ID: 4, Name: 'Diagnostic radiology', icon:'' } ,
    { ID: 5, Name: 'Emergency mediciney', icon:'' } ,
    { ID: 6, Name: 'Family medicine', icon:'' } ,
    { ID: 7, Name: 'Internal medicine', icon:'' } ,
    { ID: 8, Name: 'Neurology', icon:'' } ,
    { ID: 9, Name: 'Obstetrics and gynecology', icon:'' } ,
    { ID: 10, Name: 'Ophthalmology', icon:'' } ,
    { ID: 11, Name: 'Pathology', icon:'' } ,
    { ID: 12, Name: 'Pediatrics', icon:'' } ,
    { ID: 13, Name: 'Physical medicine and rehabilitation', icon:'' } ,
    { ID: 14, Name: 'Preventive medicine', icon:'' } ,
    { ID: 15, Name: 'Radiation oncology', icon:'' } ,
    { ID: 16, Name: 'Surgery', icon:'' } ,
    { ID: 17, Name: 'Urology', icon:'' } ,
    { ID: 18, Name: 'Cardiologists', icon:'' } ,
    { ID: 19, Name: 'Dentist', icon:'' } ,
    { ID: 20, Name: 'Eye Surgeon', icon:'' } ,
    { ID: 21, Name: 'Diabetologist', icon:'' } ,
    { ID: 22, Name: 'ENT Surger', icon:'' } ,
    { ID: 23, Name: 'General Surgeon', icon:'' } ,
    { ID: 24, Name: 'General Physican', icon:'' } ,
    { ID: 25, Name: 'Psychiatrist', icon:'' } ,
    // 'Allergy and immunology',
    // 'Anesthesiology',
    // 'Dermatology',
    // 'Diagnostic radiology',
    // 'Emergency medicine',
    // 'Family medicine',
    // 'Internal medicine',
    // 'Medical genetics',
    // 'Nuclear medicine',
    // 'Obstetrics and gynecology',
    // 'Ophthalmology',
    // 'Pathology',
    // 'Pediatrics',
    // 'Physical medicine and rehabilitation',
    // 'Preventive medicine',
    // 'Psychiatry',
    // 'Radiation oncology',
    // 'Surgery',
    // 'Urology'
  // '1':'Allergy and immunology',
  // '2':' Anesthesiology',
  // '3':'Dermatology',
  // '4':'Diagnostic radiology',
  // '5':'Emergency medicine',
  // '6':'Family medicine',
  // '7':'Internal medicine',
  // '8':'Medical genetics',
  // '9':'Neurology',
  // '10':'Nuclear medicine',
  // '11':'Obstetrics and gynecology',
  // '12':'Ophthalmology',
  // '13':'Pathology',
  // '14':'Pediatrics',
  // '15':'Physical medicine and rehabilitation',
  // '16':'Preventive medicine',
  // '17':'Psychiatry',
  // '18':'Radiation oncology',
  // '19':'Surgery',
  // '20':' Urology'
]
 }


 const schoolfeeprefrences = {
    schoolfeeprefrenceslist : [
     {"ID":1, "Name":"monthly"},
     {"ID":2, "Name":"quarterly"},
     {"ID":3, "Name":"yearly"},
   ]
 }

 const schoolclasses = {
  schoolclasseslist : [
     {"ID":1, "Name":"nursery"},
     {"ID":2, "Name":"playgroup"},
     {"ID":3, "Name":"grade 1"},
     {"ID":4, "Name":"grade 2"},
     {"ID":5, "Name":"grade 3"},
     {"ID":6, "Name":"grade 4"},
     {"ID":7, "Name":"grade 5"},
     {"ID":8, "Name":"grade 6"},
     {"ID":9, "Name":"grade 7"},
     {"ID":10, "Name":"grade 8"},
     {"ID":11, "Name":"grade 9"},
     {"ID":12, "Name":"grade 10"},
     {"ID":13, "Name":"grade 11"},
     {"ID":14, "Name":"grade 12"},
   ]
 }

 
  //FIND SCRIPTS
// MongoClient.connect(url, function(err, db) {
//     if (err) throw err;
//     var dbo = db.db("mim_v2_test");
//     dbo.collection("pakProvinceList").findOne({}, function(err, result) {
//       if (err) throw err;
//       console.log(result);
//       db.close();
//     });
//   });

MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("mim_v2_test");
    // dbo.createCollection("listbanks", function(err, res) {
    //     if (err) throw err;
    //     console.log("Collection created!");
    //     db.close(); // need to end only once
    //   });

    dbo.collection("schoolclasses").insertOne(schoolclasses,  function(err, result) {
      if (err) throw err;
      console.log(result);
      db.close();
    });
    // dbo.collection("doctorSpecialities").insertOne(doctorSpecialities,  function(err, result) {
    //   if (err) throw err;
    //   console.log(result);
    //   db.close();
    // });
  });
