
const { map } = require('lodash');
const moment = require('moment'); // library
const currTime = Date.now(); // current time in the milliseconts

const now = moment();
const nowUnix = moment.unix(currTime);
var a = moment();
var b = moment.utc();
var time = "06/16/2022, 6:49:04";
a.format();  // 2013-02-04T10:35:24-08:00
b.format();  // 2013-02-04T18:35:24+00:00
console.log("aFormate: ", a)
console.log("bFormat: ", b)
a.valueOf(); // 1360002924000
b.valueOf(); // 1360002924000

console.log("a: ", a)
console.log("b: ", b)

console.log("moment : ", now);
console.log("moment : ", currTime);
console.log("moment unix: ", nowUnix);

console.log("unix to timeformate: ", moment(currTime).format('MM/DD/YYYY, h:mm:ss'))
console.log("unix to timeformate: ", moment(1657718906079).format('MM/DD/YYYY, h:mm:ss'))
console.log("unix to timeformate: ", moment(1657718982093).format('MM/DD/YYYY, h:mm:ss'))
console.log(Date.parse("06/16/2022, 6:49:04 "), moment(1655344144000).format('MM/DD/YYYY, h:mm:ss'));

let [, currentTime] = moment(Date.now()).format('MM/DD/YYYY, h:mm:ss')
console.log("this", moment(Date.now()).format('MM/DD/YYYY, hh:mm:ss'))

let today = "11/08/2022, 8:34:25";


console.log(today.split('/')[0])
console.log(moment(Date.now()).format('MM/DD/YYYY, hh:mm:ss').split('/')[0])  // 
console.log(moment(1667885792981).format("MM/DD/YYYY, hh:mm:ss"), new Date(today).getTime())


console.log((new Date("11/08/2022, 8:34:25").getTime() - new Date("11/08/2022, 3:11:17").getTime()) / (1000 * 3600 * 24))