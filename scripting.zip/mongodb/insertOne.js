

const { insertOne } = require('../crud/crud-services');
const moment = require('moment');

let result;

const data = {
    name: "Faisalabad",
    id: "PKPFBD",
    parentId: "PKP"
}
const dbFindOperation = async () => {
    try {

        result = await insertOne("mim_v2_test", "cities", data)

        console.log(result)
    } catch (error) {
        console.log(error)
    }
}

dbFindOperation(); // got all impactees
