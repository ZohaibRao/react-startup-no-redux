const { MongoClient } = require('mongodb');
let client;


var url = 'mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2_test?retryWrites=true&w=majority';

// health menu
 helpAndDisputeMenu = {    
  titlelisthealthdoctor : [
    {
      ID:"1",
      Name:"Payment",
      
    },
    {
      ID:"2",
      Name:"Complain",
      
    },
    {
      ID:"3",
      Name:"Patient Issues",
    },
    {
      ID:"4",
      Name:"Feedback",
    },
    {
      ID:"5",
      Name:"Appointment Issues",
    },
    {
      ID:"6",
      Name:"Others",
    }
  ]
  }

// school help menu
//  helpAndDisputeMenu = {    
//   titlelistschool : [
//     {
//       ID:"1",
//       Name:"Payment",
      
//     },
//     {
//       ID:"2",
//       Name:"Complain",
      
//     },
//     {
//       ID:"3",
//       Name:"Student Issues",
//     },
//     {
//       ID:"4",
//       Name:"Feedback",
//     },
//     {
//       ID:"5",
//       Name:"Enrollement Issues",
//     },
//     {
//       ID:"6",
//       Name:"Others",
//     }
//   ]
//   }
//  helpAndDisputeMenu = {    
  
//       "1":"Payment",
//       "2":"Complain",
//       "3":"Patient Issues",
//       "4":"Feedback",
//       "5":"Appointment Issues",
//       "6":"Others",
//   }

  //FIND SCRIPTS
// MongoClient.connect(url, function(err, db) {
//     if (err) throw err;
//     var dbo = db.db("mim_v2_test");
//     dbo.collection("pakProvinceList").findOne({}, function(err, result) {
//       if (err) throw err;
//       console.log(result);
//       db.close();
//     });
//   });

MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("mim_v2_test");
    // dbo.createCollection("listbanks", function(err, res) {
    //     if (err) throw err;
    //     console.log("Collection created!");
    //     db.close(); // need to end only once
    //   });

    dbo.collection("supporttitles").insertOne(helpAndDisputeMenu,  function(err, result) {
      if (err) throw err;
      console.log(result);
      db.close();
    });
  });