const fs = require("fs");

const str = 
"Allergy and immunology, Anesthesiology,Dermatology,Diagnostic radiology,Emergency medicine,Family medicine,Internal medicine,Medical genetics,Neurology,Nuclear medicine,Obstetrics and gynecology,Ophthalmology,Pathology,Pediatrics,Physical medicine and rehabilitation,Preventive medicine,Psychiatry,Radiation oncology,Surgery, Urology";
let strArr = str.split(',');
//const strJson = JSON.stringify(strArr)
console.log(strArr)

// fs.writeFileSync('docterSpeciality.txt', strJson);
// console.log("done")


