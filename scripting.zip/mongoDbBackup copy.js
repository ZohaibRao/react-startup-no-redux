const { MongoClient } = require('mongodb');
let client;
const exec = require('child_process').exec;
const spawn = require('child_process').spawn

//let cmd = 'mongodump --uri mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2_test --out=./ ';
// 'mongodump --host ' +
// dbOptions.host +
// ' --port ' +
// dbOptions.port +
// ' --db ' +
// dbOptions.database +
// ' --username ' +
// dbOptions.user +
// ' --password ' +
// dbOptions.pass +
// ' --out ' +
// newBackupPath;

// exec(cmd, (error, stdout, stderr) => {
//     if(error){
//         console.log('error', error)
//     }
    // if (this.empty(error)) {
    //   // check for remove old backup after keeping # of days given in configuration.
    // //   if (dbOptions.removeOldBackup == true) {
    // //     if (fs.existsSync(oldBackupPath)) {
    // //       exec('rm -rf ' + oldBackupPath, err => {});
    // //     }
    // //   }
    // }
  //});

let backupProcess = spawn('mongodump', [
    //'--db=restaurantDB',
   ' --uri=mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2',
    '--archive=./',
    '--gzip'
    ]);

backupProcess.on('exit', (code, signal) => {
    if(code) 
        console.log('Backup process exited with code ', code);
    else if (signal)
        console.error('Backup process was killed with singal ', signal);
    else 
        console.log('Successfully backedup the database')
});