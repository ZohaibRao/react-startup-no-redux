 // result.forEach(async (x) => {
            //     try {
            //         if (x.requestStatus === "pending") {
            //             await client.db(db).collection(col).updateOne(
            //                 { _id: x._id },
            //                 { $set: UpdateQuery },
            //                 { upsert: true }
            //             );

            //             const result3 = await client.db(db).collection("banktransactions").findOne({ requestId: x.requestId });
            //             await client.db(db).collection("banktransactions").updateOne(
            //                 { _id: result3._id },
            //                 {
            //                     $set: {
            //                         lastUpdatedAt: unixTime,
            //                         updatedBy: "admin",

            //                     }
            //                 },
            //                 { upsert: true }
            //             );
            //         }

            //     } catch (e) {
            //         console.log(e)
            //     }
            // })

 // const result = await client.db("mim_v2_test").collection("requestforgroceries").aggregate([


            //     {
            //         $lookup:
            //         {
            //             from: "banktransactions",
            //             foreignField: "requestId",
            //             localField: "requestId",
            //             as: "Transactions"
            //         }
            //     }, {
            //         $unwind: {
            //             path: "$Transactions",
            //             preserveNullAndEmptyArrays: false
            //         }
            //     }
            // ]).toArray();