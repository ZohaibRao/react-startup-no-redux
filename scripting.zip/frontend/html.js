// var data = "<h1>hello world</h1>"
// // `<html><head><script src="https://test-bankalfalah.gateway.mastercard.com/static/checkout/checkout.min.js"data-error="errorCallback"data-cancel="cancelCallback"data-complete="completeCallback"></script><script type="text/javascript">function errorCallback(error){console.log(JSON.stringify(error));}function cancelCallback(){console.log("\\Payment cancelled\\");}function completeCallback(resultIndicator,sessionVersion){console.log(\"Payment Done\");console.log(\"result:\",resultIndicator);}Checkout.configure({merchant:\"TESTIMPACTMETER\",session:{id:\"${paramsData.sessionId}\",version:\"${paramsData.versionId}\"},billing:{address:{}},order:{id:\"${paramsData.orderId}\",description:\"${paramsData.orderDescription}\"},interaction:{merchant:{name:\"IMPACTMETER\",address: {line1:\"4th Floor,CP 63,Defence Raya Golf Resort Sector M DHA Phase 6, Lahore, Punjab 54792\",},email:\"help@ymyimpactmeter.com\",phone:\"+923154377317\",logo:\"https://www.myimpactmeter.com/assets/images/MIM_logo_main.png\"},locale: \"en_US\",}});</script></head><body><div style=\"margin:33px;  text-align:center\"> <img src=\"https://www.myimpactmeter.com/assets/images/MIM_logo_main.png\" /></div><div id="embed-target"></div><script>window.onload = Checkout.showEmbeddedPage('#embed-target');</script></body></html>`
// //{ "\\id\\": "\\23232\\", "\\pass\\": "\\1434\\" };
// console.log(data);
// var b = JSON.stringify(data);
// str = b.replace(/\\/g, '');
// console.log(str);

var encodedHtml = "PGh0bWw+PGhlYWQ+CiAgICAgICAgPHNjcmlwdCBzcmM9Imh0dHBzOi8vdGVzdC1iYW5rYWxmYWxhaC5nYXRld2F5Lm1hc3RlcmNhcmQuY29tL3N0YXRpYy9jaGVja291dC9jaGVja291dC5taW4uanMiCiAgICAgICAgICAgIGRhdGEtZXJyb3I9ImVycm9yQ2FsbGJhY2siIGRhdGEtY2FuY2VsPSJjYW5jZWxDYWxsYmFjayIgZGF0YS1jb21wbGV0ZT0iY29tcGxldGVDYWxsYmFjayI+IDwvc2NyaXB0PgogICAgICAgIDxzY3JpcHQgdHlwZT0idGV4dC9qYXZhc2NyaXB0Ij4KICAgICAgICAgICAgZnVuY3Rpb24gZXJyb3JDYWxsYmFjayhlcnJvcikgewogICAgICAgICAgICAgICAgY29uc29sZS5sb2coSlNPTi5zdHJpbmdpZnkoZXJyb3IpKTsKICAgICAgICAgICAgfQogICAgICAgICAgICBmdW5jdGlvbiBjYW5jZWxDYWxsYmFjaygpIHsKICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdQYXltZW50IGNhbmNlbGxlZCcpOwogICAgICAgICAgICB9CiAgICAgICAgICAgIGZ1bmN0aW9uIGNvbXBsZXRlQ2FsbGJhY2socmVzdWx0SW5kaWNhdG9yLCBzZXNzaW9uVmVyc2lvbikgewogICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ1BheW1lbnQgRG9uZScpOwogICAgICAgICAgICAgICAgY29uc29sZS5sb2coInJlc3VsdEluZGljYXRvciAsIHNlc3Npb25WZXJzaW9uIiwgcmVzdWx0SW5kaWNhdG9yLCBzZXNzaW9uVmVyc2lvbik7CiAgICAgICAgICAgIH0KICAgICAgICAgICAgQ2hlY2tvdXQuY29uZmlndXJlKHsKICAgICAgICAgICAgICAgIG1lcmNoYW50OiAiVEVTVElNUEFDVE1FVEVSIiwKICAgICAgICAgICAgICAgIHNlc3Npb246IHsKICAgICAgICAgICAgICAgICAgICBpZDogIlNFU1NJT04wMDAyMTY2OTU0MzM0STc2MTk0NDBINDAiLAogICAgICAgICAgICAgICAgICAgIHZlcnNpb246ICJhZTI0NTcwNTAxIgogICAgICAgICAgICAgICAgfSwKICAgICAgICAgICAgICAgIGJpbGxpbmc6IHsgYWRkcmVzczoge30gfSwKICAgICAgICAgICAgICAgIG9yZGVyOiB7CiAgICAgICAgICAgICAgICAgICAgaWQ6ICAiRTEwMDAwMDNjNDI1IiwKICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogICJzY2hvb2wiLCAKICAgICAgICAgICAgICAgIH0sCiAgICAgICAgICAgICAgICBpbnRlcmFjdGlvbjogewogICAgICAgICAgICAgICAgICAgIG1lcmNoYW50OiB7CiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6ICdJTVBBQ1RNRVRFUicsCiAgICAgICAgICAgICAgICAgICAgICAgIGFkZHJlc3M6IHsKICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxpbmUxOiAiNHRoIEZsb29yLENQIDYzLERlZmVuY2UgUmF5YSBHb2xmIFJlc29ydCBTZWN0b3IgTSBESEEgUGhhc2UgNiwgTGFob3JlLCBQdW5qYWIgNTQ3OTIiLAogICAgICAgICAgICAgICAgICAgICAgICB9LAogICAgICAgICAgICAgICAgICAgICAgICBlbWFpbDogJ3N1cHBvcnRAbXlpbXBhY3RtZXRlci5jb20nLAogICAgICAgICAgICAgICAgICAgICAgICBwaG9uZTogJys5MjMyMjY0NjAyNjYnLAogICAgICAgICAgICAgICAgICAgICAgICBsb2dvOiAnaHR0cHM6Ly93d3cubXlpbXBhY3RtZXRlci5jb20vYXNzZXRzL2ltYWdlcy9NSU1fbG9nb19tYWluLnBuZycKICAgICAgICAgICAgICAgICAgICB9LAogICAgICAgICAgICAgICAgICAgIGxvY2FsZTogJ2VuX1VTJywKICAgICAgICAgICAgICAgIH0KICAgICAgICAgICAgfSk7CiAgICAgICAgPC9zY3JpcHQ+CiAgICA8L2hlYWQ+CiAgICA8Ym9keT4KICAgICAgICA8ZGl2IHN0eWxlPSJtYXJnaW46MzNweDsgIHRleHQtYWxpZ246Y2VudGVyIj4gPGltZwogICAgICAgICAgICAgICAgc3JjPSJodHRwczovL3d3dy5teWltcGFjdG1ldGVyLmNvbS9hc3NldHMvaW1hZ2VzL01JTV9sb2dvX21haW4ucG5nIiAvPjwvZGl2PgogICAgICAgIDxkaXYgaWQ9ImVtYmVkLXRhcmdldCI+IDwvZGl2PgogICAgICAgIDxzY3JpcHQ+CiAgICAgICAgICAgIHdpbmRvdy5sb2FkID0gQ2hlY2tvdXQuc2hvd0VtYmVkZGVkUGFnZSgnI2VtYmVkLXRhcmdldCcpOwogICAgICAgIDwvc2NyaXB0PgogICAgPC9ib2R5PgogICAgCiAgICA8L2h0bWw+"

const htmlPage = `<html>

<head>
    <script src="https://test-bankalfalah.gateway.mastercard.com/static/checkout/checkout.min.js"
        data-error="errorCallback" data-cancel="cancelCallback" data-complete="completeCallback"> </script>
    <script type="text/javascript">
        function errorCallback(error) {
            console.log(JSON.stringify(error));
        }
        function cancelCallback() {
            console.log('Payment cancelled');
        }
        function completeCallback(resultIndicator, sessionVersion) {
            console.log('Payment Done');
            console.log("resultIndicator , sessionVersion", resultIndicator, sessionVersion);
        }
        Checkout.configure({
            merchant: "TESTIMPACTMETER",
            session: {
                id: "SESSION0002075943122K7772720L50",
                version: "dde5720401"
            },
            billing: { address: {} },
            order: {
                id: "032",
                description: "Grocery",
            },
            interaction: {
                merchant: {
                    name: 'IMPACTMETER',
                    address: {
                        line1: "4th Floor,CP 63,Defence Raya Golf Resort Sector M DHA Phase 6, Lahore, Punjab 54792",
                    },
                    email: 'support@myimpactmeter.com',
                    phone: '+923226460266',
                    logo: 'https://www.myimpactmeter.com/assets/images/MIM_logo_main.png'
                },
                locale: 'en_US',
            }
        });
    </script>
</head>

<body>
    <div style="margin:33px;  text-align:center"> <img
            src="https://www.myimpactmeter.com/assets/images/MIM_logo_main.png" /></div>
    <div id="embed-target"> </div>
    <script>
        window.load = Checkout.showPaymentPage();
    </script>
</body>

</html>`
var encodedImage = new Buffer.from(htmlPage, "binary").toString("base64");
var decodeHtml = new Buffer.from(encodedHtml, 'base64').toString('binary');
// var encodedImage = new Buffer.from("console.log(Hello)", "binary").toString("base64");
// var decodeHtml = new Buffer.from(encodedHtml, 'base64').toString('binary');

console.log(decodeHtml)

// export const decodedHtmlPage = () => { return decodeHtml }