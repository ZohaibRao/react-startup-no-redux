
<html>
    <head>
        <script src="https://test-bankalfalah.gateway.mastercard.com/static/checkout/checkout.min.js"
            data-error="errorCallback" data-cancel="cancelCallback" data-complete="completeCallback"> </script>

        <script>
            function myFunc() {
                console.log("hello world!")
            }
        </script>
    </head>
    <body>

        <h1>My First Heading</h1>

        <p>My first paragraph.</p>

    </body>
</html>

