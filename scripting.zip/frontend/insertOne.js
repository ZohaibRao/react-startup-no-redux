

const { insertOne } = require('../crud/crud-services');
const moment = require('moment');
const { getTimeUnix, getTime } = require('../services/common-services/common-services');

let result;

const data = {
    moduleName: "frngos",
    type: "bundle",
    ngoName: "alkhidmat",
    ngoCode: "AKM",
    ngoId: "",
    item: [
        { "id": 1, "ngoCode": "AKM", "RC": "TN", "name": "tent", "price": 20000.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },
        { "id": 2, "ngoCode": "AKM", "RC": "CP", "name": "cooked food", "price": 10000.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },
        { "id": 3, "ngoCode": "AKM", "RC": "TP", "name": "tarpaulin", "price": 2500.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },
        { "id": 4, "ngoCode": "AKM", "RC": "FP", "name": "food package", "price": 5000.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },
        { "id": 5, "ngoCode": "AKM", "RC": "MC", "name": "medical camp", "price": 50000.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },

    ]

}
const dbFindOperation = async () => {
    try {

        result = await insertOne("mim_v2_test", "fr_ngos", data)

        console.log(result)
    } catch (error) {
        console.log(error)
    }
}

dbFindOperation(); // got all impactees
