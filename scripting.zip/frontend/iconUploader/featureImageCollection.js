

const { pushItemCollection, appendDb, insertOne } = require('../../crud/crud-services');
const moment = require('moment');
const { getTimeUnix, getTime } = require('../../services/common-services/common-services');

let result;

const data = {
    moduleName: "mimImagesFeature",
    type: "images",
    list: [
        {
            "id": 1,
            iconUrl: "https://mimfeatureimages.s3.us-east-2.amazonaws.com/floodRelief2022.jpg",
            redirectUrl: "https://www.myimpactmeter.com/flood-relief/",
            "name": "Flood Relief 2022",
            isActive: true,
            lastModifiedAt: getTimeUnix(),
            createdAt: getTimeUnix(),
            createdBy: 'admin',
            lastUpdatedBy: ""
        },
    ]

}

const dbFindOperation = async () => {
    try {
        result = await insertOne("mim_v2_stage", "mimimages", data)

        console.log(result)
    } catch (error) {
        console.log(error)
    }
}

dbFindOperation(); // got all impactees
