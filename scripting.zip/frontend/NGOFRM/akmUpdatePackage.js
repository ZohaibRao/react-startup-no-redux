

const { pushItemCollection, appendDb, insertOne, findOne } = require('../../crud/crud-services');
const moment = require('moment');
const mongoose = require('mongoose');
const { getTimeUnix, getTime } = require('../../services/common-services/common-services');

let result;

// const data =
//     { "id": 5, "ngoCode": "AKM", "RC": "MC", "name": "Medical Camp", "price": 50000.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" };


// ref: 091422
const item = [

    { "id": 11, iconUrl: "https://floodrelief.s3.us-east-2.amazonaws.com/Masjid.svg", "ngoCode": "AKM", "RC": "CM", "name": "Contribution for Masjid Rehabilitation - Rs 1000", "price": 1000.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },
    { "id": 12, iconUrl: "https://floodrelief.s3.us-east-2.amazonaws.com/Solar%20Warter%20Tank.svg", "ngoCode": "AKM", "RC": "CP", "name": "Contribution for Solar Water Filtration Plant - Rs 1000", "price": 1000.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },

]

// { "id": 6, iconUrl: "https://floodrelief.s3.us-east-2.amazonaws.com/Clean%20Drinking%20Water%20210.svg", "ngoCode": "AKM", "RC": "CW", "name": "Clean Drinking Water", "price": 210.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },
//     { "id": 7, iconUrl: "https://floodrelief.s3.us-east-2.amazonaws.com/Medicine%20500.svg", "ngoCode": "AKM", "RC": "EM", "name": "Emergency Medicine", "price": 500.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },
//     { "id": 8, iconUrl: "https://floodrelief.s3.us-east-2.amazonaws.com/Dry%20Food%201000.svg", "ngoCode": "AKM", "RC": "DF", "name": "Dry Food Items", "price": 1000.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },
// const data = {
//     moduleName: "FR",
//     type: "bundle",
//     ngoName: "alkhidmat",
//     ngoCode: "AKM",
//     ngoId: "",
//     email: "hasham@myimpactmeter.com",
//     contact: "03157122173",
//     item: [
//         { "id": 1, iconUrl: "https://floodrelief.s3.us-east-2.amazonaws.com/Tent.svg", "ngoCode": "AKM", "RC": "TN", "name": "Tent", "price": 20000.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },
//         { "id": 2, iconUrl: "https://floodrelief.s3.us-east-2.amazonaws.com/Cooked+Food.svg", "ngoCode": "AKM", "RC": "CP", "name": "Cooked food", "price": 10000.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },
//         { "id": 3, iconUrl: "https://floodrelief.s3.us-east-2.amazonaws.com/Tarpaulin.svg", "ngoCode": "AKM", "RC": "TP", "name": "Tarpaulin", "price": 2500.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },
//         { "id": 4, iconUrl: "https://floodrelief.s3.us-east-2.amazonaws.com/Package+Food.svg", "ngoCode": "AKM", "RC": "FP", "name": "Food package", "price": 5000.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },
//         { "id": 5, iconUrl: "https://floodrelief.s3.us-east-2.amazonaws.com/Medical+Camp.svg", "ngoCode": "AKM", "RC": "MC", "name": "Medical camp", "price": 50000.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },
//         { "id": 6, iconUrl: "https://floodrelief.s3.us-east-2.amazonaws.com/Clean%20Drinking%20Water%20210.svg", "ngoCode": "AKM", "RC": "EM", "name": "Clean drinking water", "price": 210.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },
//         { "id": 7, iconUrl: "https://floodrelief.s3.us-east-2.amazonaws.com/Medicine%20500.svg", "ngoCode": "AKM", "RC": "CW", "name": "Emergency medicine", "price": 500.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },
//         { "id": 8, iconUrl: "https://floodrelief.s3.us-east-2.amazonaws.com/Dry%20Food%201000.svg", "ngoCode": "AKM", "RC": "DF", "name": "Dry food items ", "price": 1000.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },
// { "id": 13, iconUrl: "https://floodrelief.s3.us-east-2.amazonaws.com/Package+Food.svg", "ngoCode": "AKM", "RC": "CF", "name": "Contribution for Food package - Rs 200", "price": 200.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },
// { "id": 14, iconUrl: "https://floodrelief.s3.us-east-2.amazonaws.com/Dry%20Food%201000.svg", "ngoCode": "AKM", "RC": "CD", "name": "Contribution for Dry food items - Rs 200", "price": 200.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },
// { "id": 15, iconUrl: "https://floodrelief.s3.us-east-2.amazonaws.com/Tent.svg", "ngoCode": "AKM", "RC": "CT", "name": "Contribution for Tent - Rs 500", "price": 500.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },
// { "id": 16, iconUrl: "https://floodrelief.s3.us-east-2.amazonaws.com/Medical+Camp.svg", "ngoCode": "AKM", "RC": "CM", "name": "Contribution for Medical Camp - Rs 500", "price": 500.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', last
//     ]

// }

let existingItem;
let result1;
const dbFindOperation = async () => {
    const item = [
        { "id": 17, iconUrl: "https://floodrelief.s3.us-east-2.amazonaws.com/Cooked+Food.svg", "ngoCode": "AKM", "RC": "CF", "name": "Contribution for Cooked Food - Rs 200", "price": 200.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },

    ]
    try {
        [existingItem] = await findOne("mim_v2_stage", "fr_ngos", { "_id": mongoose.Types.ObjectId("63206d00067401cc9415c947") })
        // result = await insertOne("mim_v2_stage", "fr_ngos", data)
        // console.log("exisitng: ", existingItem.item,)


        item.forEach(async (x, index) => {
            existingItem.item.push(x)

            // x.transactionDetail.paymentMethod === "MIM WALLET" ? x.transactionDetail.paymentMethod = "MIM BALANCE" : x.transactionDetail.paymentMethod;

            await appendDb("mim_v2_stage", "fr_ngos", { _id: mongoose.Types.ObjectId("63206d00067401cc9415c947") }, existingItem);
            // console.log(existingItem.item)
            console.log("done", index)
        })
        // console.log(existingItem.item)
        // result1 = await appendDb("mim_v2_prod_live", "fr_ngos", { "_id": mongoose.Types.ObjectId("63109ce4851924416c8b009f") }, existingItem)
    } catch (error) {
        console.log(error)
    }
}
dbFindOperation(); // got all impactees
