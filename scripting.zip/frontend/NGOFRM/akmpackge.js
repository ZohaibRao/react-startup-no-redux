

const { pushItemCollection, appendDb, insertOne } = require('../../crud/crud-services');
const moment = require('moment');
const { getTimeUnix, getTime } = require('../../services/common-services/common-services');

let result;

// const data =
//     { "id": 5, "ngoCode": "AKM", "RC": "MC", "name": "Medical Camp", "price": 50000.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" };


const data = {
    moduleName: "FR",
    type: "bundle",
    ngoName: "alkhidmat",
    ngoCode: "AKM",
    ngoId: "",
    email: "hasham@myimpactmeter.com",
    contact: "03157122173",
    item: [
        { "id": 1, iconUrl: "https://floodrelief.s3.us-east-2.amazonaws.com/Tent.svg", "ngoCode": "AKM", "RC": "TN", "name": "Tent", "price": 20000.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },
        { "id": 2, iconUrl: "https://floodrelief.s3.us-east-2.amazonaws.com/Cooked+Food.svg", "ngoCode": "AKM", "RC": "CP", "name": "Cooked food", "price": 10000.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },
        { "id": 3, iconUrl: "https://floodrelief.s3.us-east-2.amazonaws.com/Tarpaulin.svg", "ngoCode": "AKM", "RC": "TP", "name": "Tarpaulin", "price": 2500.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },
        { "id": 4, iconUrl: "https://floodrelief.s3.us-east-2.amazonaws.com/Package+Food.svg", "ngoCode": "AKM", "RC": "FP", "name": "Food package", "price": 5000.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },
        { "id": 5, iconUrl: "https://floodrelief.s3.us-east-2.amazonaws.com/Medical+Camp.svg", "ngoCode": "AKM", "RC": "MC", "name": "Medical camp", "price": 50000.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },
        { "id": 6, iconUrl: "https://floodrelief.s3.us-east-2.amazonaws.com/Clean%20Drinking%20Water%20210.svg", "ngoCode": "AKM", "RC": "EM", "name": "Clean drinking water", "price": 210.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },
        { "id": 7, iconUrl: "https://floodrelief.s3.us-east-2.amazonaws.com/Medicine%20500.svg", "ngoCode": "AKM", "RC": "CW", "name": "Emergency medicine", "price": 500.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },
        { "id": 8, iconUrl: "https://floodrelief.s3.us-east-2.amazonaws.com/Dry%20Food%201000.svg", "ngoCode": "AKM", "RC": "DF", "name": "Dry food items ", "price": 1000.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" },

    ]

}

const dbFindOperation = async () => {
    try {

        // let data = { "id": 6, iconUrl: "", "ngoCode": "AKM", "RC": "EM", "name": "Emergency medicine", "price": 500.00, "currency": "PKR", isActive: true, lastModifiedAt: getTimeUnix(), createdAt: getTimeUnix(), createdBy: 'admin', lastUpdatedBy: "" }


        result = await insertOne("mim_v2_stage", "fr_ngos", data)

        console.log(result)
    } catch (error) {
        console.log(error)
    }
}

dbFindOperation(); // got all impactees
