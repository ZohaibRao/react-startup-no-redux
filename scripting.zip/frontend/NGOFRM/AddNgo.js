

const { insertOne } = require('../../crud/crud-services');
const moment = require('moment');
const { getTimeUnix, getTime } = require('../../services/common-services/common-services');

let result;

const data = {
    moduleName: "FR",
    ngoName: "akhuwat",
    ngoCode: "AKT",
    ngoId: ""
}
const dbFindOperation = async () => {
    try {

        result = await insertOne("mim_v2_test", "fr_ngos", data)

        console.log(result)
    } catch (error) {
        console.log(error)
    }
}

dbFindOperation(); // got all impactees
