let staticHtmlPage = `<html>

<head>
    <script src="https://test-bankalfalah.gateway.mastercard.com/static/checkout/checkout.min.js"
        data-error="errorCallback" data-cancel="cancelCallback" data-complete="completeCallback"> </script>
    <script type="text/javascript">
        function errorCallback(error) {
            console.log(JSON.stringify(error));
        }
        function cancelCallback() {
            console.log('Payment cancelled');
        }
        // on complete call back
        function completeCallback(resultIndicator, sessionVersion) {
            console.log('Payment Done');
            console.log(resultIndicator: ${001} sessionVersion: ${003});
        }
        Checkout.configure({
            "merchant": "TESTIMPACTMETER",
            "session": {
                id: "SESSION0002957476359N99748648N7",
                version: "8845e5be01"
            },
            billing: {
                address: {
                    street: 'DHA PHASE 5',
                    city: 'Lahore',
                    postcodeZip: '5700',
                    stateProvince: 'PUNJAB',
                    country: 'PAK'
                }
            },
            order: {
                id: "004",
                description: "buying"
            },
            interaction: {
                merchant: {
                    name: 'IMPACTMETER',
                    address: {
                        line1: '200 Sample St',
                        line2: '1234 Example Town'
                    },
                    email: 'zohaib@ymyimpactmeter.com',
                    phone: '+923154377317',
                    logo: 'https://www.myimpactmeter.com/assets/images/MIM_logo_main.png'
                },
                locale: 'en_US',

                // displayControl: {
                //     billingAddress: 'OPTIONAL',
                //     customerEmail: 'OPTIONAL',
                //     shipping: 'HIDE'
                // }
            }
        });
    </script>
</head>

<body>
    ...
    <div id="embed-target"> </div>
    <input type="button" value="Pay with Embedded Page" onclick="Checkout.showEmbeddedPage('#embed-target');" />
    <input type="button" value="Pay with Payment Page" onclick="Checkout.showPaymentPage();" />
    ...
</body>

</html>`


const paramsData = {
    resultIndicator: 123
}

let params = 123;
const changeHTMLPageWithNewParams = (...paramsData) => {
    return `<html>

    <head>
        <script src="https://test-bankalfalah.gateway.mastercard.com/static/checkout/checkout.min.js"
            data-error="errorCallback" data-cancel="cancelCallback" data-complete="completeCallback"> </script>
        <script type="text/javascript">
            function errorCallback(error) {
                console.log(JSON.stringify(error));
            }
            function cancelCallback() {
                console.log('Payment cancelled');
            }
            // on complete call back
            function completeCallback(resultIndicator, sessionVersion) {
                console.log('Payment Done');
                console.log(resultIndicator: ${paramsData["resultIndicator"]} sessionVersion: ${003});
            }
            Checkout.configure({
                "merchant": "TESTIMPACTMETER",
                "session": {
                    id: "SESSION0002957476359N99748648N7",
                    version: "8845e5be01"
                },
                billing: {
                    address: {
                        street: 'DHA PHASE 5',
                        city: 'Lahore',
                        postcodeZip: '5700',
                        stateProvince: 'PUNJAB',
                        country: 'PAK'
                    }
                },
                order: {
                    id: "004",
                    description: "buying"
                },
                interaction: {
                    merchant: {
                        name: 'IMPACTMETER',
                        address: {
                            line1: '200 Sample St',
                            line2: '1234 Example Town'
                        },
                        email: 'zohaib@ymyimpactmeter.com',
                        phone: '+923154377317',
                        logo: 'https://www.myimpactmeter.com/assets/images/MIM_logo_main.png'
                    },
                    locale: 'en_US',
    
                    // displayControl: {
                    //     billingAddress: 'OPTIONAL',
                    //     customerEmail: 'OPTIONAL',
                    //     shipping: 'HIDE'
                    // }
                }
            });
        </script>
    </head>
    
    <body>
        ...
        <div id="embed-target"> </div>
        <input type="button" value="Pay with Embedded Page" onclick="Checkout.showEmbeddedPage('#embed-target');" />
        <input type="button" value="Pay with Payment Page" onclick="Checkout.showPaymentPage();" />
        ...
    </body>
    
    </html>`
}

console.log(changeHTMLPageWithNewParams())