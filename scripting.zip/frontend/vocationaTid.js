

const { insertOne } = require('../crud/crud-services');
const moment = require('moment');

let result;

const data = {
    moduleName: "vocational",
    prefix: "E2"
}
const dbFindOperation = async () => {
    try {

        result = await insertOne("mim_v2_test", "ngo", data)

        console.log(result)
    } catch (error) {
        console.log(error)
    }
}

dbFindOperation(); // got all impactees
