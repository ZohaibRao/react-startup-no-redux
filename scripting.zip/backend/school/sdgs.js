const { MongoClient } = require('mongodb');
const mongoose = require('mongoose');

let client;

var url = 'mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2_test?retryWrites=true&w=majority';

// MongoClient.connect(url, function(err, db) {
//     if (err) throw err;
//     var dbo = db.db("mim_v2_test");
//     dbo.collection("impactors").findOne({}, function(err, result) {
//       if (err) throw err;
//       console.log(result);
//       db.close();
//     });
//   });


const obj=[
  {
  
    name: 'no proverty',
    icon: '',
    url: '',
    id: 1
  },
  {
    name: 'zero hunger',
    icon: '',
    url: '',
    id: 2
  },
  {
    name: 'good health and well-being',
    icon: '',
    url: '',
    id: 3
  },
  {
    name: 'quality education',
    icon: '',
    url: '',
    id: 4
  },
  {
    name: 'gender equality',
    icon: '',
    url: '',
    id: 5
  },
  {
    name: 'clean water and sanitation',
    icon: '',
    url: '',
    id: 6
  },
  {
    name: 'affordable and clean energy',
    icon: '',
    url: '',
    id: 7
  },
  {
    name: 'decent work and economic growth',
    icon: '',
    url: '',
    id: 8
  },
  {
    name: 'industry, innovation and infrastructure',
    icon: '',
    url: '',
    id: 9
  },
  {
    name: 'reduced inequalities',
    icon: '',
    url: '',
    id: 10
  },
  {
    name: 'sustainable cities and communities',
    icon: '',
    url: '',
    id: 11
  },
  {
    name: 'influence responsible consumption and production',
    icon: '',
    url: '',
    id: 12
  },
  {
    name: 'climate action',
    icon: '',
    url: '',
    id: 13
  },
  {
    name: 'life below water',
    icon: '',
    url: '',
    id: 14
  },
  {
    name: 'life on land',
    icon: '',
    url: '',
    id: 15
  },
  {
    name: 'peace, justice and strong institutions',
    icon: '',
    url: '',
    id: 16
  },
  {
    name: 'partnership for the goals',
    icon: '',
    url: '',
    id: 17
  },
]

MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("mim_v2_test");
    dbo.collection("unosdgs").insertMany( obj,  function(err, result) {
      if (err) throw err;
      console.log(result);
      db.close();
    });
  });
  
// async function connectdb() {
   
//     client = new MongoClient(url);
//     try {
//         // Connect to the MongoDB cluster
//         await client.connect();
//         console.log('connected with db')

//         //await  listDatabases(client);
//         // Make the appropriate DB calls
//         await listOfCollections(client);
//         //await findCollections(client)
//     } catch (e) {
//         console.error(e);
//     } finally {
//         await client.close();
//     }
// }

// connectdb().catch(console.error);

// async function listDatabases() {
//     try {
//         databasesList = await client.db().admin().listDatabases();
//         console.log("Databases:");
//         databasesList.databases.forEach(db => console.log(` - ${db.name}`));

//     } catch (err) {
//         console.log('facing this error:', err)
//     }
// }

// const listOfCollections = async (client)=>{

//     var cursor = await client.db("mim_v2_test").getCollectionsNames();
//     //console.log(cursor)
//     cursor.each(function(err, doc) {

//         console.log(doc);

//     });

// // const findCollections = async (client)=>{
// //     var findData = await client.
// // }
// }