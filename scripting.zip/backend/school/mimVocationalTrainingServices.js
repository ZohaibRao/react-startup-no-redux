
// this serivce add the new list to db.
const { insertMany } = require('../../crud/crud-services');
const { getTimeUnix, getTime } = require('../../services/common-services/common-services');
const mongoose = require('mongoose');

const moment = require('moment');

let result;


data = {
    coursesList: [
        {
            _id: mongoose.Types.ObjectId(),
            id: 1,
            name: 'course A',
            createdAt: getTime(),
            timestamp: getTimeUnix(),
            isActive: true,
            lastUpdateAt: getTimeUnix(),
            updatedBy: 'admin'
        },
        {
            _id: mongoose.Types.ObjectId(),
            id: 2,
            name: 'course B',
            createdAt: getTime(),
            timestamp: getTimeUnix(),
            isActive: true,
            lastUpdateAt: getTimeUnix(),
            updatedBy: 'admin'
        },
        {
            _id: mongoose.Types.ObjectId(),
            id: 3,
            name: 'course C',
            createdAt: getTime(),
            timestamp: getTimeUnix(),
            isActive: true,
            lastUpdateAt: getTimeUnix(),
            updatedBy: 'admin'
        },
        {
            _id: mongoose.Types.ObjectId(),
            id: 4,
            name: 'course D',
            createdAt: getTime(),
            timestamp: getTimeUnix(),
            isActive: true,
            lastUpdateAt: getTimeUnix(),
            updatedBy: 'admin'
        }
    ]
}



const dbFindOperation = async () => {
    try {

        result = await insertMany("mim_v2_test", "vocationaltrainingcourses", data);
        console.log(result)
    } catch (error) {
        console.log(error)
    }
}

dbFindOperation(); // got all impactees
