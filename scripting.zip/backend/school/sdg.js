
// this serivce add the new list to db.
const { insertMany } = require('../../crud/crud-services');

const moment = require('moment');

let result;

let years = [];


const data = {
    
}

const dbFindOperation = async () => {
    try {

        result = await insertMany("mim_v2_test", "yearlists", data);
        console.log(result)
    } catch (error) {
        console.log(error)
    }
}

dbFindOperation(); // got all impactees
