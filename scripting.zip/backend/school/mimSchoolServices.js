
// this serivce add the new list to db.
const { insertMany } = require('../../crud/crud-services');

const moment = require('moment');

let result;


const data = {
    "id": "3",
    "name": "University"
}


const dbFindOperation = async () => {
    try {

        result = await insertMany("mim_v2_test", "mimeducationservices", data);
        console.log(result)
    } catch (error) {
        console.log(error)
    }
}

dbFindOperation(); // got all impactees
