
// this serivce add the new list to db.
const { insertMany } = require('../../crud/crud-services');

const moment = require('moment');

let result;

let years = [];

let initNumber = 1947;
while (initNumber <= 2022) {
    console.log(initNumber)
    years.push(initNumber + 1);
    initNumber++;
}


const data = {
    years
}

const dbFindOperation = async () => {
    try {

        result = await insertMany("mim_v2_test", "yearlists", data);
        console.log(result)
    } catch (error) {
        console.log(error)
    }
}

dbFindOperation(); // got all impactees
