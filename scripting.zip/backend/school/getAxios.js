const axios = require('axios');


const doTransactionBAFPGI = async () => {
    let responed;

    for (let i = 0; i < 100; i++) {
        try {
            responed = await axios.get(`https://app.myimpactmeter.com/api/v2/dev/admin/getyearList`)
            // console.log("responseData: ", responed.data)
            if (responed.status == 200) {
                console.log("attemp:", i, "PASSED")
            }
            // else {
            //     console.log("responseData: ", responed.data)
            //     console.log("attemp:", i, "FAILED")
            // }
        } catch (error) {
            // l.info(` doTransactionBAFPGI ${error}`)
            console.log('got an error: ' + error)
            responed = "false";
            return responed;
        }

        console.log("attemp:", i)
    }

}

doTransactionBAFPGI();
