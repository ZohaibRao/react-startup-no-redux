const axios = require('axios');

const data = {
    "email": "zohaib@myimpactmeter.com",
    "name": "zohaib nasir",
    "contact": "03154377317",
    "amount": 50.00,
    "currency": "PKR"
};

const authToken = {
    "username": "merchant.TESTIMPACTMETER",
    "password": "4e528e05fb9e49557008688acc542c93"
}

const doTransactionBAFPGI = async (data, authToken) => {
    let responed;

    console.log(data, authToken);
    if (!authToken) {
        return {
            status: false,
            "error": "authToken not found"
        }
    }

    try {
        responed = await axios.post(`https://app.myimpactmeter.com/api/v2/dev/ipg/createSessionRand`,
            {
                "data": { ...data }
            },
            //     {
            //         auth: {
            //             ...authToken
            //         }
            //     }
        )
        console.log("responseData: ", responed.data)
        if (responed.status === 200) {
            return {
                status: true,
                data: responed.data
            }
        } else {

            return {
                status: false,
                data: '',
            }
        }
    } catch (error) {
        // l.info(` doTransactionBAFPGI ${error}`)
        console.log('got an error: ' + error)
        responed = "false";
        return responed;
    }
}

doTransactionBAFPGI(data, authToken)