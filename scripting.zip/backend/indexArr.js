const banks = [
    {
        "id": 1,
        "name": "Allied Bank Limited",
        "activated": false
    },
    {
        "id": 2,
        "name": "Askari Bank",
        "activated": true
    },
    {
        "id": 3,
        "name": "Bank Al Falah Islamic",
        "activated": true
    },
    {
        "id": 4,
        "name": "Bank Al Habib",
        "activated": true
    },
    {
        "id": 5,
        "name": "Bank Islami",
        "activated": true
    },
    {
        "id": 6,
        "name": "Bank of Khyber",
        "activated": true
    },
    {
        "id": 7,
        "name": "Bank of Punjab",
        "activated": true
    },
    {
        "id": 8,
        "name": "Faysal Bank",
        "activated": true
    },
    {
        "name": "Habib Bank Limited",
        "activated": true
    },
    {
        "name": "JS Bank",
        "activated": true
    },
    {
        "name": "Standard Chartered bank",
        "activated": true
    },
    {
        "name": "SILK Bank",
        "activated": true
    },
    {
        "name": "Summit Bank",
        "activated": true
    },
    {
        "name": "United Bank Limited",
        "activated": true
    },
    {
        "name": "Soneri Bank",
        "activated": true
    },
    {
        "name": "Citi Bank",
        "activated": true
    },
    {
        "name": "Dubai Islamic Bank",
        "activated": true
    },
    {
        "name": "Meezan Bank",
        "activated": true
    },
    {
        "name": "APNA Microfinance Bank",
        "activated": true
    },
    {
        "name": "SAMBA Bank",
        "activated": true
    },
    {
        "name": "Sindh Bank",
        "activated": true
    },
    {
        "name": "Habib Metropolitan Bank",
        "activated": true
    },
    {
        "name": "Industrial and Commercial Bank of China",
        "activated": true
    },
    {
        "name": "MCB",
        "activated": true
    },
    {
        "name": "MCB Islamic Bank",
        "activated": true
    },
    {
        "name": "Al-Baraka Bank",
        "activated": true
    },
    {
        "name": "National Bank Of Pakistan",
        "activated": true
    },
    {
        "name": "U Microfinance Bank Limited",
        "activated": true
    },
    {
        "name": "Telenor Microfinance Bank Limited (Tameer Bank)",
        "activated": true
    },
    {
        "name": "First Microfinance Bank Limited",
        "activated": true
    },
    {
        "name": "NRSP Microfinance Bank Limited",
        "activated": true
    },
    {
        "name": "Khushhali Microfinance Bank Limited",
        "activated": true
    },
    {
        "name": "Mobilink Microfinance Bank Limited",
        "activated": true
    },
    {
        "name": "FINCA Microfinance Bank Limited",
        "activated": true
    }
]


banks.map((x, index) => {
    !x.id ? x.id = index + 1 : x.id;
    return x
})

console.log(JSON.stringify(banks))