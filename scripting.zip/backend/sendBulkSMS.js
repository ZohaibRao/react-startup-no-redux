const { SMS } = require('aws-sdk');
const axios = require('axios');

contactList = [
    '03154377317',
    '03244471192'
];

const sendBulkSMS = async (contact, message) => {
    try {
        responed = await axios.post(`http://3.128.210.224:3003/api/v2/service/sendSMS`,
            {
                "data": {
                    "contact": contact,
                    "message": message
                }
            },
        )
        console.log("responseData: ", responed.data)
        if (responed.status === 200) {
            return {
                status: true,
                data: responed.data
            }
        } else {

            return {
                status: false,
                data: '',
            }
        }
    } catch (error) {
        // l.info(` doTransactionBAFPGI ${error}`)
        console.log('got an error: ' + error)
        responed = "false";
        return responed;
    }
}

// for (let i = 0; i < contactList.length; i++) {
//     // setInterval(function () { console.log("sent"); }, 3000);
//     sendBulkSMS(contactList[i], 'hello');
// }
