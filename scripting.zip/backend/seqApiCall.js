const axios = require('axios');

const myPromise = new Promise(async (resolve, reject) => {
    await axios.post('https://app.myimpactmeter.com/api/v2/dev/impactor/login', {
        "email": "zohaib@myimpactmeter.com",
        "password": "123456",
        "keepMeLogin": true
    }).then((result) => {
        result.success == 200 ? resolve(result.success == 200)
    }).catch((err) => {
            reject(err)
        })
});

myPromise
    .then((data) => {
        console.log("success: ", data)
    })
    .catch((error) => {
        console.log("error:", error)
    })