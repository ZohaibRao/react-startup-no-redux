const axios = require('axios');

const initBafCall = async () => {
    let responed;
    let paramsData = {
        "apiOperation": "INITIATE_CHECKOUT",
        "apiPassword": "$7f6b4e254fe0352bb4f31f62057a5c5f",
        "apiUsername": "",
        "merchant": "merchant.IMPACTMETER",
        "interaction.operation": "AUTHORIZE",
        "order.id": "1",
        "amount": 100.00,
        "order.currency": "PKR"
    };

    try {
        await axios({
            method: 'post',
            url: `https://test-bankalfalah.gateway.mastercard.com/api/rest/version/66/merchant/IMPACTMETER/session`,
            data: {
                "apiOperation": "INITIATE_CHECKOUT",
                "apiPassword": "",
                "apiUsername": "",
                "merchant": "merchant.IMPACTMETER",
                "interaction.operation": "AUTHORIZE",
                "order.id": "1",
                "amount": 100.00,
                "order.currency": "PKR"

            }
        }).then(function (response) {

            console.log("Error!! ", response);
            // responed = JSON.stringify(response.data);
        })
        return responed;
    } catch (error) {
        console.log('got an error: ' + error)
        responed = "false";
        return responed;
    }
    // try {
    //     // let responed;
    //     const response = await fetch(`https://app.myimpactmeter.com/api/v2/dev/ipg/getTxRecordBAF`
    //     ,{method: 'POST', body: JSON.stringify(data), headers: {'Authorization': (authToken).toString()}});
    //     //const res = await response.json();
    //     console.log("node-fetch data: ", response.headers);
    //     return response;
    // } catch (error) {
    //     console.log('got an error: ' + error)
    //         responed = "false";
    //         return responed;
    // }

}

initBafCall();
