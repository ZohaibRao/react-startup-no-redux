// map.set("data", { existingItem, requests })
// let concatObjects = Object.assign(existingItem, requests)