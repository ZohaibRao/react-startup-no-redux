
const { MongoClient } = require('mongodb');
let client;


var url = 'mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2_test?retryWrites=true&w=majority';

user = {
    "isVerified": true,
    "isFirstTimeUser": true,
    "agreeToTerms": false,
    "isLogout": true,
    "accountDeleted": false,
    "userName": "zohaib rao",
    "userCnic": "3630314436025",
    "userEmail": "zohaibrao02@gmail.com",
    "userContact": "03040780317",
    "createdAt": "01/18/2022, 7:12:20 pm",
    "timestampUnix": "1642515140208",
    "gender": "MBBS",
    "pmcNumber": "PMC",
    "qualifications": "MBBS",
    "specialist": "MBBS",
    "title": "Dr.",
    "yearOfExperience": 1,
    "city": "Multan",
    "patientPrefrences": {
        "children": true,
        "adults": false,
        "elderly": true
    },
    "province": "Lahore",
    "updateData": {
        "userName": "ZOHAIB NASIR",
        "qualifications": "MBBS",
        "title": "DR.",
        "city": "MULTAN"
    },
    "profileImage": {
        "location": "https://mimfileuploads.s3.us-east-2.amazonaws.com/1642682967072-61e68474e5a3e6777c3238f4-DOCTOR-undefined.png",
        "key": "1642682967072-61e68474e5a3e6777c3238f4-DOCTOR-undefined.png"
    },
    "location": [
        {
            "name": "Near Nisthar Hospital",
            "city": "Multan",
            "type": "male",
            "contactForAppointment": "03154377317",
            "weeklyAvailability": "0,1,2"
        },
        {
            "name": "GULAB DEVI HOSPITAL",
            "city": "LAHORE",
            "type": "male",
            "contactForAppointment": "03154377317",
            "weeklyAvailability": "0,1,2"
        }
    ],
    "feePlans": {
        "case1": "2500",
        "currency": "PKR"
    },
    "logout": true,
    "bankAccounts": [
        {
            "type": "bank",
            "bankName": "HBL",
            "accountNo": "01040099009538015",
            "title": "zohaib nasir",
            "active": false
        },
        {
            "type": "micro",
            "bankName": "jazzcash",
            "accountNo": "03154377317",
            "title": "zohaib nasir",
            "active": true
        },
        {
            "type": "tax",
            "taxNo": "3630314436025"
        }
    ]
}

//FIND SCRIPTS
// MongoClient.connect(url, function(err, db) {
//     if (err) throw err;
//     var dbo = db.db("mim_v2_test");
//     dbo.collection("pakProvinceList").findOne({}, function(err, result) {
//       if (err) throw err;
//       console.log(result);
//       db.close();
//     });
//   });

MongoClient.connect(url, function (err, db) {
    if (err) throw err;
    var dbo = db.db("mim_v2_test");
    // dbo.createCollection("listbanks", function(err, res) {
    //     if (err) throw err;
    //     console.log("Collection created!");
    //     db.close(); // need to end only once
    //   });

    dbo.collection("doctorusers").insertOne(user, function (err, result) {
        if (err) throw err;
        console.log(result);
        db.close();
    });
});
