

const { MongoClient } = require('mongodb');
let client;


var url = 'mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2?retryWrites=true&w=majority';

 doctorSpecialities = {
   specialities: [
    'Allergy and immunology',
    'Anesthesiology',
    'Dermatology',
    'Diagnostic radiology',
    'Emergency medicine',
    'Family medicine',
    'Internal medicine',
    'Medical genetics',
    'Nuclear medicine',
    'Obstetrics and gynecology',
    'Ophthalmology',
    'Pathology',
    'Pediatrics',
    'Physical medicine and rehabilitation',
    'Preventive medicine',
    'Psychiatry',
    'Radiation oncology',
    'Surgery',
    'Urology'
]
 }
  //FIND SCRIPTS
// MongoClient.connect(url, function(err, db) {
//     if (err) throw err;
//     var dbo = db.db("mim_v2_test");
//     dbo.collection("pakProvinceList").findOne({}, function(err, result) {
//       if (err) throw err;
//       console.log(result);
//       db.close();
//     });
//   });

MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("mim_v2");
    // dbo.createCollection("listbanks", function(err, res) {
    //     if (err) throw err;
    //     console.log("Collection created!");
    //     db.close(); // need to end only once
    //   });

    // dbo.collection("doctorSpecialities").insertOne(doctorSpecialities,  function(err, result) {
    //   if (err) throw err;
    //   console.log(result);
    //   db.close();
    // });

    try{
        dbo.collection("grocerybundleitems").findOne({"bundleIndex":2},  function(err, result) {
          if (err) throw err;
          for(let i =0; i< result.item.length ; i++){
              console.log(result.item[i].price)
          }
          db.close();
        });
    }catch(err){
        console.log(err)
    }
  });
