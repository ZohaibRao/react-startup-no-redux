const crypto = require("crypto");
const secret = 'zohaib nasir';
const hash = crypto.createHmac('sha256',secret).digest('hex');
console.log(hash);
