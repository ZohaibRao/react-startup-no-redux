// const impactorUser = require("../../models/impactor");
// //const requestSchema = require("../models/requestForGrocery");
// const cartSchema = require('../../models/cart');

// const userService = require('../../services/encrypDecryp.service');
// const bundlesItem = require("../../models/grocerySellPref.js");
// //const reqTransactionLog = require("../models/grocery-request-transactions");
// const Logging = require('../../models/loggedInStatus');
// const impacteeObj = require('../../models/impactee');
// const walletLog = require('../../models/walletLog');
const moment = require('moment');
// var aes256 = require('aes256');
// const jwt = require('jsonwebtoken');
// const Token = require('../../models/token');
// var randomstring = require('randomstring');
// const crudServices = require('./crud-services');
// const mimPercentShareSchema = require('../../models/mimpercentshare'); // mim percent schema



// //putting await here is important
// const comparePassword = (dbHashedPassword, password) => {
//     //console.log("db password ", dbHashedPassword, " given password", password)
//     var decryptedPassword = decryptDataWithKey(process.env.AES_KEY, dbHashedPassword);
//     //console.log("decrypted:", decryptedPassword);
//     if (decryptedPassword === password) {
//         return true;
//     }
//     return false;
// }

// const encryptData = (data) => {
//     try {
//         return aes256.encrypt(process.env.AES_KEY, data);
//     } catch (error) {
//         return false;
//     }

// }
// const encryptDataWithKey = (key, data) => {
//     try {
//         return aes256.encrypt(key, data);
//     } catch (error) {
//         console.log("common Service", error)
//         return false;
//     }

// }

// const decryptData = (data) => {
//     return aes256.decrypt(process.env.AES_KEY, data);
// }

// const decryptDataWithKey = (key, data) => {
//     return aes256.decrypt(key, data);
// }

// //this is the token creator 
// const JWToken = (expiry, payLoad) => {
//     return jwt.sign(
//         payLoad,
//         `${process.env.JWT_KEY}`,
//         { expiresIn: (expiry).toString() }
//     );
// }

// // //this is the token creator 
// // const JWTokenWithExpiry = (expiry, payLoad) => {
// //     return jwt.sign(
// //         payLoad,
// //         `${process.env.JWT_KEY}`,
// //         { expiresIn: (expiry).toString() }
// //     );
// // }

// const verifyJWT = (token) => {
//     return jwt.verify(token, `${process.env.JWT_KEY}`, (err, decoded) => {
//         if (err) {
//             return false;
//         } else {
//             return decoded;
//         }
//     });
// }

// const generateVerificationToken = (data) => {
//     let payload = {
//         userId: data.userId,
//         contact: data.contact,
//         tokenIsCheck: false,
//         token: randomstring.generate({
//             length: process.env.SMS_OTP_LENGTH,
//             charset: 'numeric',
//         })
//     };
//     return new Token(payload);
// };

// const calMimShareOfGivenAmount = (actualDonatedAmount) => {
//     //amount received as params will inclusive of .8 % comming from impactor side
//     // let 7820 /.92 = 8500
//     //1. actual amount 8500
//     //2. 8500 * .92 = 8500 - 7820 = 680
//     //3.
//     let localMimShare = Math.round((((actualDonatedAmount / process.env.WOMIMSHARE) - actualDonatedAmount) * 100) / 100);
//     const shareData = {
//         impactSupplierShare: actualDonatedAmount - localMimShare,
//         mimShare: localMimShare
//     }
//     return shareData;
// }

// const generateRequestId = () => {
//     return randomstring.generate({
//         length: process.env.REQ_TOKEN_LENGTH,
//         charset: 'numeric',
//     })
// }
// const generateRequestIdNew = () => {
//     return randomstring.generate({
//         length: process.env.REQ_TOKEN_LENGTH,
//         charset: 'numeric',
//     })
// }

// // CREATE new sequance TID
// const generateSequanceId = (str) => {
//     let iter, min, len;
//     return [...str]
//         .reduceRight((a, c, i) => {
//             let code = c.charCodeAt();
//             if (code >= 48 && code < 57) { // [0-8]
//                 min = 48;
//                 len = 10;
//             }
//             else if ((code >= 97 && code < 122)) { // [a-y]
//                 min = 97;
//                 len = 26;
//             } else if ((code >= 65 && code < 90)) { // [A-Y]
//                 min = 65;
//                 len = 26;
//             }
//             else if ((code === 90)) { // for Z -> 0 
//                 let code1 = 48;
//                 let sum = 0;
//                 let min1 = 48;
//                 let len1 = 10;
//                 let iter1 = code1 - min1 + sum;  // 48 - 48 + 1 = 1
//                 a.res[i] = String.fromCharCode(iter1 % len1 + min1);  // 1 % 10 + 48 = 49
//                 a.sum = Math.floor(iter1 / len);
//                 iter = 66;
//                 min = 65;
//                 len = 26;
//                 a.sum = 1;
//                 return a;
//             }
//             else if ((code === 122)) { // for  z --> A
//                 let code1 = 65;
//                 let sum = 0;
//                 let min1 = 65;
//                 let len1 = 26;
//                 let iter1 = code1 - min1 + sum;  // 48 - 48 + 1 = 1
//                 a.res[i] = String.fromCharCode(iter1 % len1 + min1);  // 1 % 10 + 48 = 49
//                 a.sum = Math.floor(iter1 / len);
//                 iter = 65;
//                 min = 65;
//                 len = 26;
//                 a.sum = 0;
//                 return a;
//             }
//             else if ((code === 57)) { // for  9 -> a
//                 let code1 = 97;
//                 let sum = 0;
//                 let min1 = 97;
//                 let len1 = 26;
//                 let iter1 = code1 - min1 + sum;  // 48 - 48 + 1 = 1
//                 a.res[i] = String.fromCharCode(iter1 % len1 + min1);  // 1 % 10 + 48 = 49
//                 // console.log(a.res[i])
//                 a.sum = Math.floor(iter1 / len);
//                 iter = 98;
//                 min = 97;
//                 len = 26;
//                 a.sum = 0;
//                 return a;
//             }
//             iter = code - min + a.sum;  // 48 - 48 + 1 = 1 
//             a.res[i] = String.fromCharCode(iter % len + min);  // 1 % 10 + 48 = 49
//             // console.log(iter, code, min, a.sum, (iter % len), (iter % len + min), a.res[i], i)
//             a.sum = Math.floor(iter / len);
//             return a;
//         }, { res: [], sum: 1 })
//         .res
//         .join('');
// }




// const generateUniqueId = (data) => {
//     return getTimeUnix() + data;
// }

// // cal mim percent share from db's percent amount.

// const currentMIMShareFig = async () => {
//     // get active percent share figure from db
//     let latestcurrentMIMShare = await crudServices.getUser(mimPercentShareSchema, 'onewithdata', { isActive: true })
//     return latestcurrentMIMShare.mimPercent;
// }

const getTime = () => { return moment(Date.now()).format('MM/DD/YYYY, h:mm:ss'); }
const getTimeUnix = () => {
    return (Date.now())

}

module.exports = {

    getTime,
    getTimeUnix,

};
