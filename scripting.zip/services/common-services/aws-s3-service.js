const multer = require('multer');
//const uuid = require('uuid');
const { v4: uuidv4 } = require('uuid');

const multer3 = require('multer-s3');
const AWS = require('aws-sdk');

const s3 = new AWS.S3({
  accessKeyId: process.env.S3AWSACCESSKEY,
  secretAccessKey: process.env.S3AWSSECRETKEY,
  bucket: process.env.BUCKET,
});

const bucket = process.env.LIVE_BUCKET;

const MIME_TYPE_MAP = {
  'image/png': 'png',
  'image/jpeg': 'jpeg',
  'image/jpg': 'jpg'
};

multer({
  limits: 500000,
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, 'uploads/images');
    },
    filename: (req, file, cb) => {
      //const ext = MIME_TYPE_MAP[file.mimetype];
      cb(null, Date.now().toString() + '-' + file.originalname);
    }
  }),
  fileFilter: (req, file, cb) => {
    const isValid = !!MIME_TYPE_MAP[file.mimetype];
    let error = isValid ? null : new Error('Invalid mime type!');
    cb(error, isValid);
  }
});

const uploadS3 = multer3({
  s3: s3,
  //contentType: multer3.AUTO_CONTENT_TYPE,
  acl: 'public-read',
  bucket: process.env.BUCKET,
  metadata: (req, file, cb) => {
    cb(null, { fieldName: file.fieldname })
    console.log(file);
  },
  key: (req, file, cb) => {
    cb(null, Date.now().toString() + '-' + file.originalname.trim())
  },
})

//var fileName =  multer({storage:storage})
//console.log(fileName)

const fileUpload = (imagefile) => multer({
  limits: 500000,
  storage: uploadS3,
  fileFilter: (req, file, cb) => {
    const isValid = !!MIME_TYPE_MAP[file.mimetype];
    let error = isValid ? null : new Error('Invalid mime type!');
    cb(error, isValid);
  }
}, (error, data) => {
  if (error) {
    return false
  } else {
    true
  }
});

const deletes3 = (key, delFromBucket) => s3.deleteObject({
  Bucket: delFromBucket,
  Key: key,
}, (err, data) => {
  if (err) {
    console.log(err)
  } else {
    return;
  }
})

const params = {
  Key: "1631031812411-Screenshot (1).png",
  Bucket: process.env.BUCKET,
}

const getImage =  async (key) => {
  let respData;
  await s3.getObject({ Bucket: bucket, Key: key }, (err, data) => {
  if (err) {
   // console.log(err)
    return err
  } else {
    var decodedImage = new Buffer.from(data.Body, 'base64').toString('binary');
    respData = new Buffer.from(decodedImage, 'base64').toString('binary');
  }
}).promise()
console.log(respData)
return respData
}

// s3.upload (uploadParams, function (err, data) {
//   if (err) {
//     console.log("Error", err);
//   } if (data) {
//     console.log("Upload Success", data.Location);
//   }
// });

const uploadBinaryFile = async (encodedImage, _key) => {
  let respData;
 await s3.putObject({
    Bucket: process.env.BUCKET,
    Key: _key,
    Body: encodedImage
  }, (err,data)=>{
    if(err) return err
    else {
    respData = true;
  }
  }).promise()
  return respData;
}


const imageUpload = (files) => multer({
  limits: 500000,
  storage: multer.diskStorage({
    destination: (req, files, cb) => {
      cb(null, 'uploads/images');
    },
    filename: (req, files, cb) => {
      //const ext = MIME_TYPE_MAP[file.mimetype];
      cb(null, Date.now().toString() + '-' + file.originalname);
    }
  }),
  fileFilter: (req, file, cb) => {
    const isValid = !!MIME_TYPE_MAP[file.mimetype];
    let error = isValid ? null : new Error('Invalid mime type!');
    cb(error, isValid);
  }
});



module.exports = {
  deletes3,
  getImage,
  fileUpload,
  imageUpload,
  uploadBinaryFile
};
