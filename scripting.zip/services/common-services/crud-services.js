import actionLog from '../../models/actionLog';
const commonServices = require('./common-services');
const { MongoClient } = require('mongodb');
import l from '../../../common/logger';


const getUser = (modal, getBy, data, selectData, populateData, sortData, limit) => {
    switch (getBy) {
        case 'id':
            return modal.findOne(data).lean();
        case 'onewithdata':
            return modal.findOne(data).lean();
        case 'allwithdata':
            return modal.find(data).lean();
        case 'phone':
            return modal.findOne(data).lean();
        case 'cnic':
            return modal.findOne(data).lean();
        case 'or':
            return modal.find({ $or: data }).lean();
        case 'and':
            return modal.find({ $and: data }).lean();
        case 'onewithselect':
            return modal.findOne(data).select(selectData).lean();
        case 'all':
            return modal.find().lean();
        case 'allwithselect':
            return modal.find().select(selectData).lean();
        case 'allwithDataAndSelect':
            return modal.find(data).select(selectData).lean();
        case 'populate':
            return modal.findOne(data).populate(selectData)
        case 'allpopulate':
            return modal.find(data).populate(selectData);
        case 'allselectpopulate':
            return modal.find(data).select(selectData).populate(populateData)
        case 'select':
            return modal.findOne({}).populate(data)
        case 'allOne':
            return modal.findOne(data).select(selectData).populate(populateData).sort(sortData).limit(limit).lean()
        case 'allMany':
            return modal.find(data).select(selectData).populate(populateData).sort({ $natural: sortData }).limit(limit).lean()
        case 'findWithSortLimit':
            return modal.find(data).sort({ _id: -1 }).limit(1)
        case 'aggregate':
            return modal.aggregate([{ $group: { _id: null, count: { $count: {} } } }])
        case 'deleteOne':
            return modal.deleteOne(data)
        default:
            return false;
    }
}

const userObject = (modal, req) => {
    return new modal({
        ...req.body
    });
}

const userObjectData = (modal, data) => {
    return new modal({
        ...data
    });
}

const registerUser = (modal, data) => {
    switch (modal) {
        case 'doctor':
            return data.save();
        case 'grocery':
            console.log('hello', modal)
            break;
        case 'impactor':
            break;
        default:
            console.log('default', modal)
            break;
    }
}

const saveUser = (modal) => {
    modal.save();
}

const updateUser = (modal, findBy, data) => {
    return modal.updateOne(
        { _id: findBy },
        {
            $set: data,
        }
    ).lean();
}

const appendData = (modal, findBy, data) => {
    return modal.updateOne(
        { _id: findBy },
        {
            $set: data,
        }
    );
}

const appendOneGeneric = (modal, findBy, data) => {
    return modal.updateOne(
        findBy,
        {
            $set: data,
        }
    );
}

const updateAllModal = (modal, findBy, data) => {
    return modal.update(
        { findBy },
        {
            $set: data,
        }
    );
}


const appendDataModal = (modal, findBy, data) => {
    return modal.updateOne(
        { _id: findBy },
        {
            $set: data,
        }
    );
}

const pushData = (modal, findBy, data) => {
    return modal.updateOne(
        { _id: findBy },
        {
            $push: data,
        }
    );
}

const getItem = async (getBy, collectionName, modal) => {

    switch (getBy) {

        // case 'id':
        //     return modal.findOne(data).lean();
        // case 'onewithdata':
        //     return modal.findOne(data).lean();
        // case 'allwithdata':
        //     return modal.find(data).lean();
        // case 'phone':
        //     return modal.findOne(data).lean();
        // case 'cnic':
        //     return modal.findOne(data).lean();
        // case 'or':
        //     return modal.findOne({ $or: data }).lean();
        // case 'and':
        //     return modal.find({ $and: data }).lean();
        // case 'onewithselect':
        //     return modal.findOne(data).select(selectData).lean();
        case 'all':
            async () => {
                await MongoClient.connect(process.env.MONGODB_URL, function (err, db) {
                    if (err) throw err;
                    var dbo = db.db(process.env.MONGODB);
                    dbo.collection(collectionName).findOne({}, function (err, result) {
                        if (err) {
                            console.log(err);
                            return err;
                        };
                        //console.log(result)
                        db.close();
                        return result;
                    });
                });
            }

        // case 'allwithselect':
        //     return modal.find().select(selectData).lean();
        // case 'populate':
        //     return modal.findOne(data).populate(selectData)
        // case 'allpopulate':
        //     return modal.find(data).populate(selectData);
        // case 'allselectpopulate':
        //     return modal.find(data).select(selectData).populate(populateData)
        // case 'select':
        //     return modal.findOne({}).populate(data)
        default:
            return false;
    }


}

//this function is for saving the action log of the user in the db, actionLogs
// by calling userId
const saveActionLog = async (_id, data) => {
    const saveData = new actionLog({
        userId: _id,
        data,
        createdAt: commonServices.getTime(),
        timestamp: commonServices.getTimeUnix(),
    })
    try {
        await saveData.save()
    } catch (err) {
        return err;
    }
}



// const userObject  =  (modal, req)=>{
//     switch (modal){
//         case 'doctor':
//             return new doctorUser({
//                 ...req.body
//             });
//         case 'grocery':
//             console.log('hello', modal)
//             console.log('data', data)
//             break;
//         case 'impactor':
//             break;
//         default:
//             console.log('default', modal)
//             break;
//     }
// }
// const registerUser = (modal, data)=>{

//     switch (modal){
//         case 'doctor':
//             return data.save();
//         case 'grocery':
//             console.log('hello', modal)
//             break;
//         case 'impactor':
//             break;
//         default:
//             console.log('default', modal)
//             break;
//     }

// }
// const updateUser = (modal, findBy, data )=>{
//     switch (modal){
//         case 'doctor':
//             return doctorUser.updateOne(
//                 {_id :findBy},
//                 {
//                     $set: data,
//                 }
//             ).lean();
//         case 'grocery':
//             console.log('hello', modal)
//             break;
//         case 'impactor':
//             break;
//         default:
//             console.log('default', modal)
//             break;
//     }
// }


// const appendData = (modal, findBy, data)=>{
//     switch (modal){
//         case 'doctor':
//             //const item =  await doctorUser.findOne({_id: findBy}).lean();
//             return doctorUser.updateOne(
//                 {_id :findBy},
//                 {
//                     $set: data,
//                 }
//             );
//         case 'grocery':
//             console.log('hello', modal)
//             break;
//         case 'impactor':
//             break;
//         default:
//             console.log('default', modal)
//             break;
//     }
// }
// const pushData = (modal, findBy, data)=>{
//     switch (modal){
//         case 'doctor':
//             //const item =  await doctorUser.findOne({_id: findBy}).lean();
//             return doctorUser.updateOne(
//                 {_id :findBy},
//                 {
//                     $push: data,
//                 }
//             );
//         case 'grocery':
//             console.log('hello', modal)
//             break;
//         case 'impactor':
//             break;
//         default:
//             console.log('default', modal)
//             break;
//     }
// }

/////////////////////MONGODB/////////////////////

async function insertOne(collectionName, data) {

    // mongoDb atlas url
    const uri = process.env.NODE_ENV === 'production' ? process.env.MONGODB_URL_LIVE : process.env.MONGODB_URL;
    const dbName = process.env.NODE_ENV === 'production' ? process.env.MONGODB_LIVE : process.env.MONGODB
    // create new mongoDBClient
    const client = new MongoClient(uri);
    let obj = {
        ...data,
        createdAt: commonServices.getTime(),
        timestamp: commonServices.getTimeUnix()
    }
    try {
        // Connect the client to the servers
        await client.connect();
        // establich and verify the connection status
        const result = await client.db(dbName).collection(collectionName).insertOne({ ...obj });
        l.info(`${this.constructor.name}.insertOne(${result})`);
        return result;
    } catch (error) {
        l.info(`${this.constructor.name}.insertOne(${error})`);
    } finally {
        await client.close();
    }

    /// then and promise method to insert into Db
    // MongoClient.connect(process.env.MONGODB_URL, function (err, db) {
    //     if (err) throw err;
    //     var dbo = db.db(process.env.MONGODB);
    //     let obj = {
    //         ...data,
    //         createdAt: commonServices.getTime(),
    //         timestamp: commonServices.getTimeUnix()
    //     }
    //     dbo.collection(collectionName).insertOne({ ...obj }, async function (err, result) {
    //         if (err) {
    //             db.close();
    //             l.info(`${this.constructor.name}.joinBetaIndex(${err})`);
    //             return res.status(404).send({ success: false, message: "join beta failed" });
    //         } else {
    //             db.close();
    //             return 1;
    //         }
    //     });
    // });
}
async function aggregate(collectionName, data) {

    // mongoDb atlas url
    const uri = process.env.NODE_ENV === 'production' ? process.env.MONGODB_URL_LIVE : process.env.MONGODB_URL;
    const dbName = process.env.NODE_ENV === 'production' ? process.env.MONGODB_LIVE : process.env.MONGODB
    // create new mongoDBClient
    const client = new MongoClient(uri);

    let obj = {
        ...data,
        createdAt: commonServices.getTime(),
        timestamp: commonServices.getTimeUnix()
    }
    try {
        // Connect the client to the servers
        await client.connect();
        // establich and verify the connection status
        const result = await client.db(dbName).collection(collectionName).aggregate([data]).toArray()
        // l.info(`${this.constructor.name}.aggregate(${result})`);
        return result;
    } catch (error) {
        l.info(`${this.constructor.name}.aggregate(${error})`);
    } finally {
        await client.close();
    }
}

// find existing user
async function findOne(collectionName, data) {
    // mongoDb atlas url
    const uri = process.env.NODE_ENV === 'production' ? process.env.MONGODB_URL_LIVE : process.env.MONGODB_URL;
    const dbName = process.env.NODE_ENV === 'production' ? process.env.MONGODB_LIVE : process.env.MONGODB
    // create new mongoDBClient
    const client = new MongoClient(uri, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
    });
    try {
        // Connect the client to the servers
        await client.connect();
        // establich and verify the connection status
        var result = await client.db(dbName).collection(collectionName).find(data).toArray()
        return result;
    } catch (error) {
        l.info(`crudService.findOne(${error})`);
    } finally {
        await client.close();
    }

    // promise method to fetch the data from MongoDb
    // let client;
    //  MongoClient.connect(process.env.MONGODB_URL, function (err, db) {
    //     if (err) throw err;
    //     var dbo = db.db(process.env.MONGODB);
    //     return  dbo.collection(collectionName).findOne(data)
    //    .then(result => {
    //         if (result) {
    //             db.close();
    //             result = JSON.stringify(result)
    //             console.log(`Successfully found document: ${result}.`);
    //             return 1;
    //         } else {
    //             db.close();
    //             console.log("No document matches the provided query.");
    //         }

    //     }).catch(err => console.error(`Failed to find document: ${err}`));
    // });
}

//////////////////// ping connection with monogoDb //////////////////
function pingMongoDb() {
    // mongoDb atlas url
    const uri = process.env.MONGODB_URL;
    // create new mongoDBClient
    const client = new MongoClient(uri);
    async function run() {
        try {
            // Connect the client to the servers
            await client.connect();
            // establich and verify the connection status
            await client.db(process.env.MONGODB).collection("anc").findOne({ ping: 1 });
            console.log("connected successfully to MongoDbServer");
            return 1;
        } finally {
            await client.close();
        }
    }
    run().catch(console.dir);
}

module.exports = {
    getUser,
    userObject,
    userObjectData,
    registerUser,
    updateUser,
    appendData,
    appendDataModal,
    appendOneGeneric,
    updateAllModal,
    pushData,
    saveUser,
    saveActionLog,
    insertOne,
    findOne,
    pingMongoDb,
    getItem,
    aggregate,
}