let arr = [];

let initNumber = 1947;
while (initNumber <= 2022) {
    console.log(initNumber)
    arr.push(initNumber + 1);
    initNumber++;
}

console.log(arr.length)