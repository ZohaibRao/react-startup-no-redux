let num=9;
if(num%3==0 | num%7==0){
    console.log("Multiple of 7 or 3");
}
else{
    console.log("Not multiple of 7 0r 3");
}