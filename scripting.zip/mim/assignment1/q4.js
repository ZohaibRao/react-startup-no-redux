checkNum=(num1,num2)=>{
    if(num1==50 | num2==50 | (num1+num2)==50){
        return true;
    }
    else{
        return false;
    }

}

console.log("The number if num2 is 50: " + checkNum(34,50));
console.log("The number if none of them is 50: " + checkNum(34,30));
console.log("The number if sum is 50: " + checkNum(25,25));
