let str="hello";
addAtFrontBack=()=>{
    str1=str.substring(0,1);
    str2=str1+str+str1;
    return str2;
}

console.log(addAtFrontBack(str));