let str="rethon";
addingString=(str)=>{
    if(str.startsWith("Py")){
        return (str);
    }
    else{
        str1=str.padStart((str.length+2),"Py");
        return ("The string by adding Py: "+str1);
    }

}

console.log(addingString(str));