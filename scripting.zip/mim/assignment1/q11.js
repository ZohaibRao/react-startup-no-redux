date=new Date();
dateformat=()=>{
    var year = date.getFullYear();
  
    var month = (1 + date.getMonth());
    if(month<10){
        month='0'+month;
    }
    
    var day = date.getDate();
    if(day<10){
        day='0'+day;
    }
    
    return month + '/' + day + '/' + year;
}

console.log(dateformat(date));