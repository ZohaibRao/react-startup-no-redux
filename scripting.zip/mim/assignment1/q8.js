let str="hello";
updateString=(str)=>{
    if(str.length>=1){
        str1=str.substring(0,1);
        str2=str.substring(str.length-1,str.length);
        str3=str.substring(1,str.length-1);
        str4=str2+str3+str1;
        return str4;

    }
    else{
        return ("The string length is less than 1.");
    }

}

console.log(updateString(str));