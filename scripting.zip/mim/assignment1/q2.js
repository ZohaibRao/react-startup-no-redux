sum=(a,b)=>{
    if(a==b){
        return (3*(a+b));
    }
    else{
        return (a+b);
    }
}
console.log("The sum of 2 and 3 is: "+sum(2,3));

console.log("The sum of 3 and 3 is: "+sum(3,3));
