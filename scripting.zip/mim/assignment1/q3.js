absoluteFunc=(num)=>{
    
    absDiff=Math.abs(num)-19;
    if(num>19){
        return (3*absDiff);
    }
    else{
        return absDiff;
    }

}

console.log("The absolute difference is: " + absoluteFunc(23));

