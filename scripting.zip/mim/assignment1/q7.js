let str="Hello world";

removeString=(str)=>{
    str1=str.slice(3,7);
    str2=str.replace(str1,"");
    return str2;
}
console.log("The new string after extracting the specific part is: "+ removeString(str));
