var express=require('express');
var app=express();
var fs=require("fs");

var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";


var user={
    "user4":{
        "name":"usama",
        "password":"usama123",
        "profession":"software engineering intern",
        "id":6
    }
}

app.post("/adduser",function(req,res){
    //read existing file
    fs.readFile(__dirname+"/"+"users.json","utf8",function(err,data){
        data=JSON.parse(data);
        data["user4"]=user["user4"];
        MongoClient.connect(url, function(err, db) {
            if (err) throw err;
            var dbo = db.db("mydb");
            var myobj = {
                name: data
            }
              dbo.collection("customers1").insertOne(myobj,function(err,res){
                  if(err) throw err;
                  console.log("respond");
                  db.close();
              });
          });
        //console.log(data);
        res.end(JSON.stringify(data));//stringify converts a js object or value to JSON string
    });
})
// MongoClient.connect(url, function(err, db) {
//     if (err) throw err;
//     var dbo = db.db("mydb");
//     var myobj = {
//         name: "Amish" ,
//         phone: 02213123
//     }
//       dbo.collection("customers1").insertOne(,function(err,res){
//           if(err) throw err;
//           console.log("respond");
//           db.close();
//       });
//   });
// var server=app.listen(8081,function(){
//     var host=server.address().address;
//     var port=server.address().port;
//     console.log(host,port);


// })
