var express=require('express');
var app=express();
var fs=require("fs");

var user={
    "user4":{
        "name":"aamish",
        "password":"aamish123",
        "profession":"software engineering intern",
        "id":5
    }
}

app.post("/adduser",function(req,res){
    //read existing file
    fs.readFile(__dirname+"/"+"users.json","utf8",function(err,data){
        data=JSON.parse(data);
        data["user4"]=user["user4"];
        console.log(data);
        res.end(JSON.stringify(data));//stringify converts a js object or value to JSON string
    });
})
var server=app.listen(8081,function(){
    var host=server.address().address;
    var port=server.address().port;
    console.log(host,port);


})