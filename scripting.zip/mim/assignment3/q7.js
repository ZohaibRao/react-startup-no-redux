let arr=[9,45,2,4,1];
let arr1=[1,2,3,4,5];
let arr2=[5,4,3,2,1];

ascending=(arr)=>
{
    let i=0;
    while(i!=arr.length-1){
        if(arr[i]<arr[i+1]){
            i++;

        }
        else{
            return (0);
        }
    }
    return(1); 

}

descending=(arr)=>
{
    let i=0;
    while(i!=arr.length-1){
        if(arr[i]>arr[i+1]){
            i++;

        }
        else{
            return (0);
        }
    }
    return(-1); 

}

if(ascending(arr)==1){
    console.log("The array is ascending");
}

else if(descending(arr)==-1){
    console.log("The array is descending");
}
else{
    console.log("The array is not in ascending nor descending.");
}
