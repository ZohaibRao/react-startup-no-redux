const fun1 = (val) => console.log(val);

const fun2 = (val) => console.log(val);

const myPromise = new Promise(function(fun1, fun2) {
    let x = 11;
    if (x == 10) {
        fun1('this is correct');
    } else {
        fun2('this is incorrect');
    }
});

myPromise.then(
    function(value) {
        fun1(value);
    },
    function(value) {
        fun2(value);
    }
);

console.log("Promise function "+myPromise);

//check the  function is promise or not

const ispromise= obj=> obj!=null && (typeof obj==='object' || typeof obj==='function') && typeof obj.then==='function';
console.log(ispromise({
    then: function(){
        return ' ';
    }
}));
