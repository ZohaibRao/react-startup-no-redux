let num=2.35678;
roundNum=(num)=>{
    return (num.toExponential(2));

}
console.log(roundNum(num));
