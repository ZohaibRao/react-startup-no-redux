let text='{"employee": ['+
    '{"firstname":"John","class": "x"},'+
    '{"firstname":"smith","class": "x1"} ]}';

function myFunc(text){

    try{
        JSON.parse(text);
    }catch(e){
        return false;
    }
    return true;
}
console.log(myFunc(text));

