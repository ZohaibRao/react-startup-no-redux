let arr=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20];
let arr1=[];
range=(step)=>{
    arr1[0]=arr[0];
    for(let i=1;i<arr.length;i++){
        let s=Math.pow(step,i);
        if(s<20){
            arr1[i]=s;
        }
    }
    arr1[arr1.length]=arr[arr.length-1];
return arr1;

}
console.log(range(4));



