const date=new Date();
console.log(date.toTimeString());
