const obj1={"name":"a",'id':Math.floor(Math.random() * 20)};
const obj2={"name":"b",'id':Math.floor(Math.random() * 20)};
const obj3={"name":"c",'id':Math.floor(Math.random() * 20)};
const obj4={"name":"d",'id':Math.floor(Math.random() * 20)};
const obj5={"name":"e",'id':Math.floor(Math.random() * 20)};
const obj6={"name":"f",'id':Math.floor(Math.random() * 20)};
const obj7={"name":"g",'id':Math.floor(Math.random() * 20)};
const obj8={"name":"h",'id':Math.floor(Math.random() * 20)};
const obj9={"name":"i",'id':Math.floor(Math.random() * 20)};
const obj10={"name":"j",'id':Math.floor(Math.random() * 20)};


const forOwnRight = (obj, fn) =>Object.keys(obj).reverse();
let arr=[obj1,obj2,obj3,obj4,obj5,obj6,obj7,obj8,obj9,obj10];

for(let i=0;i<10;i++){
    console.log(forOwnRight(arr[i]));
}
