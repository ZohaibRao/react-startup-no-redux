const obj1={"name":"a",'id':Math.floor(Math.random() * 20)};
const obj2={"name":"b",'id':Math.floor(Math.random() * 20)};
const obj3={"name":"c",'id':Math.floor(Math.random() * 20)};
const obj4={"name":"d",'id':Math.floor(Math.random() * 20)};
const obj5={"name":"e",'id':Math.floor(Math.random() * 20)};
const obj6={"name":"f",'id':5};
const obj7={"name":"g",'id':Math.floor(Math.random() * 20)};
const obj8={"name":"h",'id':Math.floor(Math.random() * 20)};
const obj9={"name":"i",'id':Math.floor(Math.random() * 20)};
const obj10={"name":"j",'id':Math.floor(Math.random() * 20)};

let arr=[obj1,obj2,obj3,obj4,obj5,obj6,obj7,obj8,obj9,obj10];

console.log(arr);
removeFunc=(arr)=>{
    for(let i=0;i<arr.length;i++){
       // console.log(i);
        //console.log(arr.length);
        if(arr[i].id==5){
            arr.splice(i,1);
        }
    }
return arr;
}
console.log(removeFunc(arr));