let arr=[1,2,3,4,5],total=0;

sumfunc=(total,arr)=>{
    return total+arr;
}
res=arr.reduce(total,arr);
console.log(res);