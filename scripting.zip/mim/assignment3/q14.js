let arr=[],i=2;

arr[0]=0,arr[1]=1;
fibo=(n)=>{
    for(let j=2;j<n-1;j++){
        arr[j]=0;
    }
    while(i!=n){
    arr[i]=arr[i-1]+arr[i-2];
    i++;
    }
return arr;

}
console.log(fibo(24));