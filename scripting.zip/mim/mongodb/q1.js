var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://0.0.0.0:27017";

// const { Double, MongoDBNamespace, Db } = require("mongodb");


MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb1");
  
  // for adding ids
  
  // var myobj=[
  //   {name:'john',address:'143a'},
  //   {
  //     name:'ali',address:'2333f'
  //   },
  //   {
  //     name:'ahmed',address:'2eddew'
  //   },
  //   { _id:234, name:"asad",address:'5tf4r'},
  // ];
  // dbo.collection("customers").insertMany(myobj,function(err,res){
  //   if (err) throw err;
  //   console.log("document inserted! " + res.insertedCount);
  
  // for finding

  // dbo.collection("customers").findOne({},function(err,result){
  //   if(err) throw err;
  //   console.log(result.name);
  
  // db.close();


 //find total no of documents
 
  // dbo.collection("customers").find({}).toArray(function(err,result){
  // if(err) throw err;
  //    console.log(result);
  //  db.close();


  //to find all documents without ids and names
  //ypu cannot specify 0 and 1  value to the same object except the _id

// dbo.collection("customers").find({},{projection: {_id: 0, address: 1}}).toArray(function(err,result){
//   if(err) throw err;
//      console.log(result[4]);
//    db.close();


//find specific address or name

// var name={address:'143a'};
// dbo.collection("customers").find(name).toArray(function(err,result){
//   if(err) throw err;
//      console.log(result);
//    db.close();


//to find address which start with 1

// var name={name:/^1/};
// dbo.collection("customers").find(name).toArray(function(err,result){
//   if(err) throw err;
//      console.log(result);
//    db.close();


// sort alphabetically by name
//1 for ascending 
//-1 for descending

// var s={name:-1};
// dbo.collection("customers").find().sort(s).toArray(function(err,result){
//   if(err) throw err;
//      console.log(result);
//    db.close();


//delete document with address

// var s={address:/^2/};
// dbo.collection("customers").deleteMany(s,function(err,res){
//   if(err) throw err;
//      console.log(res.deletedCount);
//    db.close();


//drop the collection

// var dbo = db.db("mydb");
// or u can use 
//dbo.dropCollection("customers", function(err, delOK)

// dbo.collection("customers").drop(function(err, delOK) {
//   if (err) throw err;
//   if (delOK) console.log("Collection deleted");
//   db.close();

var q={_id:24,pro_id:130,status:1};
var r={_id:130,name:'djf'};

//dbo.createCollection("customers1", function(err, res) {
  //if (err) throw err;
//});


// dbo.collection("customers1").insertOne(r,function(err,res){
//   if(err) throw err;
//   db.close();
// });
// dbo.collection("customers").insertOne(q,function(err,res){
//      if (err) throw err;


//      db.close();



//join 


dbo.collection('customers').aggregate([
  { $lookup:
     {
       from: 'customers1',
       localField: '_id',
       foreignField: 'company_id',
       as: 'orderdetails'
     }
   }
  ]).toArray(function(err, res) {
  if (err) throw err;
  const insertValue = {
    order: res
  }
  dbo.collection("organization").insertOne(insertValue,function(err,res){
     if (err) throw err;
  db.close();
  });
  });



});