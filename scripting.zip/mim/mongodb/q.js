var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://0.0.0.0:27017";
var org=[
    {_id:1,name:'aamish',type:'e-commerce',location:'lahore'},
    {_id:2,name:'aamish1',type:'e-commerce1',location:'lahore1'},
    {_id:3,name:'aamish2',type:'e-commerce2',location:'lahore2'},
    {_id:4,name:'aamish3',type:'e-commerce3',location:'lahore3'},
    {_id:5,name:'aamish4',type:'e-commerce4',location:'lahore4'},
    {employeeid:[]}
];
var employee=[
    {cnic:1234,fname:'aamish',lname:'1',salary:10000,status:true,company_id:1},
    {cnic:12345,fname:'aamish',lname:'2',salary:10000,status:true,company_id:12},
    {cnic:123456,fname:'aamish',lname:'3',salary:10000,status:false,company_id:13},
    {cnic:1234567,fname:'aamish',lname:'4',salary:10000,status:true,company_id:4},
    {cnic:12345678,fname:'aamish',lname:'5',salary:10000,status:true,company_id:15}
];
var sum=0;
MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("mydb1");
    

    //to calculate total salary

    dbo.collection("employees").aggregate([{$group: {_id:null, sum_val:{$sum:"$salary"}}}]).toArray(function(err, res) {
        if (err) throw err;
        console.log(res);

    db.close();
    });



    dbo.collection('organization').aggregate([
        { $lookup:
           {
             from: 'employees',
             localField: '_id',
             foreignField: 'company_id',
             as: 'orderdetails'
           }
         }
        ]).toArray(function(err, res) {
        if (err) throw err;
        const insertValue = {
          order: res
        }
      });
        dbo.collection("organization").insertOne(insertValue,function(err,res){
           if (err) throw err;
        db.close();
        });


db.close();




 
});