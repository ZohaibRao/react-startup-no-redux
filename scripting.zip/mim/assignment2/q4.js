let arr=[1,2,3,4,5,6,5];

filter=(arr,a,b)=>{
for(let i=0;i<arr.length;i++){
    if(arr[i]==a){
        arr.splice(i,1);

    }
    else if(arr[i]==b){
        arr.splice(i,1);

    }
    
}
return arr;
}
let a=3,b=5;
console.log("We will filter out values "+ a +" and "+b );
console.log("The original array is: "+filter(arr,a,b));