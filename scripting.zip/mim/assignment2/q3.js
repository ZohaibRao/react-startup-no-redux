//

let num=2334567;
if(num==''){
    return;
}
let str=num.toString();
let arr=[],arr1=[];
console.log("The number is converted to array as: ");
for(let i=0;i<str.length;i++){
    arr[i]=(str[i]);
    
}
for(let i=0;i<arr.length;i++){
    arr1[i]=parseInt(arr[i]);
    console.log(arr1[i]);
}
//console.log(arr1);

console.log("The sum of two numbers: ");
console.log(arr1[1]+arr1[2]);

