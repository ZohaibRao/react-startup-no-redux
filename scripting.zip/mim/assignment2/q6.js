let arr=[2,3,4,5,6,7,8,9];
console.log("We will extract 3rd and 5th index numbers.");
for(let i=0;i<arr.length;i++){
    if(i==3){
        console.log("The 3rd index value: "+arr[i]);
    }
    if(i==5){
        console.log("5th index value: "+arr[i]);
    }

}
