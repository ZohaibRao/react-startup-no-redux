let num=[1,2,3,4];
let a=1,b=1;
for(let i=0;i<num.length;i++){
    for(let j=0;j<num.length;j++){
        if(i==0 & j==0){
            console.log(""+num);
        }
        console.log(num[i]+" "+num[j]);
    }
}