let num=[1,2,3,4,5];
let arr=[];
twoDimension=(a,b)=>{

for(let i=0;i<a;i++){
    for(let j=0;j<b;j++){
        arr[i]=[];
    }


for(let i1=0;i1<a;i1++){
    for(let j1=0;j1<b;j1++){
        arr[i1][j1]=j1;
        
    }
}

}
return arr;
}
const res=twoDimension(2,3);
console.log(res);

