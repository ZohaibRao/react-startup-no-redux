let num=1234;//4d2 in hexa
let hex='';
let temp=num;
//console.log(temp);
let i=0,rem;
while(temp!=0){
    
    rem = Math.floor(temp%16); 
    console.log(rem);
    
    if(rem==10){
        hex+='A';
    }
    else if(rem==11){
        hex+='B';
    }
    else if(rem==12){
        hex+='C';
    }
    else if(rem==13){
        hex+='D';
    }
    else if(rem==14){
        hex+='E';
    }
    else if(rem==15){
        hex+='F';
    }
    else{
        hex+=rem;
    }
    temp= Math.floor(temp/=16);
}
//console.log("fjer");
console.log(hex.split("").reverse());
