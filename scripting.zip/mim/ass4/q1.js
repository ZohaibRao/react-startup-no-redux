let str="0000000",str1;

let original_string="H1"+ str +Math.floor(Math.random()*999);
var array=[];


str1=str;
let size=str1.length-1;

console.log("here are the ids generated: ");
function getNextChar(char) {
    if (char[size] == 'z') {
      return'A';
    }
    else if (char[size] == 'Z') {
        if(size==-1){
            return;
        }
        else if(char[size-1]=='0'){
            return String.fromCharCode(char.charCodeAt(size-1)+1);
        }
        else{
            return '0';
        }

    }
    else if(char[size]=='9'){
        return 'a';
    }
    else if(char[size]=='0'){
        return '1';
    }
    else{
    return String.fromCharCode(char.charCodeAt(size)+1);
    }
}
//console.log(str1);

let i=0,store;
let final_str,char_change;
store=getNextChar(str1);
final_str= str1;
while(final_str[size]!='Z'){
    char_change=str1[size];
    //final_str= str1.replace(char_change,store);
    final_str=str.substring(0, size) + store + str.substring(size + 1);
    //array[j]=0;
    array[i]="H1"+ final_str +Math.floor(Math.random()*9)+Math.floor(Math.random()*9)+Math.floor(Math.random()*9);     //storing in an array
    
    console.log(array[i]);
    store=getNextChar(final_str);
    if(final_str[size]=='Z'){
        size=size-1;
    }
    if(size==-1){
        break;
    }
    i++;
}



var fs = require('fs');

//Create a file

// fs.writeFile('mynewfile2.txt', 'w', function (err,file) {
//   if (err) throw err;
//   console.log('Saved!');
// });

//Delete the files

// fs.unlink('mynewfile1.txt', function (err) {
//   if (err) throw err;
//   console.log('Deleted!');
// });


//console.log(array);
const file=fs.createWriteStream('renameFile.txt');

//Renaming a file

// fs.writeFile('renameFile.txt', array, function (err) {
//   if (err) throw err;
//   console.log('Renamed!');
// });


  file.write(array.join('\n') + '\n');
file.end();
