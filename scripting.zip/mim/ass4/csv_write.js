//write into a csv file in js

var fs = require('fs');

//Create a file

fs.writeFile('file.csv', '', function (err,file) {
  if (err) throw err;
  console.log('csv file created!');
});


//Delete the files

// fs.unlink('file.csv', function (err) {
//   if (err) throw err;
//   console.log('Deleted!');
// });

//reading a text file and storing in arr

const {readFileSync, promises: fsPromises} = require('fs');
let arr=[];
function syncReadFile(filename) {
  const contents = readFileSync(filename, 'utf-8');

  arr = contents.split(/\r?\n/);

  console.log(arr);

  return arr;
}

syncReadFile('renameFile.txt');

//write into a csv file

const file=fs.createWriteStream('file.csv');


file.write(arr.join('\n') + '\n');
file.end();
