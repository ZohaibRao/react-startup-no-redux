let arr="00000",final_array=[];
let size=arr.length-1,i=1;
function getNextChar(char) {
    if (char[size] == '9') {
        if(size==-1){
            return;
        }
        else if(char[size-1]=='0'){
            return String.fromCharCode(char.charCodeAt(size-1)+1);
        }
        else{
            return '0';
        }

    }
    else{
        return String.fromCharCode(char.charCodeAt(size-1)+i);
    }


    //if(char[size]=='0' || char[size]=='1' || char[size]=='2' || char[size]=='3' || char[size]=='4' || char[size]=='5' || char[size]=='6' || char[size]=='7' || char[size]=='8' || char[size]=='9'){
      //  return String.fromCharCode(char.charCodeAt(size-1)+1); 
    //}
    
}

let str1=arr,char_change;
let store=getNextChar(str1);
let final_str= str1;

while(final_str[0]!='9'){
    char_change=final_str[size];
    //final_str= str1.replace(char_change,store);
    final_str=str1.substring(0, size) + store + str1.substring(size + 1);
    //array[j]=0;
    console.log(final_array[i]="N333SM"+ final_str +Math.floor(Math.random()*9)+Math.floor(Math.random()*9)+Math.floor(Math.random()*9));     //storing in an array//
    i++;
    //console.log(array[i]);
    store=getNextChar(final_str);
    if(final_str[size]=='9'){
        size=size-1;
    }
    if(size==-1){
        break;
    }
    
}










let str="N333SM"+arr+Math.floor(Math.random()*999);

