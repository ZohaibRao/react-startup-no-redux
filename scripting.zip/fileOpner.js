var fs = require('fs');
const path = require('path');
var zlib = require("zlib"); // from compressing operations
const sThree = require('./services/aws-services');

const rootDir = path.join(__dirname, 'database-backup');

// fs.readFile('./database-backup/mim_v2_test.gzip', (err, data)=>{
//     if (err) console.log('error in reading this file: ', err);
//     console.log('obtained file:', data);
// })
//file uploading to s3
// fs.readFile('./database-backup/mim_v2_test.gzip', async (err, data)=>{
//     if (err) console.log('error in reading this file: ', err);
//     console.log('obtained file:', data);
//     //console.log('Bucket to Target:', process.env.BUCKET);
//    try {
//        await sThree.uploadBinaryFile(data, new Date().getTime() + '-backkupfile')

//    } catch (error) {
//        console.log(error)
//    }
// })

let data;
try {
    sThree.getFile("1641447149444-backkupfile").then((data) => {
        console.log("file", data)
        fs.writeFileSync('./database-backup/abc', data); //simple compression
    })
    fs.createReadStream("./database-backup/abc")
            .pipe(zlib.createGunzip())
            .pipe(fs.createWriteStream('./database-backup/abc.gz'));
} catch (error) {
    console.log("encoutred an Error: ", error)
}




// compress the file input.tx to input.tx.gz
// fs.createReadStream('fileRead.txt')
//     .pipe(zlib.createGzip())
//     .pipe(fs.createWriteStream('input.txt.gz'));

// console.log("program is ended and file is compressed Successfully");

// now read the compressed file and decompress file it
