var aes256 = require('aes256');

const decryptData = (data) => {
    return aes256.decrypt('supersecret', data);
}

const comparePassword = async (dbHashedPassword) => {
    //console.log("db password ", dbHashedPassword, " given password", password)
    var decryptedPassword =  decryptData(dbHashedPassword);
    //console.log("decrypted:", decryptedPassword);
    // if (decryptedPassword !== password) {
    //     return false;
    // }
    return decryptedPassword;
}

console.log('password: ',comparePassword('aESru3R5EMcDFH5Y5/jTy3sRNiYJNiU='))
