/**
 * this scripts create the back up of the given mongo Atlas url,
 * and save it locally and upload the backup to s3 backupDb bucket,
 */
const cron = require('node-cron'), spawn = require('child_process').spawn;
//const spawn = require('child_process').spawn
const sThree =  require('./services/aws-services');
const AWS = require('aws-sdk');
var fs = require("fs");
const moment = require('moment');

const currentTime =  moment(Date.now() ).format('MMDDYYYY-hmmss');
//let cmd = 'mongodump --uri mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2_test';

let backupProcess = spawn('mongodump', [
  '--uri=mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2_test',
  `--archive=./database-backup/${currentTime}-mim_v2_test`
]);
// let backupProcess = spawn('mongodump', [
//   '--uri=mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2_test',
//   '--archive=./database-backup/mim_v2_test.gzip',
//   '--gzip'
// ]);

backupProcess.on('exit', (code, signal) => {
  if(code){ 
      console.log('Backup process exited with code ', code);
    }
  else if (signal)
      console.error('Backup process was killed with singal ', signal);
  else
    fs.readFile(`./database-backup/${currentTime}-mim_v2_test`, (err, data)=>{
      if (err) console.log('error in reading this file: ', err);
      //console.log('obtained file:', data);
     try{
      sThree.uploadBinaryFile(data,  currentTime + '-mim_v2_test-backkupfile')
     }catch(err){
       console.log(err)
     }
  })
      console.log('Successfully backedup the database')
});

// let dbBackupTask = cron.schedule('33 16 * * *', () => {
    
// });
// try {
//   let respData;
// const abc = async()=> {
//   await s3.putObject({
//     Bucket: process.env.AVATAR_BUCKET,
//     Key: 'DB',
//     Body: './database-backup/mim_v2_test.gzip'
//   }, (err,data)=>{
//     if(err) return err
//     else {
//     respData = true;
//   }
//   }).promise()
//   return respData;}
  
// } catch (error) {
//   console.log(error)
// }