const { MongoClient } = require('mongodb');
let client;


var url = 'mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2_test?retryWrites=true&w=majority';

doctorFeePlans = {
  plans: [
    {
      case: 1,
      amount: 2500,
      currency: 'PKR'
    },
    {

      case: 2,
      amount: 3500,
      currency: 'PKR'
    },
    {
      case: 3,
      amount: 4500,
      currency: 'PKR'
    }
  ]
}

//FIND SCRIPTS
// MongoClient.connect(url, function(err, db) {
//     if (err) throw err;
//     var dbo = db.db("mim_v2_test");
//     dbo.collection("pakProvinceList").findOne({}, function(err, result) {
//       if (err) throw err;
//       console.log(result);
//       db.close();
//     });
//   });

MongoClient.connect(url, function (err, db) {
  if (err) throw err;
  var dbo = db.db("mim_v2_test");
  // dbo.createCollection("listbanks", function(err, res) {
  //     if (err) throw err;
  //     console.log("Collection created!");
  //     db.close(); // need to end only once
  //   });

  dbo.collection("mimschoolclasses").insertOne(doctorFeePlans, function (err, result) {
    if (err) throw err;
    console.log(result);
    db.close();
  });
});