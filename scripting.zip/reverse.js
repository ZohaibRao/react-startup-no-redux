function reverse(arr, size) {
    
    for (let i = 0; i < Math.floor(size / 2); i++) {
        [arr[i], arr[size - 1 - i]] = [arr[size - 1 - i], arr[i]];
    }
    return arr;
}

let arr = [10,10,10,10,1];
console.log(reverse(arr, arr.length))