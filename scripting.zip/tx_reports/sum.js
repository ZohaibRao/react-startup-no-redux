

const { MongoClient } = require('mongodb');
const { findOne, appendDb, insertOne, insertMany } = require('../crud/crud-services');
const moment = require('moment');
const { DataExchange } = require('aws-sdk');
let client;
var url = 'mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2_test?retryWrites=true&w=majority';
let result;


lastImpactivity = {
  date: new Date().getTime(),
  type: "OPEN VOUCHER"
}


/*
GUEST USER SCHEMA 
fullName: 'Kanwal Cheema',
    email: 'kanwal@myimpactmeter.com',
    mobileNumber: '03225001983',
    moduleName: 'FR',
    ngoName: '',
    transactionId: 'FR1663776436287',
    totalAmount: 500,
    mimShare: 51.25,
    createdBy: 'ipg-admin',
    createdAt: '1663776559871',
    updatedBy: '',
    lastUpdatedAt: '',
    isActive: true,
    status: '',
    IsRegistered: false,
    supplier: { type: 'fr_ngo', name: 'alkhidmat' },
    userId: '',
    packName: 'Emergency medicine - Rs 500',
    packQuantity: 1,
    dateTime: '21/09/2022, 04:09:19',
    paymentInit: false,
    paymentComplete: false,
    paymentInitDate: '',
    paymentCompleteDate: '',
    instrumentNo: '',
    remarks: '',
    userType: 'Guest',
    payableAmount: 448.75,
*/

let actionLogObject;
const dbFindOperation = async () => {
  try {
    // result = await findOne("mim_v2_prod_live", "tx_reports", { "transactionId": "FR1663776436287" })
    let txReports;

    let set = new Set();
    let arr = [];

    txReports = await findOne("mim_v2_prod_live", "tx_reports_test", {}, 0)   // get all tx_reports requests

    let sum = 0;
    txReports.forEach((x, index) => {
      sum = sum + x.totalAmount;
    })

    console.log("sum: ", sum)


  } catch (error) {
    console.log(error)
  }
}
// find impactees with
dbFindOperation();

