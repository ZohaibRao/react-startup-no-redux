const { MongoClient } = require('mongodb');
let client;


var url = 'mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2?retryWrites=true&w=majority';

 data = {    
  applications: [
    {
      "objectId":"0001",
      "typeOfObject": "application",
      "typeOfApplication": "admission",
      "isActive": true,
      "isTestDone": false,
      "isTestScheduled":false,
      "testDate": "mm/dd/yyyy",
      "testStatus":"passed/pending/failed",
      "admissionGranted": "false",
      "date": "mm/dd/yyyy, h:mm:ss",
      "timestamp": 1653958839262,
      "studentData": {
          "cnic": "1234567890123",
          "name": "student-0001",
          "age": 24,
          "classGrade": "4th"
      }
   },
  {
      "objectId":"0002",
      "typeOfObject": "application",
      "typeOfApplication": "admission",
      "isActive": true,
      "isTestDone": false,
      "isTestScheduled":false,
      "testDate": "mm/dd/yyyy",
      "testStatus":"passed/pending/failed",
      "admissionGranted": "false",
      "date": "mm/dd/yyyy, h:mm:ss",
      "timestamp": 1653958839262,
      "studentData": {
          "cnic": "1234567890002",
          "name": "student-0002",
          "age": 24,
          "classGrade": "4th"
      }
   },
  {
      "objectId":"0003",
      "typeOfObject": "application",
      "typeOfApplication": "admission",
      "isActive": true,
      "isTestDone": false,
      "isTestScheduled":false,
      "testDate": "mm/dd/yyyy",
      "testStatus":"passed/pending/failed",
      "admissionGranted": "false",
      "date": "mm/dd/yyyy, h:mm:ss",
      "timestamp": 1653958839262,
      "studentData": {
          "cnic": "1234567890003",
          "name": "student-0003",
          "age": 24,
          "classGrade": "4th"
      }
   },
  {
      "objectId":"0004",
      "typeOfObject": "application",
      "typeOfApplication": "admission",
      "isActive": true,
      "isTestDone": false,
      "isTestScheduled":false,
      "testDate": "mm/dd/yyyy",
      "testStatus":"passed/pending/failed",
      "admissionGranted": "false",
      "date": "mm/dd/yyyy, h:mm:ss",
      "timestamp": 1653958839262,
      "studentData": {
          "cnic": "1234567890004",
          "name": "student-0004",
          "age": 24,
          "classGrade": "4th"
      }
   },
  {
      "objectId":"0005",
      "typeOfObject": "application",
      "typeOfApplication": "admission",
      "isActive": true,
      "isTestDone": false,
      "isTestScheduled":false,
      "testDate": "mm/dd/yyyy",
      "testStatus":"passed/pending/failed",
      "admissionGranted": "false",
      "date": "mm/dd/yyyy, h:mm:ss",
      "timestamp": 1653958839262,
      "studentData": {
          "cnic": "1234567890005",
          "name": "student-0005",
          "age": 24,
          "classGrade": "4th"
      }
   }
    ],
    resultApplications: [
    ],
    testApplications: [
    ],
  }

  //FIND SCRIPTS
// MongoClient.connect(url, function(err, db) {
//     if (err) throw err;
//     var dbo = db.db("mim_v2_test");
//     dbo.collection("pakProvinceList").findOne({}, function(err, result) {
//       if (err) throw err;
//       console.log(result);
//       db.close();
//     });
//   });

MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("mim_v2");
    // dbo.createCollection("listbanks", function(err, res) {
    //     if (err) throw err;
    //     console.log("Collection created!");
    //     db.close(); // need to end only once
    //   });

    dbo.collection("interviewtests").insertOne(data,  function(err, result) {
      if (err) throw err;
      console.log(result);
      db.close();
    });
  });