const { MongoClient } = require('mongodb');
let client;


var url = 'mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2_test?retryWrites=true&w=majority';

listofBanks = {
      
    banks: [
      {
       
        name: 'Allied Bank Limited',
        activated: false
      },
      {
        
        name: 'Askari Bank',
        activated: true
      },
      {
      
        name: 'Bank Al Falah Islamic',
        activated: true
      },
      {
      
        name: 'Bank Al Habib',
        activated: true
      },
      {
       
        name: 'Bank Islami',
        activated: true
      },
      {
     
        name: 'Bank of Khyber',
        activated: true
      },
      {
   
        name: 'Bank of Punjab',
        activated: true
      },
      {
       
        name: 'Faysal Bank',
        activated: true
      },
      {
     
        name: 'Habib Bank Limited',
        activated: true
      },
      {
      
        name: 'JS Bank',
        activated: true
      },
      {
        
        name: 'Standard Chartered bank',
        activated: true
      },
      {
        
        name: 'SILK Bank',
        activated: true
      },
      {
    
        name: 'Soneri Bank',
        activated: true
      },
      {
        
        name: 'Summit Bank',
        activated: true
      },
      {
        
        name: 'United Bank Limited',
        activated: true
      },
      {
        
        name: 'Soneri Bank',
        activated: true
      },
      {
        
        name: 'Citi Bank',
        activated: true
      },
      {
     
        name: 'Dubai Islamic Bank',
        activated: true
      },
      {
      
        name: 'Meezan Bank',
        activated: true
      },
      {
       
        name: 'APNA Microfinance Bank',
        activated: true
      },
      {
        
        name: 'SAMBA Bank',
        activated: true
      },
      {
        
        name: 'Sindh Bank',
        activated: true
      },
      {
        
        name: 'Al-Baraka Bank',
        activated: true
      },
      {
      
        name: 'Habib Metropolitan Bank',
        activated: true
      },
      {
        
        name: 'Industrial and Commercial Bank of China',
        activated: true
      },
      {
    
        name: 'MCB',
        activated: true
      },
      {
        
        name: 'MCB Islamic Bank',
        activated: true
      },
      {
       
        name: 'Al-Baraka Bank',
        activated: true
      },
      {
        
        name: 'National Bank Of Pakistan',
        activated: true
      },
      {
        
        name: 'U Microfinance Bank Limited',
        activated: true
      },
      {
       
        name: 'Telenor Microfinance Bank Limited (Tameer Bank)',
        activated: true
      },
      {
       
        name: 'First Microfinance Bank Limited',
        activated: true
      },
      {
        
        name: 'NRSP Microfinance Bank Limited',
        activated: true
      },
      {
        
        name: 'Khushhali Microfinance Bank Limited',
        activated: true
      },
      {
       
        name: 'Mobilink Microfinance Bank Limited',
        activated: true
      },
      {
       
        name: 'First Microfinance Bank Limited',
        activated: true
      },
      {
       
        name: 'FINCA Microfinance Bank Limited',
        activated: true
      }
    ]
  }

MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("mim_v2_test");
    dbo.collection("listbanks").findOne({}, function(err, result) {
      if (err) throw err;
      console.log(result);
      db.close();
    });
  });


// MongoClient.connect(url, function(err, db) {
//     if (err) throw err;
//     var dbo = db.db("mim_v2_test");
//     // dbo.createCollection("listbanks", function(err, res) {
//     //     if (err) throw err;
//     //     console.log("Collection created!");
//     //     db.close(); // need to end only once
//     //   });

//     dbo.collection("listbanks").insertOne( listofBanks,  function(err, result) {
//       if (err) throw err;
//       console.log(result);
//       db.close();
//     });
//   });

