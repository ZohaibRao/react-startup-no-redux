const { MongoClient } = require('mongodb');
// let client;
var aes256 = require('aes256');


const decryptDataWithKey = (key, data) => {
  return aes256.decrypt(key, data);
}

const encryptDataWithKey = (key, data) => {
  try {
    return aes256.encrypt(key, data);
  } catch (error) {
    console.log("common Service", error)
    return false;
  }

}


console.log(decryptDataWithKey("supersecret", "y7zjM3gNDTYBgP6Sv18nZYz9IqVj0K0="))
// RQbh1gLseYONR7+mjBhl7n93GQjkBRlfLDs=
console.log(encryptDataWithKey("supersecret", "Fds@-4v"))

// var url = 'mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2_test?retryWrites=true&w=majority';
// MongoClient.connect(url, function(err, db) {
//     if (err) throw err;
//     var dbo = db.db("mim_v2_test");s
//     dbo.collection("impactors").findOne({}, function(err, result) {
//       if (err) throw err;
//       console.log(result.password);
//       db.close();
//     });
//   });


// MongoClient.connect(url, function(err, db) {
//     if (err) throw err;
//     var dbo = db.db("mim_v2_test");
//     dbo.createCollection("listbanks", function(err, res) {
//         if (err) throw err;
//         console.log("Collection created!");
//         db.close(); // need to end only once
//       });

//     dbo.collection("listbanks").insertOne( listofBanks,  function(err, result) {
//       if (err) throw err;
//       console.log(result);
//       db.close();
//     });
//   });
