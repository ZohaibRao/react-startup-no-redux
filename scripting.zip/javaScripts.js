//javaScripts..
//variables to store the data, and to operate on that data
// operation means addition multiplication subtraction division modulus ...

var a,b,sum;

b=2;
var a = 'zohaib';
var sum = a === b;
console.log('sum :' + sum);
//node javascritps/..
// javascripts is a programming language.. 
// offers to write the code for front end hanlidng.  
// fullstack --> full website development .
// forontend(Html, css, javaScripts + React, Angular wordpress) , backend() , middleware apis
console.log((a === b) ? 'type are equals' :'type are not equal');

var a=1;
var b=0;
var result = a||b;
console.log( result );

var string = 'zohaibNasir';
// let complex = {
//     temp : 'zohbib',
//     lastName : 'nasir',
// };

console.log(typeof(string));
var obj = {
    firstName : 'zohaib',
    lastName : 'nasir',
}
console.log(obj.lastName);

for(var a=1 ;a<5 ; a++ ){
   console.log(a); 
}
do{

}while()

while(){

}
// let a ={
//     x:1,
//     y:2,
//     z:3,
// }
// foreach( temp : a){
//     console.log(temp);
// }
// arrays object are used to store the mulitple values

var car = ["abc","xyz","temp"];

var person = ["zohaib","nasir"];
// arrays as a objec
var person1 = {
    firstName: "zohaib",
    lastNmae: "nasir",
    age: 22
};
// Array Elements Can Be Objects
// JavaScript variables can be objects. Arrays are special kinds of objects
// Because of this, you can have variables of different types in the same Array
// ou can have objects in an Array. You can have functions in an Array. You can have arrays in an Array:
myArray[0] = Date.now;
myArray[1] = myFunction;
myArray[2] = myCar;
// The real strength of JavaScript arrays are the built-in array properties and methods:
var x = cars.length; // // The length property returns the number of elements\
var y = cars.sort;  // // The sort() method sorts arrays
var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.length;
var first = fruits[0];
var last = fruits[fruits.length - 1]; // accessing the last element in array
var fruits, text, fLen, i;
fruits = ["Banana", "Orange", "Apple", "Mango"];
fLen = fruits.length;

text = "<ul>";
for (i = 0; i < fLen; i++) {
  text += "<li>" + fruits[i] + "</li>";
}
text += "</ul>";
var fruits, text;
fruits = ["Banana", "Orange", "Apple", "Mango"];

text = "<ul>";
fruits.forEach(myFunction);
text += "</ul>";

function myFunction(value) {
  text += "<li>" + value + "</li>";
}

var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.push("Lemon");  

var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits[fruits.length] = "Lemon";    // adds a new element (Lemon) to fruits

var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits[6] = "Lemon";    // adds a new element (Lemon) to fruits
Many programming languages support arrays with named indexes.

Arrays with named indexes are called associative arrays (or hashes).

JavaScript does not support arrays with named indexes.

In JavaScript, arrays always use numbered indexes.  

var person = [];
person[0] = "John";
person[1] = "Doe";
person[2] = 46;
var x = person.length;     // person.length will return 3
var y = person[0];  
var person = [];
person["firstName"] = "John";
person["lastName"] = "Doe";
person["age"] = 46;
var x = person.length;     // person.length will return 0
var y = person[0];         // person[0] will return undefined

The Difference Between Arrays and Objects
In JavaScript, arrays use numbered indexes.  

In JavaScript, objects use named indexes.

When to Use Arrays. When to use Objects.
JavaScript does not support associative arrays.
You should use objects when you want the element names to be strings (text).
You should use arrays when you want the element names to be numbers.
var points = new Array();     // Bad
var points = [];              // Good 
var points = new Array(40, 100, 1, 5, 25, 10); // Bad
var points = [40, 100, 1, 5, 25, 10];          // Good

var points = new Array(40, 100);  // Creates an array with two elements (40 and 100)
var points = new Array(40);
Array.isArray(fruits);
var fruits = ["Banana", "Orange", "Apple", "Mango"];

fruits instanceof Array;   // returns true

//functions
function myFunction(p1, p2) {
    return p1 * p2;   // The function returns the product of p1 and p2
  }

//   When an event occurs (when a user clicks a button)
// When it is invoked (called) from JavaScript code
// Automatically (self invoked)

//Function Return
// When JavaScript reaches a return statement, the function will stop executing.

// If the function was invoked from a statement, JavaScript will "return" to execute the code after the invoking statement.

// Functions often compute a return value. The return value is "returned" back to the "caller"

var x = myFunction(4, 3);   // Function is called, return value will end up in x

function myFunction(a, b) {
  return a * b;             // Function returns the product of a and b
}

function toCelsius(fahrenheit) {
    return (5/9) * (fahrenheit-32);
  }
  document.getElementById("demo").innerHTML = toCelsius(77);
  //Functions Used as Variable Values
  var x = toCelsius(77);

  //Real Life Objects, Properties, and Methods
  var car = {type:"Fiat", model:"500", color:"white"};
  var person = {firstName:"John", lastName:"Doe", age:50, eyeColor:"blue"};
  var person = {
    firstName: "John",
    lastName: "Doe",
    age: 50,
    eyeColor: "blue"
  };
  //You can access object properties in two ways:
  person.lastName;
  person["lastName"];

  var person = {
    firstName: "John",
    lastName : "Doe",
    id       : 5566,
    fullName : function() {
      return this.firstName + " " + this.lastName;
    }
  };
  var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.pop();
fruits.push("Kiwi");   
var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.shift();            // Removes the first element "Banana" from fruits
var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.unshift("Lemon");    // Adds a new element "Lemon" to fruits
var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits[fruits.length] = "Kiwi"; 
var fruits = ["Banana", "Orange", "Apple", "Mango"];
delete fruits[0];  
var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.splice(2, 0, "Lemon", "Kiwi");
var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.splice(0, 1);        // Removes the first element of fruits
var myGirls = ["Cecilie", "Lone"];
var myBoys = ["Emil", "Tobias", "Linus"];
var myChildren = myGirls.concat(myBoys);   // Concatenates (joins) myGirls and myBoys
var arr1 = ["Cecilie", "Lone"];
var arr2 = ["Emil", "Tobias", "Linus"];
var arr3 = ["Robin", "Morgan"];
var myChildren = arr1.concat(arr2, arr3);   // Concatenates arr1 with arr2 and arr3
var citrus = fruits.slice(3);

var citrus = fruits.slice(1, 3);
var citrus = fruits.slice(2);
fruits.sort();        // First sort the elements of fruits
fruits.reverse();

  //The this Keyword

//   In a function definition, this refers to the "owner" of the function.

// In the example above, this is the person object that "owns" the fullName function.

// In other words, this.firstName means the firstName property of this object.

// Read more about the this keyword at JS this Keyword.
name = person.fullName();
//If you access a method without the () parentheses, it will return the function definition:
name = person.fullName;
//Do Not Declare Strings, Numbers, and Booleans as Objects!
//When a JavaScript variable is declared with the keyword "new", the variable is created as an object:
var x = new String();        // Declares x as a String object
var y = new Number();        // Declares y as a Number object
var z = new Boolean();       // Declares z as a Boolean object
var txt = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
var sln = txt.length;



