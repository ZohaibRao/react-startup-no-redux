

const { MongoClient } = require('mongodb');
const {findOne, appendDb} = require('./crud/crud-services');
const moment = require('moment');
const { DataExchange } = require('aws-sdk');
const mongoose = require('mongoose');
let client;
var url = 'mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2_test?retryWrites=true&w=majority';
let result;


 lastImpactivity = {
   date: new Date().getTime(),
   type: "OPEN VOUCHER"
 }

 let actionLogObject;
const dbFindOperation = async ()=>{
  try {
    result =  await findOne("mim_v2_test", "impactors", {})
    
    result = result.forEach(async (x)=>{
      !x.notifications ? x.notifications = [] : x.notifications;
      await appendDb("mim_v2_test", "impactors", {_id: x._id}, x);
    })
    

    console.log("done")
    //  result.filter((x)=>{
     
    // })
  } catch (error) {
    console.log(error)
  }
}
// find impactees with
 dbFindOperation(); // got all impactees

// 
// /console.log("result: ", result)
  //FIND SCRIPTS
// MongoClient.connect(url, function(err, db) {
//     if (err) throw err;
//     var dbo = db.db("mim_v2_test");
//     dbo.collection("pakProvinceList").findOne({}, function(err, result) {
//       if (err) throw err;
//       console.log(result);
//       db.close();
//     });
//   });



// MongoClient.connect(url, function(err, db) {
//     if (err) throw err;
//     var dbo = db.db("mim_v2");
//     // dbo.createCollection("listbanks", function(err, res) {
//     //     if (err) throw err;
//     //     console.log("Collection created!");
//     //     db.close(); // need to end only once
//     //   });


//     // inserOne in monogoDb collection 
//     // dbo.collection("impactees").insertOne(lastImpactivity,  function(err, result) {
//     //   if (err) throw err;
//     //   console.log(result);
//     //   db.close();
//     // });

//     // try{
//     //     dbo.collection("grocerybundleitems").findOne({"bundleIndex":2},  function(err, result) {
//     //       if (err) throw err;
//     //       for(let i =0; i< result.item.length ; i++){
//     //           console.log(result.item[i].price)
//     //       }
//     //       db.close();
//     //     });
//     // }catch(err){
//     //     console.log(err)
//     // }
    
   
//     let ids = [];
//     result = findOne("mim_v2_test", "impactees", {})
//   //   try{
//   //       dbo.collection("impactees").find().limit(20).forEach( x => 
//   //      { ids.push(x._id)}
//   //      )
//   //       // dbo.collection("impactees").find({_id},  function(err, result) {
//   //       //   if (err) throw err;
//   //       //   console.log(result, '\n')
//   //       // //   for( let i =0; i< result.item.length; i++ ){
//   //       // //       console.log(result.item[i]._id, '\n')
//   //       // //   }
//   //       //   db.close();
//   //       // });
//   //       console.log(ids)
//   //       //db.close();
//   //   }catch(err){
//   //       console.log(err)
//   //   }
//   });

