


const { MongoClient } = require('mongodb');
const { getTimeUnix, getTime } = require('../services/common-services/common-services');
let client;
var url = 'mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2_test?retryWrites=true&w=majority';
let result;


async function insertOne(dbName, collectionName, data) {

    // mongoDb atlas url
    const uri = url;
    // create new mongoDBClient
    const client = new MongoClient(uri);
    let obj = {
        ...data,
        createdAt: getTimeUnix(),
        timestamp: getTimeUnix(),
        isActive: true,
        lastUpdateAt: getTimeUnix(),
        updatedBy: 'admin'
    }
    try {
        // Connect the client to the servers
        await client.connect();
        // establich and verify the connection status
        const result = await client.db(dbName).collection(collectionName).insertOne({ ...obj });
        // l.info(`${this.constructor.name}.insertOne(${result})`);
        return result;
    } catch (error) {
        // l.info(`${this.constructor.name}.insertOne(${error})`);
    } finally {
        await client.close();
    }

    /// then and promise method to insert into Db
    // MongoClient.connect(process.env.MONGODB_URL, function (err, db) {
    //     if (err) throw err;
    //     var dbo = db.db(process.env.MONGODB);
    //     let obj = {
    //         ...data,
    //         createdAt: commonServices.getTime(),
    //         timestamp: commonServices.getTimeUnix()
    //     }
    //     dbo.collection(collectionName).insertOne({ ...obj }, async function (err, result) {
    //         if (err) {
    //             db.close();
    //             l.info(`${this.constructor.name}.joinBetaIndex(${err})`);
    //             return res.status(404).send({ success: false, message: "join beta failed" });
    //         } else {
    //             db.close();
    //             return 1;
    //         }
    //     });
    // });
}

// insert Many
async function insertMany(dbName, collectionName, data) {

    // mongoDb atlas url
    const uri = url;
    // create new mongoDBClient
    const client = new MongoClient(uri);
    let obj = {
        ...data,
    }
    try {
        // Connect the client to the servers
        await client.connect();
        // establich and verify the connection status
        const result = await client.db(dbName).collection(collectionName).insertOne({ ...obj });
        // l.info(`${this.constructor.name}.insertOne(${result})`);
        return result;
    } catch (error) {
        // l.info(`${this.constructor.name}.insertOne(${error})`);
    } finally {
        await client.close();
    }

    /// then and promise method to insert into Db
    // MongoClient.connect(process.env.MONGODB_URL, function (err, db) {
    //     if (err) throw err;
    //     var dbo = db.db(process.env.MONGODB);
    //     let obj = {
    //         ...data,
    //         createdAt: commonServices.getTime(),
    //         timestamp: commonServices.getTimeUnix()
    //     }
    //     dbo.collection(collectionName).insertOne({ ...obj }, async function (err, result) {
    //         if (err) {
    //             db.close();
    //             l.info(`${this.constructor.name}.joinBetaIndex(${err})`);
    //             return res.status(404).send({ success: false, message: "join beta failed" });
    //         } else {
    //             db.close();
    //             return 1;
    //         }
    //     });
    // });
}

// insert array
async function insertArray(dbName, collectionName, data) {

    // mongoDb atlas url
    const uri = url;
    // create new mongoDBClient
    const client = new MongoClient(uri);
    let obj = {
        ...data,
        createdAt: getTime(),
        timestamp: getTimeUnix(),
        isActive: true,
        lastUpdateAt: getTimeUnix(),
        updatedBy: 'admin'
    }
    try {
        // Connect the client to the servers
        await client.connect();
        // establich and verify the connection status
        const result = await client.db(dbName).collection(collectionName).insertOne({ ...obj });
        // l.info(`${this.constructor.name}.insertOne(${result})`);
        return result;
    } catch (error) {
        // l.info(`${this.constructor.name}.insertOne(${error})`);
    } finally {
        await client.close();
    }

    /// then and promise method to insert into Db
    // MongoClient.connect(process.env.MONGODB_URL, function (err, db) {
    //     if (err) throw err;
    //     var dbo = db.db(process.env.MONGODB);
    //     let obj = {
    //         ...data,
    //         createdAt: commonServices.getTime(),
    //         timestamp: commonServices.getTimeUnix()
    //     }
    //     dbo.collection(collectionName).insertOne({ ...obj }, async function (err, result) {
    //         if (err) {
    //             db.close();
    //             l.info(`${this.constructor.name}.joinBetaIndex(${err})`);
    //             return res.status(404).send({ success: false, message: "join beta failed" });
    //         } else {
    //             db.close();
    //             return 1;
    //         }
    //     });
    // });
}

async function appendDb(dbName, collectionName, findBy, data) {

    // mongoDb atlas url
    const uri = url;
    // create new mongoDBClient
    const client = new MongoClient(uri);
    try {
        // Connect the client to the servers
        await client.connect();
        // establich and verify the connection status
        const result = await client.db(dbName).collection(collectionName).updateOne(
            findBy,
            { $set: data },
            { upsert: true }
        );
        // l.info(`${this.constructor.name}.updateOne(${result})`);
        return result;
    } catch (error) {
        // l.info(`${this.constructor.name}.updateOne(${error})`);
    } finally {
        await client.close();
    }
}

// PUSH to array
async function pushItemCollection(dbName, collectionName, findBy, data) {

    console.log(data)
    // mongoDb atlas url
    const uri = url;
    // create new mongoDBClient
    const client = new MongoClient(uri);
    try {
        // Connect the client to the servers
        await client.connect();
        // establich and verify the connection status
        const result = await client.db(dbName).collection(collectionName).updateOne(
            { contact: "03157122173" },
            { $push: { "item": [{ "item": "01" }] } },
            // { upsert: true }
        );
        // l.info(`${this.constructor.name}.updateOne(${result})`);
        return result;
    } catch (error) {
        // l.info(`${this.constructor.name}.updateOne(${error})`);
    } finally {
        await client.close();
    }
}
async function aggregate(dbName, collectionName, data) {

    // mongoDb atlas url
    const uri = url;
    // create new mongoDBClient
    const client = new MongoClient(uri);


    try {
        // Connect the client to the servers
        await client.connect();
        // establich and verify the connection status
        // { $group: { _id: null, count: { $sum: 1 } } }
        console.log(data)
        const result = await client.db(dbName).collection(collectionName).aggregate(data);
        console.log(result)
        // l.info(`${this.constructor.name}.aggregate(${result})`);
        return result;
    } catch (error) {
        // l.info(`${this.constructor.name}.aggregate(${error})`);
    } finally {
        await client.close();
    }
}

async function deleteOne(dbName, collectionName, data) {

    // mongoDb atlas url
    const uri = url;
    // create new mongoDBClient
    const client = new MongoClient(uri);


    try {
        // Connect the client to the servers
        await client.connect();
        // establich and verify the connection status
        // { $group: { _id: null, count: { $sum: 1 } } }
        console.log(data)
        const result = await client.db(dbName).collection(collectionName).deleteOne(data);
        console.log(result)
        // l.info(`${this.constructor.name}.aggregate(${result})`);
        return result;
    } catch (error) {
        // l.info(`${this.constructor.name}.aggregate(${error})`);
    } finally {
        await client.close();
    }
}



// find existing user
async function findOne(db, collectionName, data, sort, limit) {
    // mongoDb atlas url
    const uri = url;
    // create new mongoDBClient
    const client = new MongoClient(uri, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
    });
    try {
        // Connect the client to the servers
        await client.connect();
        // establich and verify the connection status
        var result = await client.db(db).collection(collectionName).find(data).sort(sort).limit(limit).toArray()
        // console.log(result);
        return result;
    } catch (error) {
        // l.info(`crudService.findOne(${error})`);
    } finally {
        await client.close();
    }
    // promise method to fetch the data from MongoDb
    // let client;
    //  MongoClient.connect(process.env.MONGODB_URL, function (err, db) {
    //     if (err) throw err;
    //     var dbo = db.db(process.env.MONGODB);
    //     return  dbo.collection(collectionName).findOne(data)
    //    .then(result => {
    //         if (result) {
    //             db.close();
    //             result = JSON.stringify(result)
    //             console.log(`Successfully found document: ${result}.`);
    //             return 1;
    //         } else {
    //             db.close();
    //             console.log("No document matches the provided query.");
    //         }

    //     }).catch(err => console.error(`Failed to find document: ${err}`));
    // });
}

async function find(db, collectionName, data) {
    // mongoDb atlas url
    const uri = url;
    // create new mongoDBClient
    const client = new MongoClient(uri, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
    });
    try {
        // Connect the client to the servers
        await client.connect();
        // establich and verify the connection status
        var result = await client.db(db).collection(collectionName).find(data).toArray()
        // console.log(result);
        return result;
    } catch (error) {
        // l.info(`crudService.findOne(${error})`);
    } finally {
        await client.close();
    }
}
async function pingMongoDb() {
    // mongoDb atlas url
    const uri = process.env.MONGODB_URL;
    // create new mongoDBClient
    const client = new MongoClient(uri);
    async function run() {
        try {
            // Connect the client to the servers
            await client.connect();
            // establich and verify the connection status
            await client.db(db).collection("anc").findOne({ ping: 1 });
            console.log("connected successfully to MongoDbServer");
            return 1;
        } finally {
            await client.close();
        }
    }
    run().catch(console.dir);
}


module.exports = {
    findOne,
    aggregate,
    appendDb,
    insertOne,
    pingMongoDb,
    insertMany,
    pushItemCollection,
    deleteOne
}