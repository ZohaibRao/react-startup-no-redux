const { MongoClient } = require('mongodb');

export const appendData =  (collectionName, ) => {
// this module is the for adding data to mongoDb
}