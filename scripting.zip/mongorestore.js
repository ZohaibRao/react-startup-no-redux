/**
 * this scripts create the back up of the given mongo Atlas url,
 * and save it locally and upload the backup to s3 backupDb bucket,
 */
 const cron = require('node-cron'), spawn = require('child_process').spawn;
 //const spawn = require('child_process').spawn
 const sThree =  require('./services/aws-services');
 const AWS = require('aws-sdk');
 var fs = require("fs");
 const moment = require('moment');
 
 
 //let cmd = 'mongodump --uri mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2_test';
 
 let backupProcess = spawn('mongorestore', [
    '--uri=mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net',
    '--gzip',
    '--db mongodb_practice',
    '--verbose',
    '--archive=./database-backup/mim_v2_test.gz',
 ]);
 
 backupProcess.on('exit', (code, signal) => {
   if(code){ 
       console.log('restore process exited with code ', code);
     }
   else if (signal)
       console.error('restore process was killed with singal ', signal);
//    else
//      fs.readFile('./database-backup/mim_v2_test.gzip', (err, data)=>{
//        if (err) console.log('error in reading this file: ', err);
//        //console.log('obtained file:', data);
//       try{
//        sThree.uploadBinaryFile(data,  moment(Date.now() ).format('MMDDYYYY-hmmss') + '-mim_v2_test-backkupfile')
//       }catch(err){
//         console.log(err)
//       }
//    })
       console.log('Successfully backedup the database')
 });