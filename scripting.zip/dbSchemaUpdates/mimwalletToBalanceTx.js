

const { MongoClient } = require('mongodb');
const { findOne, appendDb } = require('../crud/crud-services');
const moment = require('moment');
const { DataExchange } = require('aws-sdk');
let client;
var url = 'mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2_prod_live?retryWrites=true&w=majority';
let result;


lastImpactivity = {
  date: new Date().getTime(),
  type: "OPEN VOUCHER"
}

let actionLogObject;
const dbFindOperation = async () => {
  try {
    result = await findOne("mim_v2_prod_live", "banktransactions", {})

    result = result.forEach(async (x, index) => {

      if (x.moduleName === "wallet") {
        x.moduleName === "wallet" ? x.moduleName = "mim balance" : x.moduleName = x.moduleName;  // change the carts to wallet to mim balance
        !x.transactionDetail.isWalletRecharge ? x.transactionDetail.isMIMBalanceRecharge = true : x.transactionDetail.isMIMBalanceRecharge = x.transactionDetail.isMIMBalanceRecharge;
        x.transactionDetail.isWalletRecharge == true ? x.transactionDetail.isMIMBalanceRecharge = true : x.transactionDetail.isMIMBalanceRecharge = x.transactionDetail.isMIMBalanceRecharge;
        await appendDb("mim_v2_prod_live", "banktransactions", { _id: x._id }, x);
      }
      console.log("requestNo: ", index, "updated")
      // return ;
    })
    //  result.filter((x)=>{

    // })
    console.log(result)
  } catch (error) {
    console.log(error)
  }
}
// find impactees with
dbFindOperation();

