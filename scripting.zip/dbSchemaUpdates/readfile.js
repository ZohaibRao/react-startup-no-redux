const fs = require('fs');


const readStream = fs.createReadStream("./ids.txt", { encoding: 'UTF-8' });

readStream.on('data', function (data) {
    // This just pipes the read stream to the response object (which goes to the client)
    // readStream.pipe(console.log(data));
    console.log(data)
});