

const { MongoClient } = require('mongodb');
const { findOne, appendDb } = require('../crud/crud-services');
const moment = require('moment');
const { DataExchange } = require('aws-sdk');
let client;
var url = 'mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2_test?retryWrites=true&w=majority';
let result;


lastImpactivity = {
  date: new Date().getTime(),
  type: "OPEN VOUCHER"
}

let actionLogObject;
const dbFindOperation = async () => {
  try {
    result = await findOne("mim_v2_prod_live", "carts", {})

    result = result.forEach(async (x, index) => {

      x.moduleName === "wallet" ? x.moduleName = "mim balance" : x.moduleName = x.moduleName;  // change the carts to wallet to mim balance
      await appendDb("mim_v2_prod_live", "carts", { _id: x._id }, x);
      console.log("requestNo: ", index, "udpated")
      // return ;
    })
    //  result.filter((x)=>{

    // })
    console.log(result)
  } catch (error) {
    console.log(error)
  }
}
// find impactees with
dbFindOperation();

