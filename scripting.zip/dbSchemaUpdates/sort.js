const arr1 = [1, 2, 3, 4, 5];
const arr2 = [1, 2, 3]

// for (let i = 0; i < arr1.length; i++) {
//     for (let j = 0; j < arr2.length; j++) {
//         if (arr2[j] !== arr1[j]) {
//             console.log(arr1[j])
//         }
//     }
// }

var final = arr1.filter(function (item) {
    return !arr2.includes(item);
})

console.log(final)
