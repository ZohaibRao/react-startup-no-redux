const axios = require('axios').default;


  // GET request for remote image in node.js
//   try {
      
//       axios({
//           method: 'get',
//           url: 'http://127.0.0.1:3005/api/v2/grocery/getSellingPref',
//           headers: {'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2MWQyOGJhZTIyOGM2NzE4ZmM2NjA4YjMiLCJjb250YWN0IjoiMDMxNTQzNzczMTciLCJNT0RVTEUiOiJHUk9DRVJZIiwiaWF0IjoxNjQxMjc5MTYyLCJleHAiOjE2NDEzMjIzNjJ9.L6mKIbG4mC3P1QQOJOjgUeGu8WVogmClomxCsrUyoio'}
//         })
//           .then(function (response) {
//           //   response.data.pipe(fs.createWriteStream('ada_lovelace.jpg'))
//           console.log(response.data)
//           });
//   } catch (error) {
//       console.log(error)
      
//   }

// const data ={
//     "impactor": {
//       "id": "61bb055df40b3c0ff8b18e8f",
//       "name": "Zohaib"
//     },
//     "impactee": {
//       "id": "61bb31a28f585e1c840d4229",
//       "name": "Zohaib baba",
//       "cnic":"363031443605",
//       "contact":"03154377317"
       
//     },
//     "requestType": "BUNDLE",
//     "bundleId": "61360171be824d37a0ec23bb",
//     "bundlePrice": "150",
//     "qtyOfBundles": 1
//   }


const st = new Date().getTime();
let et;
for(let i=0; i<1000; i++){
  try {
    axios({
        method: 'GET',
        url: 'http://3.133.161.23:5000/api/v2/admin/',
        //headers: {'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2MWJiMDU1ZGY0MGIzYzBmZjhiMThlOGYiLCJjb250YWN0IjoiMDMxNTQzNzczMTciLCJNT0RVTEUiOiJJTVBBQ1RPUiIsImlhdCI6MTY0MTI3ODM3NSwiZXhwIjoxNjQxMzIxNTc1fQ.ADr2SjlBIDrjctkXDxWnMKax2IJz8LJXYMi0x9QqJvY'},
        //data
    })
        .then(function (response) {
        //   response.data.pipe(fs.createWriteStream('ada_lovelace.jpg'))
        console.log(response.data)
         et = new Date().getTime() - st;
         console.log("time"+et , 'iteration No.'+ i)
         
    }) 
} catch (error) {
    console.log(error)
}
}




