const { MongoClient } = require('mongodb');
let client;


var url = 'mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2_test?retryWrites=true&w=majority';

// MongoClient.connect(url, function(err, db) {
//     if (err) throw err;
//     var dbo = db.db("mim_v2_test");
//     dbo.collection("impactors").findOne({}, function(err, result) {
//       if (err) throw err;
//       console.log(result);
//       db.close();
//     });
//   });


const obj=[
    {
        isVerified: true,
        isFirstTimeUser: true,
        logout: false,
        accountDeleted: false,
        requestRef: [],
        role: 'impactor',
        impacteeRef: [ ("61bb31a28f585e1c840d4229") ],
        impactorWallet: 0,
        userName: 'zohaib',
        contact: '03154377317',
        password: 'z5U9utHRWoYXoibki73LrtdgruVnLw==',
        createdAt: '12/16/2021, 7:22:36 pm',
        timestamp: '1639664556810',
        lastModified: '1639664556810',
      },
      {
        isVerified: true,
        isFirstTimeUser: true,
        logout: false,
        accountDeleted: false,
        requestRef: [],
        role: 'impactor',
        impacteeRef: [ ("61bb31a28f585e1c840d4229") ],
        impactorWallet: 0,
        userName: 'zohaib',
        contact: '03154377317',
        password: 'z5U9utHRWoYXoibki73LrtdgruVnLw==',
        createdAt: '12/16/2021, 7:22:36 pm',
        timestamp: '1639664556810',
        lastModified: '1639664556810',
      },
      {
        isVerified: true,
        isFirstTimeUser: true,
        logout: false,
        accountDeleted: false,
        requestRef: [],
        role: 'impactor',
        impacteeRef: [ ("61bb31a28f585e1c840d4229") ],
        impactorWallet: 0,
        userName: 'zohaib',
        contact: '03154377317',
        password: 'z5U9utHRWoYXoibki73LrtdgruVnLw==',
        createdAt: '12/16/2021, 7:22:36 pm',
        timestamp: '1639664556810',
        lastModified: '1639664556810',
      },
      {
        isVerified: true,
        isFirstTimeUser: true,
        logout: false,
        accountDeleted: false,
        requestRef: [],
        role: 'impactor',
        impacteeRef: [ ("61bb31a28f585e1c840d4229") ],
        impactorWallet: 0,
        userName: 'zohaib',
        contact: '03154377317',
        password: 'z5U9utHRWoYXoibki73LrtdgruVnLw==',
        createdAt: '12/16/2021, 7:22:36 pm',
        timestamp: '1639664556810',
        lastModified: '1639664556810',
      },
      {
        isVerified: true,
        isFirstTimeUser: true,
        logout: false,
        accountDeleted: false,
        requestRef: [],
        role: 'impactor',
        impacteeRef: [ ("61bb31a28f585e1c840d4229") ],
        impactorWallet: 0,
        userName: 'zohaib',
        contact: '03154377317',
        password: 'z5U9utHRWoYXoibki73LrtdgruVnLw==',
        createdAt: '12/16/2021, 7:22:36 pm',
        timestamp: '1639664556810',
        lastModified: '1639664556810',
      },
      {
        isVerified: true,
        isFirstTimeUser: true,
        logout: false,
        accountDeleted: false,
        requestRef: [],
        role: 'impactor',
        impacteeRef: [ ("61bb31a28f585e1c840d4229") ],
        impactorWallet: 0,
        userName: 'zohaib',
        contact: '03154377317',
        password: 'z5U9utHRWoYXoibki73LrtdgruVnLw==',
        createdAt: '12/16/2021, 7:22:36 pm',
        timestamp: '1639664556810',
        lastModified: '1639664556810',
      },
      {
        isVerified: true,
        isFirstTimeUser: true,
        logout: false,
        accountDeleted: false,
        requestRef: [],
        role: 'impactor',
        impacteeRef: [ ("61bb31a28f585e1c840d4229") ],
        impactorWallet: 0,
        userName: 'zohaib',
        contact: '03154377317',
        password: 'z5U9utHRWoYXoibki73LrtdgruVnLw==',
        createdAt: '12/16/2021, 7:22:36 pm',
        timestamp: '1639664556810',
        lastModified: '1639664556810',
      },
      {
        isVerified: true,
        isFirstTimeUser: true,
        logout: false,
        accountDeleted: false,
        requestRef: [],
        role: 'impactor',
        impacteeRef: [ ("61bb31a28f585e1c840d4229") ],
        impactorWallet: 0,
        userName: 'zohaib',
        contact: '03154377317',
        password: 'z5U9utHRWoYXoibki73LrtdgruVnLw==',
        createdAt: '12/16/2021, 7:22:36 pm',
        timestamp: '1639664556810',
        lastModified: '1639664556810',
      },
      {
        isVerified: true,
        isFirstTimeUser: true,
        logout: false,
        accountDeleted: false,
        requestRef: [],
        role: 'impactor',
        impacteeRef: [ ("61bb31a28f585e1c840d4229") ],
        impactorWallet: 0,
        userName: 'zohaib',
        contact: '03154377317',
        password: 'z5U9utHRWoYXoibki73LrtdgruVnLw==',
        createdAt: '12/16/2021, 7:22:36 pm',
        timestamp: '1639664556810',
        lastModified: '1639664556810',
      },
      

]

MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("mim_v2_test");
    dbo.collection("impactors").insertMany( obj,  function(err, result) {
      if (err) throw err;
      console.log(result);
      db.close();
    });
  });
  
// async function connectdb() {
   
//     client = new MongoClient(url);
//     try {
//         // Connect to the MongoDB cluster
//         await client.connect();
//         console.log('connected with db')

//         //await  listDatabases(client);
//         // Make the appropriate DB calls
//         await listOfCollections(client);
//         //await findCollections(client)
//     } catch (e) {
//         console.error(e);
//     } finally {
//         await client.close();
//     }
// }

// connectdb().catch(console.error);

// async function listDatabases() {
//     try {
//         databasesList = await client.db().admin().listDatabases();
//         console.log("Databases:");
//         databasesList.databases.forEach(db => console.log(` - ${db.name}`));

//     } catch (err) {
//         console.log('facing this error:', err)
//     }
// }

// const listOfCollections = async (client)=>{

//     var cursor = await client.db("mim_v2_test").getCollectionsNames();
//     //console.log(cursor)
//     cursor.each(function(err, doc) {

//         console.log(doc);

//     });

// // const findCollections = async (client)=>{
// //     var findData = await client.
// // }
// }