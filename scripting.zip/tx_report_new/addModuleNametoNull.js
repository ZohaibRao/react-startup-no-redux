

const { MongoClient } = require('mongodb');
const { findOne, appendDb, insertOne, insertMany } = require('../crud/crud-services');
const moment = require('moment');
const { DataExchange } = require('aws-sdk');
let client;
var url = 'mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2_test?retryWrites=true&w=majority';
let result;


lastImpactivity = {
  date: new Date().getTime(),
  type: "OPEN VOUCHER"
}


/*
GUEST USER SCHEMA 
fullName: 'Kanwal Cheema',
    email: 'kanwal@myimpactmeter.com',
    mobileNumber: '03225001983',
    moduleName: 'FR',
    ngoName: '',
    transactionId: 'FR1663776436287',
    totalAmount: 500,
    mimShare: 51.25,
    createdBy: 'ipg-admin',
    createdAt: '1663776559871',
    updatedBy: '',
    lastUpdatedAt: '',
    isActive: true,
    status: '',
    IsRegistered: false,
    supplier: { type: 'fr_ngo', name: 'alkhidmat' },
    userId: '',
    packName: 'Emergency medicine - Rs 500',
    packQuantity: 1,
    dateTime: '21/09/2022, 04:09:19',
    paymentInit: false,
    paymentComplete: false,
    paymentInitDate: '',
    paymentCompleteDate: '',
    instrumentNo: '',
    remarks: '',
    userType: 'Guest',
    payableAmount: 448.75,
*/

let actionLogObject;
const dbFindOperation = async () => {
  try {
    // result = await findOne("mim_v2_prod_live", "tx_reports", { "transactionId": "FR1663776436287" })
    let txReports = [];

    let set = new Set();
    let arr = [];


    let frCarts = await findOne("mim_v2_prod_live", "banktransactions", { moduleName: null }, {}, 0) // find the carts request



    console.log(frCarts.length) // 122890
    // // txReports = await findOne("mim_v2_prod_live", "tx_reports_test", {}, 0)   // get all tx_reports requests

    // let index = 0;

    frCarts.forEach(async (x, index) => {
      
      x.modulName = "GROCERY" ? x.moduleName = "GROCERY" : x.moduleName = x.moduleName;
      await appendDb("mim_v2_prod_live", "banktransactions", { _id: x._id }, x);
    })


    // INSERT NEW DATA
    // // let txReportsTest = await findOne("mim_v2_prod_live", "tx_reports_test", {})  // find the carts request

    // try {
    //   txReports.forEach(async (x, index) => {

    //     await insertOne("mim_v2_prod_live", "tx_reports_test", x)

    //     console.log("inserted: ", index)
    //   })


    // } catch (error) {
    //   console.log(error)
    // }

  } catch (error) {
    console.log(error)
  }
}
// find impactees with
dbFindOperation();

