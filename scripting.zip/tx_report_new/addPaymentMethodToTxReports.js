

const { MongoClient } = require('mongodb');
const { findOne, appendDb, insertOne, insertMany } = require('../crud/crud-services');
const moment = require('moment');
const { DataExchange } = require('aws-sdk');
let client;
var url = 'mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2_test?retryWrites=true&w=majority';
let result;


let actionLogObject;
const dbFindOperation = async () => {
    try {
        // result = await findOne("mim_v2_prod_live", "tx_reports", { "transactionId": "FR1663776436287" })
        let txReports;

        let set = new Set();
        let arr = [];

        // $and: [{ isActive: false }, { moduleName: "FR" }]
        let result = await findOne("mim_v2_prod_live", "tx_reports", {}, {}, 0) // find the carts request
        let subResult;


        // let FRcarts = await findOne("mim_v2_prod_live", "tx_reports", { "transactionId": "FRAKMCM00003t094" })  // find the carts request
        // console.log(frCarts.)

        let sum = 0;
        result.forEach(async (x, index) => {
            subResult = await findOne("mim_v2_prod_live", "banktransactions", { requestId: x.transactionId }, {}, 0) // find the carts request
            console.log("reqeustId: ", x.transactionId, " paymentMethod: ", subResult[0].transactionDetail.paymentMethod)
            !x.paymentMethod ? x.paymentMethod = subResult[0].transactionDetail.paymentMethod : x.paymentMethod = x.paymentMethod;
            await appendDb("mim_v2_prod_live", "tx_reports", { _id: x._id }, x);
        })

        // console.log(sum, frCarts.length) // 122890
        // txReports = await findOne("mim_v2_prod_live", "tx_reports_test", {}, 0)   // get all tx_reports requests



    } catch (error) {
        console.log(error)
    }
}
// find impactees with
dbFindOperation();

