

const { MongoClient } = require('mongodb');
const { deleteOne, appendDb } = require('../crud/crud-services');
const moment = require('moment');
const { DataExchange } = require('aws-sdk');
const mongoose = require('mongoose');
const { forEach } = require('lodash');
let client;
var url = 'mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2_test?retryWrites=true&w=majority';
let result;


let actionLogObject;
const dbFindOperation = async () => {
    try {


        // mongoDb atlas url
        const uri = url;
        // create new mongoDBClient
        const client = new MongoClient(uri);


        try {
            // Connect the client to the servers
            await client.connect();

            const db = "mim_v2_test";
            const col = "requestforgroceries";
            const unixTime = Date.now().toString();

            let UpdateQuery = {
                requestStatus: "paid",
                voucherRedeemDate: unixTime,
                lastUpdatedAt: unixTime,
                updatedBy: "admin",
                bundleDeliveryDate: unixTime
            }
            const result = await client.db("mim_v2_test").collection("impactees").find({}).toArray();
            console.log(result.length);



            result.forEach(async (x) => {
                !x.profileImage ? x.profileImage = {
                    "location": "",
                    "key": ""
                } : x.profileImage;

                !x.reference ? x.reference = {
                    "type": "self",
                    "name": "",
                    id: "",
                } : x.reference;
                await appendDb("mim_v2_test", "impactees", { _id: x._id }, x)
            })






            // console.log(result.leng)

            // result.forEach((x) => {
            //     console.log(x.requestId)
            // })

            // establich and verify the connection status
            // { $group: { _id: null, count: { $sum: 1 } } } 

            // G100000rJ623
            // const result = await client.db("mim_v2_prod_live").collection("impactors").findOne({ _id: mongoose.Types.ObjectId("62bb06320c0030003af37394" }).toArray();

            // const result = await client.db("mim_v2_prod_live").collection("impactors").findOne({ _id: mongoose.Types.ObjectId("62bb06320c0030003af37394") }).populate("impacteeRef").exec((err, doc) => {

            //     if (err) { return console.error(err); }
            //     console.log(doc);
            //     return conn.close();
            // });

            // console.log(result);


            // await deleteOne("mim_v2_test", "schools", { _id: result._id });
            // await result.save();
            // await appendDb("mim_v2_test", "impactors", { _id: result._id }, result);
            // console.log("length: ", result.impactorBuddies)
            // result.forEach(async (x, index) => {
            //     await deleteOne("mim_v2_test", "voc_institutes", { _id: x._id });
            //     // console.log((x).toString())
            //     // await deleteOne("mim_v2_test", "appnotifications", { _id: x._id });
            //     //  await appendDb("mim_v2_test", "impactors", { impactorBuddies: x });
            // })

        } catch (error) {
            console.log(error)

        } finally {
            await client.close();
        }


    } catch (error) {
        console.log(error)
    }



}


// find impactees with
dbFindOperation();

