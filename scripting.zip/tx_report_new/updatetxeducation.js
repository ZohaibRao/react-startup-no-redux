
/*
update the transactions of education it should contain userId.

*/
const { MongoClient } = require('mongodb');
const { deleteOne, appendDb } = require('../crud/crud-services');
const moment = require('moment');
const { DataExchange } = require('aws-sdk');
const mongoose = require('mongoose');
let client;
var url = 'mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2_test?retryWrites=true&w=majority';
let result;


let actionLogObject;
const dbFindOperation = async () => {
    try {


        // mongoDb atlas url
        const uri = url;
        // create new mongoDBClient
        const client = new MongoClient(uri);


        try {
            // Connect the client to the servers
            await client.connect();
            // establich and verify the connection status
            const result = await client.db("mim_v2_test").collection("requestforschools").find({ "impactor._id": "633fa4c4b6de0d00390876f0" }).toArray();
            // const result = await client.db("mim_v2_test").collection("appnotifications").find({ isActive: true }).toArray();

            console.log("length: ", result.length)


            // await result.save();
            // await appendDb("mim_v2_test", "impactors", { _id: result._id }, result);
            // console.log("length: ", result.impactorBuddies)
            result.forEach(async (x, index) => {
                console.log(x.requestId)
                let tempTx = await client.db("mim_v2_test").collection("banktransactions").findOne({ "requestId": x.requestId });
                // await deleteOne("mim_v2_test", "banktransactions", { _id: x._id });
                !tempTx.userId ? tempTx.userId = x.impactor._id : tempTx.userId;
                await appendDb("mim_v2_test", "banktransactions", { _id: tempTx._id }, tempTx);
            })

        } catch (error) {
            console.log(error)

        } finally {
            // client.close();
        }


    } catch (error) {
        console.log(error)
    }



}


// find impactees with
dbFindOperation();

