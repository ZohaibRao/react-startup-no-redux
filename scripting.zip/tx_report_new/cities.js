

const { MongoClient } = require('mongodb');
const { findOne, appendDb, insertOne, insertMany } = require('../crud/crud-services');
const moment = require('moment');
const { DataExchange } = require('aws-sdk');
let client;
var url = 'mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2_test?retryWrites=true&w=majority';
let result;


let actionLogObject;
const dbFindOperation = async () => {
    try {
        // result = await findOne("mim_v2_prod_live", "tx_reports", { "transactionId": "FR1663776436287" })
        let txReports = [];

        let set = new Set();
        let arr = [];


        let citiesList = await findOne("mim_v2_test", "cities", { id: "PKPBWP" }, {}, 0) // find the carts request



        console.log(citiesList, citiesList.length) // 122890
        let lahore = [];

        // citiesList.forEach(async (x, index) => {
        //     x.name = x.name.split(" - ")[1];
        //     //console.log(x.name.split(" - ")[1])
        //     x.parentId = "PKPBWP";
        //     // console.log(x)
        //     // x.modulName = "GROCERY" ? x.moduleName = "GROCERY" : x.moduleName = x.moduleName;
        //     await appendDb("mim_v2_test", "cities", { _id: x._id }, x);
        // })


    } catch (error) {
        console.log(error)
    }
}
// find impactees with
dbFindOperation();

