

const { MongoClient } = require('mongodb');
const { findOne, appendDb, insertOne, insertMany, aggregate } = require('../crud/crud-services');
const moment = require('moment');
const { DataExchange } = require('aws-sdk');
const mongoose = require('mongoose');
let client;
var url = 'mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2_test?retryWrites=true&w=majority';
let result;


lastImpactivity = {
  date: new Date().getTime(),
  type: "OPEN VOUCHER"
}



let actionLogObject;
const dbFindOperation = async () => {
  try {


    // mongoDb atlas url
    const uri = url;
    // create new mongoDBClient
    const client = new MongoClient(uri);


    try {
      // Connect the client to the servers
      await client.connect();
      // establich and verify the connection status
      // { $group: { _id: null, count: { $sum: 1 } } }

      const result = await client.db("mim_v2_prod_live").collection("requestforgroceries").aggregate([{
        "$match": {
          storeId: mongoose.Types.ObjectId("62fdd570ac2fad003a55a354")
        }
      },
      {
        "$group": {
          "_id": null,
          "total": { "$sum": `$bundlePrice` },
          "mimShare": { "$sum": { $toDouble: `$mimShareAmount` } },
          "number_of_counts": { "$sum": 1 }
        }
      }]).toArray()

      // "total": { "$sum": `$amount` },
      // return result;
      console.log("Sajid Karyana: ", result, "payAbleAmount: ", result[0].total - result[0].mimShare)
    } catch (error) {
      console.log(error)

    } finally {
      await client.close();
    }


  } catch (error) {
    console.log(error)
  }



}


// find impactees with
dbFindOperation();

