

const { MongoClient } = require('mongodb');
const { findOne, appendDb, insertOne, insertMany } = require('../crud/crud-services');
const moment = require('moment');
const { DataExchange } = require('aws-sdk');
let client;
var url = 'mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2_test?retryWrites=true&w=majority';
let result;


lastImpactivity = {
  date: new Date().getTime(),
  type: "OPEN VOUCHER"
}


/*
GUEST USER SCHEMA 
fullName: 'Kanwal Cheema',
    email: 'kanwal@myimpactmeter.com',
    mobileNumber: '03225001983',
    moduleName: 'FR',
    ngoName: '',
    transactionId: 'FR1663776436287',
    totalAmount: 500,
    mimShare: 51.25,
    createdBy: 'ipg-admin',
    createdAt: '1663776559871',
    updatedBy: '',
    lastUpdatedAt: '',
    isActive: true,
    status: '',
    IsRegistered: false,
    supplier: { type: 'fr_ngo', name: 'alkhidmat' },
    userId: '',
    packName: 'Emergency medicine - Rs 500',
    packQuantity: 1,
    dateTime: '21/09/2022, 04:09:19',
    paymentInit: false,
    paymentComplete: false,
    paymentInitDate: '',
    paymentCompleteDate: '',
    instrumentNo: '',
    remarks: '',
    userType: 'Guest',
    payableAmount: 448.75,
*/

let actionLogObject;
const dbFindOperation = async () => {
  try {
    // result = await findOne("mim_v2_prod_live", "tx_reports", { "transactionId": "FR1663776436287" })
    let txReports = [];

    let set = new Set();
    let arr = [
      "FRAKMCF000038881",
      "FRAKMCW000033626",
      "FRAKMCF000032469",
      "FRAKMEM00003G729"
    ];



    //1.  Find the requests in tx_reports  that doesnt present in the fr_carts these are updated one. 

    //2. find the fr_carts which are isActive : false

    // 3. loop throgh all fr_carts element and  find if any of tx_reports element present in the fr_carts ( not matching elem)

    // 4. insert all those element which are not present in fr_carts in the tx_reports.


    // application of ALGO
    //1.  Find the requests in tx_reports  that doesnt present in the fr_carts these are updated one. 
    let frCarts = await findOne("mim_v2_prod_live", "carts", { $and: [{ moduleName: "FR" }, { isActive: false }] }, { createdAt: 1 }, 49) // find the carts request
    // let FRcarts = await findOne("mim_v2_prod_live", "tx_reports", { "transactionId": "FRAKMCM00003t094" })  // find the carts request


    // console.log(frCarts) //

    // let sum = 0;
    // frCarts.forEach((x, index) => {
    //   sum = sum + x.amount;
    // })

    // console.log(sum, frCarts.length) // 122890

    // txReports = await findOne("mim_v2_prod_live", "tx_reports_test", {}, 0)   // get all tx_reports requests

    // let index = 0;

    frCarts.forEach((x, index) => {

      let schema = {
        fullName: "",
        email: "",
        mobileNumber: "",
        moduleName: 'FR',
        ngoName: '',
        transactionId: x.requestId,
        totalAmount: x.amount,
        mimShare: x.mimShareAmount,
        createdBy: 'ipg-admin',
        createdAt: Date.now(),
        updatedBy: 'manual script',
        lastUpdatedAt: Date.now(),
        isActive: true,
        status: '',
        IsRegistered: true,
        supplier: { type: 'fr_ngo', name: 'alkhidmat' },
        impactor: {
          fullName: x.impactor.name,
          userId: x.impactor._id,
          email: x.impactor.email,
          mobileNumber: x.impactor.contact
        },
        userId: '',
        packName: !x.item.name ? "" : x.item.name,
        packQuantity: x.item.qty,
        dateTime: moment(Date.now()).format('DD/MM/YYYY, hh:mm:ss'),
        paymentInit: false,
        paymentComplete: false,
        paymentInitDate: '',
        paymentCompleteDate: '',
        instrumentNo: '',
        remarks: '',
        userType: 'Impactor',
        payableAmount: x.amount - x.mimShareAmount,
      }

      txReports.push(schema);

      // if (x.requestId.toString() !== y.toString()) {

      //   }
      // arr.forEach((y, index) => {

      // })
    })

    // // console.log(txReports)

    //  let txReportsTest = await findOne("mim_v2_prod_live", "tx_reports_test", {},{},0)  // find the carts request

    try {
      txReports.forEach(async (x, index) => {

        await insertOne("mim_v2_prod_live", "tx_reports_test_2", x)

        console.log("inserted: ", index)
      })


    } catch (error) {
      console.log(error)
    }


    /* we have common elements in arr  = []
    read all element of the frCarts element and insert it in the tx_reports
    alog: 
    fr_carts = 10;
    tx_reports = 7;
    common_elements = 2
    10-2 = 8 need to insert.
    8+7 = 15 element will placed to tx_reports
    */

    /*
    // tx_reports
    

    //
    _id: new ObjectId("632c1875154b720039494ab6"),
    isActive: false,
    createdBy: 'impactor',
    createdAt: '1663834229391',
    updatedBy: '',
    lastUpdatedAt: '',
    authToken: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2MzFmMzAxMjAzNzMyNDAwM2E1MzcyYjciLCJlbWFpbCI6InNpZHJhQG15aW1wYWN0bWV0ZXIuY29tIiwidXNlck5hbWUiOiJTaWRyYSIsIk1PRFVMRSI6IkZSIiwicmVxdWVzdE1vZHVsZSI6ImltcGFjdG9yIiwibW9kdWxlVHlwZSI6ImltcGFjdG9yIiwiaWF0IjoxNjYzODM0MjI1LCJleHAiOjE2NjQwOTM0MjV9.DcsmWQqTDjUaq5T7JXe8_BJviyCz7onJA3im5sm5eyg',
    userId: '631f3012037324003a5372b7',
    requestId: 'FRAKMCM00003t094',
    impactPoints: '35.44722',
    goldRate: '399883.56173147674',
    mimSharePercent: 10.25,
    mimShareAmount: 51.25,
    moduleName: 'FR',
    amount: 500,
    impactor: {
      _id: '631f3012037324003a5372b7',
      email: 'sidra@myimpactmeter.com',
      name: 'Sidra',
      contact: '+923359188991',
      profileImage: [Object]
    },
    ngo: {
      ngoName: 'alkhidmat',
      ngoCode: 'AKM',
      moduleName: 'FR',
      contact: '03234345489',
      email: 'web@alkhidmat.org'
    },
    item: {
      code: 'CM',
      id: 11,
      name: 'Contribution for Masjid Rehabilitation - Rs 500',
      amount: 500,
      qty: 1
    },
    __v: 0,
    sessionId: 'SESSION0002073532816N8395914F95',
    successIndicator: '47a7aace7c374e9a',
    version: 'ed0c221601'
  }


  {
    _id: new ObjectId("632c1920f2a010003c1d498c"),
    fullName: '',
    email: '',
    mobileNumber: '',
    moduleName: 'FR',
    ngoName: '',
    transactionId: 'FRAKMCM00003t094',
    totalAmount: 500,
    mimShare: 51.25,
    createdBy: 'ipg-admin',
    createdAt: '1663834400433',
    updatedBy: '',
    lastUpdatedAt: '',
    isActive: true,
    status: '',
    IsRegistered: true,
    impactor: {
      fullName: 'Sidra',
      userId: '631f3012037324003a5372b7',
      email: 'sidra@myimpactmeter.com',
      mobileNumber: '+923359188991'
    },
    supplier: { type: 'fr_ngo', name: 'alkhidmat' },
    packName: 'Contribution for Masjid Rehabilitation - Rs 500',
    packQuantity: 1,
    dateTime: '22/09/2022, 08:13:20',
    paymentInit: false,
    paymentComplete: false,
    paymentInitDate: '',
    paymentCompleteDate: '',
    instrumentNo: '',
    remarks: '',
    userType: 'Impactor',
    payableAmount: 448.75,
    __v: 0
  }

    */

  } catch (error) {
    console.log(error)
  }
}
// find impactees with
dbFindOperation();

