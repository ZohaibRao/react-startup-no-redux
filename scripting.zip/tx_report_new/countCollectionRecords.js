

const { MongoClient } = require('mongodb');
const { findOne, appendDb, insertOne, insertMany } = require('../crud/crud-services');
const moment = require('moment');
const { DataExchange } = require('aws-sdk');
let client;
var url = 'mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2_test?retryWrites=true&w=majority';
let result;


lastImpactivity = {
  date: new Date().getTime(),
  type: "OPEN VOUCHER"
}


/*
GUEST USER SCHEMA 
fullName: 'Kanwal Cheema',
    email: 'kanwal@myimpactmeter.com',
    mobileNumber: '03225001983',
    moduleName: 'FR',
    ngoName: '',
    transactionId: 'FR1663776436287',
    totalAmount: 500,
    mimShare: 51.25,
    createdBy: 'ipg-admin',
    createdAt: '1663776559871',
    updatedBy: '',
    lastUpdatedAt: '',
    isActive: true,
    status: '',
    IsRegistered: false,
    supplier: { type: 'fr_ngo', name: 'alkhidmat' },
    userId: '',
    packName: 'Emergency medicine - Rs 500',
    packQuantity: 1,
    dateTime: '21/09/2022, 04:09:19',
    paymentInit: false,
    paymentComplete: false,
    paymentInitDate: '',
    paymentCompleteDate: '',
    instrumentNo: '',
    remarks: '',
    userType: 'Guest',
    payableAmount: 448.75,
*/

let actionLogObject;
const dbFindOperation = async () => {
  try {
    // result = await findOne("mim_v2_prod_live", "tx_reports", { "transactionId": "FR1663776436287" })
    let txReports = [];

    let set = new Set();
    let arr = [];



    //1.  Find the requests in tx_reports  that doesnt present in the fr_carts these are updated one. 

    //2. find the fr_carts which are isActive : false

    // 3. loop throgh all fr_carts element and  find if any of tx_reports element present in the fr_carts ( not matching elem)

    // 4. insert all those element which are not present in fr_carts in the tx_reports.


    // application of ALGO
    //1.  Find the requests in tx_reports  that doesnt present in the fr_carts these are updated one. 
    let frCarts = await findOne("mim_v2_prod_live", "fr_carts", { isActive: false }, { createdAt: 1 }, 10)  // find the carts request
    // txReports = await findOne("mim_v2_prod_live", "tx_reports", {})   // get all tx_reports requests

    // // fetch the common item from the collections 
    // frCarts.forEach((y, index) => {
    //   txReports.forEach((x, index) => {
    //     if (y.requestId.toString() === x.transactionId.toString()) {
    //       arr.push(y.requestId)
    //     }
    //   })
    // })


    /* we have common elements in arr  = []
    read all element of the frCarts element and insert it in the tx_reports
    alog: 
    fr_carts = 10;
    tx_reports = 7;
    common_elements = 2
    10-2 = 8 need to insert.
    8+7 = 15 element will placed to tx_reports
    */

    frCarts.forEach((x, index) => {
      let schema = {
        fullName: x.name,
        email: x.email,
        mobileNumber: x.contact,
        moduleName: 'FR',
        ngoName: '',
        transactionId: x.requestId,
        totalAmount: x.amount,
        mimShare: x.amount * .1025,
        createdBy: 'ipg-admin',
        createdAt: Date.now(),
        updatedBy: 'manual script',
        lastUpdatedAt: Date.now(),
        isActive: true,
        status: '',
        IsRegistered: false,
        supplier: { type: 'fr_ngo', name: 'alkhidmat' },
        userId: '',
        packName: !x.itemName ? "" : x.itemName,
        packQuantity: x.itemQty,
        dateTime: moment(Date.now()).format('DD/MM/YYYY, hh:mm:ss'),
        paymentInit: false,
        paymentComplete: false,
        paymentInitDate: '',
        paymentCompleteDate: '',
        instrumentNo: '',
        remarks: '',
        userType: 'Guest',
        payableAmount: x.amount - x.amount * .1025,
      }

      txReports.push(schema);
      // arr.forEach((y, index) => {
      //   if (x.requestId.toString() !== y.toString()) {

      //   }
      // })
    })


    // let txReportsTest = await findOne("mim_v2_prod_live", "tx_reports_test", {})  // find the carts request

    try {
      txReports.forEach(async (x, index) => {

        await insertOne("mim_v2_prod_live", "tx_reports_test_2", x)

        console.log("inserted: ", index)
      })


    } catch (error) {
      console.log(error)
    }



    // txReports = txReports.map((x, index) => {
    //   return x.transactionId.toString();
    // })

    // console.log("tx_reports", txReports)


    // frCarts.forEach((y, index) => {
    //   txReports.forEach((x, index) => {
    //     if (y.requestId.toString() !== x.toString()) {
    //       console.log(y.requestId)
    //       // !arr.includes(y.transactionId) ? arr.push(y.requestId) : arr;
    //       // set.add(y.requestId)
    //     }
    //   })

    //   // x.requestId.toString() !== y.transactionId.toString() ? set.add(x.requestId) : arr;
    //   // console.log()
    //   // set.add(y.transactionId, x.requestId)
    //   // console.log((y.transactionId).toString(), (x.requestId).toString())

    // })

    // console.log("fr_carts", set.size, set.values(), arr, arr.length)

    //2. find the fr_carts which are isActive : false

    // 3. loop throgh all fr_carts element and  find if any of tx_reports element present in the fr_carts ( not matching elem)

    // 4. insert all those element which are not present in fr_carts in the tx_reports.


    // txReports.forEach(async (x, index) => {

    //   x.requestId.toString() !== "FR1663776436287" ? arr.push(x) : arr;
    //   // console.log(txReports.includes())
    //   // result.forEach((y, index) => {
    //   //   // console.log()
    //   //   set.add(y.transactionId, x.requestId)
    //   //   console.log((y.transactionId).toString(), (x.requestId).toString())

    //   // })
    // })


    // console.log("fr_cart having tx_reports in common ", arr.length)


    // result = result.forEach(async (x, index) => {

    //   x.moduleName === "wallet" ? x.moduleName = "mim balance" : x.moduleName = x.moduleName;  // change the carts to wallet to mim balance
    //   await appendDb("mim_v2_prod_live", "carts", { _id: x._id }, x);
    //   console.log("requestNo: ", index, "udpated")
    //   // return ;
    // })
    //  result.filter((x)=>{

    // })
    // console.log(txReports.length)
  } catch (error) {
    console.log(error)
  }
}
// find impactees with
dbFindOperation();

