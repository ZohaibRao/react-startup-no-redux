

const { MongoClient } = require('mongodb');
const { findOne, appendDb, insertOne, insertMany } = require('../crud/crud-services');
const moment = require('moment');
const { DataExchange } = require('aws-sdk');
const mongoose = require('mongoose');
let client;

let result;


lastImpactivity = {
  date: new Date().getTime(),
  type: "OPEN VOUCHER"
}


/*
GUEST USER SCHEMA 
fullName: 'Kanwal Cheema',
    email: 'kanwal@myimpactmeter.com',
    mobileNumber: '03225001983',
    moduleName: 'FR',
    ngoName: '',
    transactionId: 'FR1663776436287',
    totalAmount: 500,
    mimShare: 51.25,
    createdBy: 'ipg-admin',
    createdAt: '1663776559871',
    updatedBy: '',
    lastUpdatedAt: '',
    isActive: true,
    status: '',
    IsRegistered: false,
    supplier: { type: 'fr_ngo', name: 'alkhidmat' },
    userId: '',
    packName: 'Emergency medicine - Rs 500',
    packQuantity: 1,
    dateTime: '21/09/2022, 04:09:19',
    paymentInit: false,
    paymentComplete: false,
    paymentInitDate: '',
    paymentCompleteDate: '',
    instrumentNo: '',
    remarks: '',
    userType: 'Guest',
    payableAmount: 448.75,
*/

let actionLogObject;
const dbFindOperation = async () => {

  // result = await findOne("mim_v2_prod_live", "tx_reports", { "transactionId": "FR1663776436287" })
  let txReports = [];

  let set = new Set();
  let arr = [

  ];



  //1.  Find the requests in tx_reports  that doesnt present in the fr_carts these are updated one. 

  //2. find the fr_carts which are isActive : false

  // 3. loop throgh all fr_carts element and  find if any of tx_reports element present in the fr_carts ( not matching elem)

  // 4. insert all those element which are not present in fr_carts in the tx_reports.


  // application of ALGO
  /*
                          impactor: {
                              fullName: ifCartItemFound.impactor.name,
                              userId: ifCartItemFound.impactor._id,
                              email: ifCartItemFound.impactor.email,
                              mobileNumber: ifCartItemFound.impactor.contact,
                          },
                          impactee: {},
                          supplier: {
                              type: "fr_ngo",
                              name: (ifCartItemFound.ngo.ngoName).toString().toLowerCase(),
                          },
                          packName: ifCartItemFound.item.name,
                          packQuantity: ifCartItemFound.item.qty,
                          dateTime: moment(Date.now()).format('DD/MM/YYYY, HH:mm:ss'),  //date
                          moduleName: ifCartItemFound.moduleName,

                          transactionId: ifCartItemFound.requestId,
                          totalAmount: ifCartItemFound.amount,
                          mimShare: ifCartItemFound.mimShareAmount,
                          createdAt: commonServices.getTimeUnix(),
                          paymentInit: false,
                          paymentComplete: false,
                          paymentInitDate: "",
                          paymentCompleteDate: "",
                          instrumentNo: "",
                          remarks: "",
                          IsRegistered: true,
                          userType: "Impactor",
                          payableAmount: ifCartItemFound.amount - ifCartItemFound.mimShareAmount,
                          paymentMethod: "BAF CARD"

  */
  //1.  Find the requests in tx_reports  that doesnt present in the fr_carts these are updated one. 

  var url = 'mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2_test?retryWrites=true&w=majority';
  const client = new MongoClient(url, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });

  try {

    // create mongoose model
    const requestForGroceriesSchema = new mongoose.Schema({

    })


    const uri = url;
    // create new mongoDBClient

    // Connect the client to the servers
    await client.connect();
    var frCarts = await client.db("mim_v2_prod_live").collection("requestforgroceries").find({ storeId: mongoose.Types.ObjectId("62fdd570ac2fad003a55a354") }).toArray();
    console.log(frCarts.length)


    // OPERATIONS on FOUND DATA 
    // frCarts.forEach((x, index) => {

    //   if (x.isAppChargesIncluded == true) {
    //     let schema = {
    //       moduleName: 'GROCERY',
    //       transactionId: x.requestId,
    //       totalAmount: x.amount,
    //       mimShare: x.mimShareAmount,
    //       createdBy: 'ipg-admin',
    //       createdAt: Date.now(),
    //       updatedBy: 'manual script',
    //       lastUpdatedAt: Date.now(),
    //       isActive: true,
    //       status: '',
    //       IsRegistered: true,
    //       supplier: { type: 'grocery', name:  },
    //       impactor: {
    //         fullName: x.impactor.name,
    //         userId: x.impactor._id,
    //         email: x.impactor.email,
    //         mobileNumber: x.impactor.contact
    //       },
    //       userId: '',
    //       packName: !x.item.name ? "" : x.item.name,
    //       packQuantity: x.item.qty,
    //       dateTime: moment(Date.now()).format('DD/MM/YYYY, hh:mm:ss'),
    //       paymentInit: false,
    //       paymentComplete: false,
    //       paymentInitDate: '',
    //       paymentCompleteDate: '',
    //       instrumentNo: '',
    //       remarks: '',
    //       userType: 'Impactor',
    //       payableAmount: x.amount - x.mimShareAmount,
    //     }
    //   } else {

    //   }

    //   txReports.push(schema);
    // })


    // INSERT DATA IN NEW TABLE

    // txReports.forEach(async (x, index) => {

    //   await insertOne("mim_v2_prod_live", "tx_reports_grocery_test", x)

    //   console.log("inserted: ", index)
    // })


  } catch (error) {
    console.log(error)
    // l.info(`crudService.findOne(${error})`);
  } finally {
    await client.close();
  }


  /* we have common elements in arr  = []
  read all element of the frCarts element and insert it in the tx_reports
  alog: 
  fr_carts = 10;
  tx_reports = 7;
  common_elements = 2
  10-2 = 8 need to insert.
  8+7 = 15 element will placed to tx_reports
  */
}
// find impactees with
dbFindOperation();

