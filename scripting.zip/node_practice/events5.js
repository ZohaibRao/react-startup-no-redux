// node event loop and timer
setTimeout((sec)=>{
    console.log('time '+ sec);
},1000, 'abc');