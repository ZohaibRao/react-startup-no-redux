// understanding the call back concept//
//as we know call back is a function that is executed when the function has finished 
// its execution (latter in simple word)

// latter in what manner --> when all processing is done
// why use it, you put heavy processing part of application in call back function
// callback function is used for Asynchrounous 

// var fs = require("fs");
// const timeStart = new Date().getTime();
// const str = 'A quick brown fox';
// var data = fs.readFile('E:/image processing/sundus/9-21-17/matlab files/SRM.m', (err,data)=>{
//     // put all heavy computation here
//     if(err) return console.log(err.stack);
//     //console.log(data.toString());
//     fs.writeFile('./time.txt', data, ()=>{
//         console.log('this is a call back functions');
//     });
//     console.log('this is a calling function to callback');
// })
// const timeEnd = new Date().getTime();
// const interval = timeEnd - timeStart;
// console.log('time taken '+ interval);
// console.log("progarm ended");

// Blocking
var fs = require("fs");
const timeStart = new Date().getTime();
var data = fs.readFileSync('E:/image processing/sundus/9-21-17/matlab files/SRM.m');
//console.log(data.toString());
//fs.writeFileSync('./newInput.txt',data);
console.log('line 1 ');
console.log('line 2'); 

 
