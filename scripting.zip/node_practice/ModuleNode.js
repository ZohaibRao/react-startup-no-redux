// module is same like javascripts libraries
// set of functions you want to include in you app
// Built-in-Module
var http = require("http");
const timeDate = require("./ModuleExport");

http.createServer(function(req, resp){
    resp.writeHead(200,{'Content-Type' : 'text/html'});
    resp.write("current time "+ timeDate.myDateTime() );     // url of client is sent here i.e resp.write(req.url)
    resp.write(" Hehy" +timeDate.abc() );
    resp.end();
    
}).listen(8081);