/*
var fs = requrie("fs")
Synchronous Vs Asynchronous
every method in the fs is sync and async both,
Async: method takes last parameters as completion callback method adn
file parameter of the call back function and first parameter of callback is error
Sync: block execution 
Async: dosnt block the execution
*/
// Asynchronous Mode
// Following is the syntax of the method to open a file in asynchronous mode
/*
fs.open(path, flags[, mode], callback)
path:
flags: Flags indicate the behavior of the file to be opened. All possible values have been mentioned below.
{
    	
r Open file for reading. An exception occurs if the file does not exist.
r+ Open file for reading and writing. An exception occurs if the file does not exist.
rs Open file for reading in synchronous mode
rs+ Open file for reading and writing, asking the OS to open it synchronously. See notes for 'rs' about using this with caution.
w Open file for writing. The file is created (if it does not exist) or truncated (if it exists).
wx Like 'w' but fails if the path exists.
w+ Open file for reading and writing. The file is created (if it does not exist) or truncated (if it exists).
wx+ Like 'w+' but fails if path exists
a Open file for appending. The file is created if it does not exist.
ax Like 'a' but fails if the path exists.
a+ Open file for reading and appending. The file is created if it does not exist.
ax+ Like 'a+' but fails if the the path exists

}
Mode: t sets the file mode (permission and sticky bits), but only if the file was created. It defaults to 0666, readable and writeable.
callback: This is the callback function which gets two arguments (err, fd).

*Get File Information
fs.stat(path, callback)
Parameters
Here is the description of the parameters used:
path: this is the string having file name including path
This is the callback function which gets two arguments (err, stats) where stats is an object of fs.Stats type which is printed below in the example.
apart from the important attributes which are printed below in the example, 
there are several useful methods available in fs.Stats class
which can be used to check file type. These methods are given in the following table

stats.isFile()
Returns true if file type of a simple file.

stats.isDirectory()
Returns true if file type of a directory.

	
stats.isBlockDevice()
Returns true if file type of a block device.

stats.isCharacterDevice()
Returns true if file type of a character device.

stats.isSymbolicLink()
Returns true if file type of a symbolic link.

stats.isFIFO()
Returns true if file type of a FIFO.

stats.isSocket()
Returns true if file type of asocket.

*/
//var fs = require("fs");

// fs.readFile('fileSys.txt', function(err,data){
//     if(err){
//         console.log(error.stack);
//     }
//     console.log("Asynchronous read" + data.toString());
    
// })
// Synchronous method

// var data = fs.readFileSync('fileSys.txt',);
// console.log("this is Synchronous way of reading file."+ data.toString());

// var fs = require("fs");
//     fs.stat('fileSys.txt', function(err, stat){
//         if(err){
//             console.log(error.stack);
//         }
//         console.log(stat);
//         console.log("Got file state successfully");

//         // now check the file state

//         console.log("is file ? "+stat.isFile());
//         console.log("is file ? "+stat.isDirectory());
//     });

/*
Writing the file
fs.writeFile(filename, data[, options], callback)
This method will over-write the file if the file already exists.
If you want to write into an existing file then you should use another method available.
Parameters:
Here is the description of the parameters used −
Path: This is the string having the file name including path;
data: This is the String or Buffer to be written into the file.
Options: The third parameter is an object which will hold {encoding, mode, flag}. 
By default. encoding is utf8, mode is octal value 0666. and flag is 'w'
callback:  This is the callback function which gets a single parameter err that returns an error in case of any writing error.

*/

// var fs = require("fs");

// console.log("Going to write into existing file");
// fs.writeFile('input.txt', 'Simply Easy Learning!', function(err) {
//    if (err) {
//       return console.error(err);
//    }
   
//    console.log("Data written successfully!");
//    console.log("Let's read newly written data");
   
//    fs.readFile('input.txt', function (err, data) {
//       if (err) {
//          return console.error(err);
//       }
//       console.log("Asynchronous read: " + data.toString());
//    });   
// });

//***************** Reading a File ****************************//

/*
fs.read(fd, buffer, offset, length, position, callback)
another methods availble to read the file
Parameters:
fd: This is the file descriptor returned by fs.open().
buffer: This is the buffer that the data will be written to
offset: This is the offset in the buffer to start writing at
length: This is an integer specifying the number of bytes to read
position: This is an integer specifying where to begin reading from in the file. If position is null, data will be read from the current file position
callback: This is the callback function which gets the three arguments, (err, bytesRead, buffer).

*/
// var fs = require("fs");
// var buf = new Buffer(1024);

// console.log("Going to open an existing file");
// fs.open('fileSys.txt', 'r+', function(err, fd) {
//    if (err) {
//       return console.error(err);
//    }
//    console.log("File opened successfully!");
//    console.log("Going to read the file");
   
//    fs.read(fd, buf, 0, buf.length, 0, function(err, bytes){
//       if (err){
//          console.log(err);
//       }
//       console.log(bytes + " bytes read");
      
//       // Print only read bytes to avoid junk.
//       if(bytes > 0){
//          console.log(buf.slice(0, bytes).toString());
//       }
//    });
// });

// ***************Closing a File********************
/**
 * fs.close(fd, callback)
 * parameters:
 * fd: This is the file descriptor returned by file fs.open() method
 * callback: This is the callback function No arguments other than a possible exception are given to the completion callback.
 * 
 */

// var fs = require("fs");
// var buf = new Buffer(1024);

// console.log("Going to open an existing file");
// fs.open('fileSys.txt', 'r+', function(err, fd) {
//    if (err) {
//       return console.error(err);
//    }
//    console.log("File opened successfully!");
//    console.log("Going to read the file");
   
//    fs.read(fd, buf, 0, buf.length, 0, function(err, bytes) {
//       if (err) {
//          console.log(err);
//       }

//       // Print only read bytes to avoid junk.
//       if(bytes > 0) {
//          console.log(buf.slice(0, bytes).toString());
//       }

//       // Close the opened file.
//       fs.close(fd, function(err) {
//          if (err) {
//             console.log(err);
//          } 
//          console.log("File closed successfully.");
//       });
//    });
// });

// ****************** Truncate a File *******************/

/*
fs.ftruncate(fd, len, callback)
parameters 
fd: This is the file descriptor returned by fs.open()
len: This is the length of the file after which the file will be truncated
callback: This is the callback function No arguments other than a possible exception are given to the completion callback.

 */
// var fs = require("fs");
// var buf = new Buffer(1024);

// console.log("Going to open an existing file");
// fs.open('fileSys.txt', 'r+', function(err, fd) {
//    if (err) {
//       return console.error(err);
//    }
//    console.log("File opened successfully!");
//    console.log("Going to truncate the file after 20 bytes");
   
//    // Truncate the opened file.
//    fs.ftruncate(fd, 10, function(err) {
//       if (err) {
//          console.log(err);
//       } 
//       console.log("File truncated successfully.");
//       console.log("Going to read the same file"); 
      
//       fs.read(fd, buf, 0, buf.length, 0, function(err, bytes){
//          if (err) {
//             console.log(err);
//          }

//          // Print only read bytes to avoid junk.
//          if(bytes > 0) {
//             console.log(buf.slice(0, bytes).toString());
//          }
//          // Close the opened file.
//          fs.close(fd, function(err) {
//             if (err) {
//                console.log(err);
//             } 
//             console.log("File closed successfully.");
//          });
//       });
//    });
// });

// *********** Delete a File ************* //
/*
fs.unlink(path, callback)
Parameters:
path:  This is the file name including path.
callback: This is the callback function No arguments other than a possible exception are given to the completion callback.

*/

// var fs = require("fs");

// console.log("Going to delete an existing file");
// fs.unlink('Del.txt', function(err) {
//    if (err) {
//       return console.error(err);
//    }
//    console.log("File deleted successfully!");
// });

// ************* Create a Directory **************//

/**
  fs.mkdir(path[, mode], callback)
  parameters:
  path: This is the directory name including path
  mode: This is the directory permission to be set. Defaults to 0777
  callback: This is the callback function No arguments other than a possible exception are given to the completion callback.
var fs = require("fs");

console.log("Going to create directory /tmp/test");
fs.mkdir('/tmp/test',function(err) {
   if (err) {
      return console.error(err);
   }
   console.log("Directory created successfully!");
});
 */

 // ************ Read Directory **********/
 /* 
 fs.readdir(path, callback)
 Parameters
 path: This is the directory name including path.
 callback: This is the callback function which gets two arguments (err, files) where files is an array of the names of the files in the directory excluding '.' and '..'.

 //example:
var fs = require("fs");
console.log("Going to read directory /tmp");
fs.readdir("/tmp/",function(err, files) {
   if (err) {
      return console.error(err);
   }
   files.forEach( function (file) {
      console.log( file );
   });
});
 */
//**********  Remove a Directory     ********** //
 /*
 fs.rmdir(path, callback)
 path: This is the directory name including path.
 callback: This is the callback function No arguments other than a possible exception are given to the completion callback.
 //example
 var fs = require("fs");

console.log("Going to delete directory /tmp/test");
fs.rmdir("/tmp/test",function(err) {
   if (err) {
      return console.error(err);
   }
   console.log("Going to read directory /tmp");
   
   fs.readdir("/tmp/",function(err, files) {
      if (err) {
         return console.error(err);
      }
      files.forEach( function (file) {
         console.log( file );
      });
   });
});

///append file
var fs = require('fs');

fs.appendFile('mynewfile1.txt', 'Hello content!', function (err) {
  if (err) throw err;
  console.log('Saved!');
});
 */
var fs = require("fs")
fs.readFile('imageName.txt', function (err, data) {
   if (err) console.log( err);

   // Encode to base64
   var encodedImage = new Buffer.from(data, 'binary').toString('base64');

   console.log(typeof(encodedImage))
   //console.log(encodedImage)
   // Decode from base64
   var decodedImage = new Buffer.from(encodedImage, 'base64')
   fs.writeFileSync('imageName.png', decodedImage);
   console.log(typeof(decodedImage))
   //console.log(decodedImage)
});
