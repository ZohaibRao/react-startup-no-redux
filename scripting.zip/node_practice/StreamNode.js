// Stream are the object that let you read the Data from Source / Write the Data to Destination in continuous fashion
// obj for Read and Write the data Continous faschion
// in Node 4 types of Stream 
// 1. Readable --stream for read object 
// 2. Writeable --write objec
// 3. Duplex -- for both operation
// 4. Transfromabel -- is duplex in which output is computed on given object
/*
Each type of Stream is an EventEmitter instance and throws several events at different instance of times. For example, some of the commonly used events are −

data − This event is fired when there is data is available to read.

end − This event is fired when there is no more data to read.

error − This event is fired when there is any error receiving or writing data.

finish − This event is fired when all the data has been flushed to underlying system.

This tutorial provides a basic understanding of the commonly used operations on Streams.
 */

 // example for Reader Stream
//  var fs = require("fs");
//  var data = " ";
//  var readerStream = fs.ReadStream('fileRead.txt')

//  readerStream.setEncoding("UTF8");
// readerStream.on('data',function(chunks){
//     data += chunks;
// })

// readerStream.on('end', function(){
//     console.log(data);
// })

// readerStream.on('error',function(err){
//     console.log(err.stack);
// })
// console.log("prgram Ended");


// WriteStream Example 

// var fs = require("fs");
// var data = "this is wrting from Node terminal staright into file using Writing Stram";

// var writerStream = fs.createWriteStream('writeFile.txt');

// writerStream.write(data); // write the data and formate
// writerStream.end(); // mark the end of file

// //handle stream Eventa  --> finsh and error
// writerStream.on('finsih', function(){
//     console.log("data writtern is completed");
// })

// writerStream.on('error', function(err){
//     console.log(err.stack);
// })

// console.log("file wirtten is completed Succesfully");

// piping

// piping is the mechanisim to put ReadStream into input of other steram

var fs = require("fs");

//create a readablesteam
var readerStream = fs.ReadStream("fileRead.txt");
//create a writeable steram
var writerStream = fs.WriteStream("writeFile.txt");

//piping
//read the input.txt and write data to output.txt
readerStream.pipe(writerStream);
console.log("program of Piping is ended");


// Chaining the Streams
/*
Chaining is a mechanism to connect the output of one stream to another stream and 
create a chain of multiple stream operations. 
It is normally used with piping operations. 
Now we'll use piping and chaining to first compress a file and then decompress the same.

*/
// followin example of chaining and piping Stream

var fs = require("fs");
var zlib = require("zlib"); // from compressing operations

// compress the file input.tx to input.tx.gz
// fs.createReadStream('fileRead.txt')
//     .pipe(zlib.createGzip())
//     .pipe(fs.createWriteStream('input.txt.gz'));

// console.log("program is ended and file is compressed Successfully");
// now read the compressed file and decompress file it

fs.createReadStream('input.txt.gz')
    .pipe(zlib.createGunzip())
    .pipe(fs.createWriteStream('decompress.txt'));
console.log("file is decompressed");