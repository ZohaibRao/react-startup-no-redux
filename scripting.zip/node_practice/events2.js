// event program for maths operations

var event = require('events');
var em = new event.EventEmitter();
//handler for addition
var addTwoNumbers = function(a,b){
    console.log(a+b);
}
//handler for multiplication
var mulTwoNumbers = function(a,b){
    console.log(a*b);
}

// Register events

em.on('addition', addTwoNumbers);
em.on('mul', mulTwoNumbers);
// fire these events which is called emits
em.emit('addition', 2,2);
em.emit('mul', 9,2);


