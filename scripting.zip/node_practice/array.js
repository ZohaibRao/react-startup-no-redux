const arr = ['hello', 'wolrd','becasue this works'];

const Func = (...arrayObj)=>{
    return arrayObj;
}

console.log(Func(arr));