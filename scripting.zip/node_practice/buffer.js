/*  WHAT IS Node Buffer
    --A buffer is an area of memory.-- JavaScript developers are not familiar with this concept, much less than C, C++ or Go developers (or any programmer that uses a system programming language), which interact with memory every day.
    It represents a fixed-size chunk of memory (can’t be resized) allocated outside of the V8 JavaScript engine.
    You can think of a buffer like an array of integers, which each represent a byte of data. 8bits
    It is implemented by the Node Buffer class.

    --Buffers were introduced to help developers deal with binary data,-- in an ecosystem that traditionally only dealt with strings rather than binaries.
    Buffers are deeply linked with streams.
    When a stream processor receives data faster than it can digest, it puts the data in a buffer.
     i.e-- A simple visualization of a buffer is when you are watching a YouTube video and the red line goes beyond your visualization point: you are downloading data faster than you’re viewing it, and your browser buffers it.

     Pure JavaScript is Unicode friendly, but it is not so for binary data. While dealing with TCP streams or the file system, it's necessary to handle octet streams. Node provides Buffer class which provides instances to store raw data similar to an array of integers but corresponds to a raw memory allocation outside the V8 heap.
    Buffer class is a global class that can be accessed in an application without importing the buffer module.
    Notice that if you initialize a buffer with a number that sets its size, you’ll get access to pre-initialized memory that will contain random data, not an empty buffer!
    TCP strams and file system we need Buffer and node provide Buffer class to deal with
*/

// const buf = Buffer.from('Hey');
// console.log(buf[0])
// console.log(buf[1]);
// console.log(buf[2]);
// console.log(buf.toString());
// console.log(buf.length);

// for( const item of buf){
//     console.log(item);
// }

// const buf2 = Buffer.alloc(5)
// buf2.write('Allah')
// console.log(buf2.toString());
// //changing the content
// var buf3 = Buffer.from('Hey!');
// buf3[1] = 111 //o
// console.log(buf3.toString()) //Hoy!

//Copy a buffer
//Copying a buffer is possible using the copy() method:
// let copyBuf = Buffer.alloc(5);
// buf2.copy(copyBuf);
// console.log(copyBuf.toString());


// var buff = Buffer.alloc(4);
// buff.write("a");

// for( const item of buff){
//     console.log(item);
// }


/* 
Buffer.from(array)
BUffer.from(arrayBuffer[, byteOffset[,length]])
Buffer.from(buffer)
Buffer.from(string[, encoding]);
const buf = Buffer.alloc(1024);
const buf = Buffer.allocUnsafe(1024); --> buffer of size 1024KB 

*using buffer 
** accessing content of buffer**
const buff = Buffer.from("Hey")
console.log(buff[0]);
console.log(buff[1]);
console.log(buff[2]);




*/

// buff = new Buffer(256);
// len = buff.write("Simply Easy Ledfasdflnsdf,ndsa,fmndsam,fnds,fndsarning");

// console.log("Octets written : "+  len);
// DeprecationWarning: Buffer() is deprecated due to security and usability issues. Please use the Buffer.alloc(), Buffer.allocUnsafe(), or Buffer.from() methods instead.

//*length of buffer


 'use strict';
 let a = [1,2,3];
 let b = Buffer.from(a);
 console.log(b);

 let a2 = new Uint8Array([1,2,3]);
 let b2 = Buffer.from(a2);

 console.log(b2);

 let b3 = Buffer.alloc(10);
 console.log(b3);
 let b4 = Buffer.allocUnsafe(10);
 console.log(b4);

 let buf = new Buffer.from('this is my pretty example');
 let json = JSON.stringify(buf); // buffer to json
 console.log(json);

 let buf2 = new Buffer.from(JSON.parse(json).data); // parsing to buffer from given json
 //console.log(buf2.toString()); // this is my pretty example UFT8 by defaults
 //console.log(buf2.toString('ascii')); 
 console.log(buf2.toString('utf8',9,20)); //utf8 and cutting 

 let buff = new Buffer.alloc(4);
 buff.writeUInt8(0x63,0);
 buff.writeUInt8(0x61,1);
 buff.writeUInt8(0x74,2);
 buff.writeUInt8(0x75,3);


 