//its an explaination of Call back concept
// CALLBACK is a function that is called upon completion of a given task
// node is designed in such a way it support heavily callback
// following example of Text file Reading using call back funtion
// in call back first arg. is error and Second is data
// callabck function is passed as last parameter
// two ways Blocking and Non Blocking way

// Blocking
// var fs = require("fs");
// const timeStart = new Date().getTime();
// var data = fs.readFileSync('E:/image processing/sundus/9-21-17/matlab files/SRM.m');
// //console.log(data.toString());
// fs.writeFileSync('./newInput.txt',data);
// const endTime = new Date().getTime();
// const interval =  endTime - timeStart;
// console.log('time taken '+ interval); 

/*From the above output, we can say that for the first “Program started…” is printed, then the file content is printed and then, the "Program Ended" is printed. Here, the file is big and takes 9-10 seconds to read this text file. Thus, this program goes into the awaited state during reading of the file. No other operation is executed during this time. This is executed at the next instruction. So, it is called synchronous method. */

//Non Blocking
// var fs = require("fs");
// var data = fs.readFileSync('G:/BlockchainWorkspace/nodePractice/fileRead.txt', function(err, data){
//     if(err) return console.error(err);
//     console.log(data.toString());
// })

/* A function in NodeJS is either synchronous or asynchronous 
*/

var fs = require("fs");
const timeStart = new Date().getTime();
const str = 'A quick brown fox';
var data = fs.readFile('E:/image processing/sundus/9-21-17/matlab files/SRM.m', (err,data)=>{
    
    if(err) return console.log(err.stack);
    //console.log(data.toString());
    fs.writeFile('./time.txt', data, ()=>{
        console.log('this is a call back functions');
    });
    console.log('this is a calling function to callback');
})
const timeEnd = new Date().getTime();
const interval = timeEnd - timeStart;
console.log('time taken '+ interval);
console.log("progarm ended");
//console.log(str);


