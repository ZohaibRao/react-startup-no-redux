/* 
node is runtime environmet for executing javascript code
node is V8 engine that include module that gives us the capabilities that 
not inside browsers i.e we can work with file system, networks etc
it is V8 engine writter in c++ so Node.exe 
Both Chrome V8 and Node.exe engine both shares same JavaScript engine but provides different
Run time Environmet JavaScripts 

Blockin / Synchronous Architecture
Non Blocking / Synchronous Architecture

NON Blocking: in this Architecture single thread allocated to handle all the request
Node moniters the queue if the response occure it upadate accordingly.
its highly recommended for I/O intensive, data intensive or                                                                                                                                                                                                                                         e
dont use for CPU intensive Arc, i.e vedio encoding and image manipulation 

in node we dont have windows / Document objects these are the part of runtime environment
so we have global.setTime to access these windows element we availbel in 

working as module
difference between Interfaces and implementation details
make module, and exports its certain variable and functions to available to others
require module in order to import it
 in adavcned node js we can use 'const' instear 'var' i.e const abc = require('abc');
 it saves us from making run time error of accidently changing the value
*/
/*  WHAT IS Node Buffer
    --A buffer is an area of memory.-- JavaScript developers are not familiar with this concept, much less than C, C++ or Go developers (or any programmer that uses a system programming language), which interact with memory every day.
    It represents a fixed-size chunk of memory (can’t be resized) allocated outside of the V8 JavaScript engine.
    You can think of a buffer like an array of integers, which each represent a byte of data.
    It is implemented by the Node Buffer class.

    --Buffers were introduced to help developers deal with binary data,-- in an ecosystem that traditionally only dealt with strings rather than binaries.
    Buffers are deeply linked with streams.
    When a stream processor receives data faster than it can digest, it puts the data in a buffer.
     i.e-- A simple visualization of a buffer is when you are watching a YouTube video and the red line goes beyond your visualization point: you are downloading data faster than you’re viewing it, and your browser buffers it.

     Pure JavaScript is Unicode friendly, but it is not so for binary data. While dealing with TCP streams or the file system, it's necessary to handle octet streams. Node provides Buffer class which provides instances to store raw data similar to an array of integers but corresponds to a raw memory allocation outside the V8 heap.
    Buffer class is a global class that can be accessed in an application without importing the buffer module.
*/



const text = '[ "Ford", "BMW", "Audi", "Fiat" ]';
const myArr = JSON.parse(text)
console.log(text, myArr)
