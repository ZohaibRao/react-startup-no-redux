//events 3  handling file using events

var event = require('events');
const em  = new event.EventEmitter();
var fs =  require('fs');
// now i am going to open a file using events
// suppose i have to do alot of work 

// write open file handler

var openFile = (path)=>{
    var data = fs.readFile(path, ()=>{
        console.log('okay');
    });
    return data;
}

// register events

em.on('file', openFile);

// fire the emit and give the location

abc = em.emit('file',openFile('./decompress.txt'));

console.log(abc.toString());