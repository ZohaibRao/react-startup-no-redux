const event = require('events');
var emtterEvent = new event.EventEmitter(); 
//const emitter = new EventEmiter();


// register an event
// emtterEvent.on('messageLogged', function(){
//     console.log('messageLogged listner called')
// })
// //secont emitter
// emtterEvent.on('messageLogged', function(){
//     console.log('messageLogged listner called')
// })
// //third event
// emtterEvent.on('messageLogged', function(){
//     console.log('messageLogged listner called')
// })

var myEventHandler = function(){
    console.log("I hear a scream");
}

// asign events to your Event Handler

emtterEvent.on("Scream",myEventHandler);
 //fire event
 emtterEvent.emit("Scream");

// raise and event
//emtterEvent.emit('messageLogged');