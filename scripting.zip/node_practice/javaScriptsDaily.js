// var thisObje = {
//     name: {firstName: 'zoahib', lastName:'nasir'},
//     contact: {cell:'03154377317', email:'zohaibrao007@outlook.com'}
// } // ES6

// var a = ["a", "b", "c"];
// a.forEach(function(entry) {
//     console.log(entry);
// });

// var fruits = ["Banana", "Orange", "Apple", "Mango"];

// console.log(fruits.sort());
// console.log(fruits.length);

// var person = {
//     firstName: "John",
//     lastName: "Doe",
//     age: 50,
//     eyeColor: "blue"
// };
// var person = {
//     firstName: "John",
//     lastName : "Doe",
//     id       : 5566,
//     fullName : function() {
//       return this.firstName + " " + this.lastName;
//     }
//   };

  // text 
  var txt = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
var sln = txt.length;

const obj = [
    {firstName: 'zoahib', lastName:'nasir'},
    {cell:'03154377317', email:'zohaibrao007@outlook.com'}
]





//Arrays
var cars = [
    "Saab",
    "Volvo",
    "BMW"
  ];

//console.log(obj.map(x => x.firstName));

// foreach(car in cars){
//     console.log(firstName)
// }

//cars.map( console.log(car => car.toUpperCase));

console.log(cars.map(x => x));

//var dateNow = new Date().dateNow;
var dateInMilli = Date.now(); //dateNow/1000;
var dateInMilli2 = new Date()/1000;

console.log(dateInMilli+ " "+ dateInMilli2);

console.log(new Date(dateInMilli2 * 1000).getFullYear());

console.log(new Date( dateInMilli2 * 1000).getDay());

console.log(Math.PI);
console.log(Math.E);

console.log(Math.random()*10);
console.log(Math.floor(Math.random()*10));

var age = Number(9)
console.log(isNaN(age));


let language = "JavaScript";
let text = "";

for (let x of language) {
text += x ;
}

console.log(text);

var bool = false;

console.log(typeof(false.toString()))

const datee = new Date();
console.log(datee.toString())

console.log(dateInMilli2.toString().trim())

console.log(Number(false))

d = new Date();
Number(d)          // returns 1404568027739