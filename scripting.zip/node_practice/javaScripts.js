//javaScripts..
//variables to store the data, and to operate on that data
// operation means addition multiplication subtraction division modulus ...

var a,b,sum;

b=2;
var a = 'zohaib';
var sum = a === b;
console.log('sum :' + sum);
//node javascritps/..
// javascripts is a programming language.. 
// offers to write the code for front end hanlidng.  
// fullstack --> full website development .
// forontend(Html, css, javaScripts + React, Angular wordpress) , backend() , middleware apis
console.log((a === b) ? 'type are equals' :'type are not equal');

var a=1;
var b=0;
var result = a||b;
console.log( result );

var string = 'zohaibNasir';
// let complex = {
//     temp : 'zohbib',
//     lastName : 'nasir',
// };

console.log(typeof(string));
var obj = {
    firstName : 'zohaib',
    lastName : 'nasir',
}
console.log(obj.lastName);

const obj = {
  firstName: 'zohaib',
  lastName: 'nasir'
}


for(var a=1 ;a<5 ; a++ ){
   console.log(a); 
}

var i =5;
do{

}while(i<5)

const j =10;
while(i<10 ){

}
// let a ={
//     x:1,
//     y:2,
//     z:3,
// }
// foreach( temp : a){
//     console.log(temp);
// }
// arrays object are used to store the mulitple values



//javaScripts Arrays
var car = ["abc","xyz","temp"];


var person = ["zohaib","nasir"];

//javaScripts Object
// arrays as a objec
var person1 = {
    firstName: "zohaib",
    lastNmae: "nasir",
    age: 22
};
// Array Elements Can Be Objects
// JavaScript variables can be objects. Arrays are special kinds of objects
// Because of this, you can have variables of different types in the same Array
// ou can have objects in an Array. You can have functions in an Array. You can have arrays in an Array:
myArray[0] = Date.now;
myArray[1] = myFunction;
myArray[2] = myCar;
// The real strength of JavaScript arrays are the built-in array properties and methods:
var x = cars.length; // // The length property returns the number of elements\
var y = cars.sort;  // // The sort() method sorts arrays
var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.length;
var first = fruits[0];
var last = fruits[fruits.length - 1]; // accessing the last element in array
var fruits, text, fLen, i;
fruits = ["Banana", "Orange", "Apple", "Mango"];
fLen = fruits.length;

text = "<ul>";
for (i = 0; i < fLen; i++) {
  text += "<li>" + fruits[i] + "</li>";
}
text += "</ul>";
var fruits, text;
fruits = ["Banana", "Orange", "Apple", "Mango"];

text = "<ul>";
fruits.forEach(myFunction);
text += "</ul>";

function myFunction(value) {
  text += "<li>" + value + "</li>";
}

var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.push("Lemon");  

var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits[fruits.length] = "Lemon";    // adds a new element (Lemon) to fruits

var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits[6] = "Lemon";    // adds a new element (Lemon) to fruits



// Many programming languages support arrays with named indexes.

// Arrays with named indexes are called associative arrays (or hashes).

// JavaScript does not support arrays with named indexes.

// In JavaScript, arrays always use numbered indexes.  

var person = [];
person[0] = "John";
person[1] = "Doe";
person[2] = 46;
var x = person.length;     // person.length will return 3
var y = person[0];  
var person = [];
person["firstName"] = "John";
person["lastName"] = "Doe";
person["age"] = 46;
var x = person.length;     // person.length will return 0
var y = person[0];         // person[0] will return undefined

// The Difference Between Arrays and Objects
// In JavaScript, arrays use numbered indexes.  

// In JavaScript, objects use named indexes.

// When to Use Arrays. When to use Objects.
// JavaScript does not support associative arrays.
// You should use objects when you want the element names to be strings (text).
// You should use arrays when you want the element names to be numbers.
var points = new Array();     // Bad
var points = [];              // Good 
var points = new Array(40, 100, 1, 5, 25, 10); // Bad
var points = [40, 100, 1, 5, 25, 10];          // Good

var points = new Array(40, 100);  // Creates an array with two elements (40 and 100)
var points = new Array(40);
Array.isArray(fruits);
var fruits = ["Banana", "Orange", "Apple", "Mango"];

fruits instanceof Array;   // returns true

//functions
function myFunction(p1, p2) {
    return p1 * p2;   // The function returns the product of p1 and p2
  }

//   When an event occurs (when a user clicks a button)
// When it is invoked (called) from JavaScript code
// Automatically (self invoked)

//Function Return
// When JavaScript reaches a return statement, the function will stop executing.

// If the function was invoked from a statement, JavaScript will "return" to execute the code after the invoking statement.

// Functions often compute a return value. The return value is "returned" back to the "caller"

var x = myFunction(4, 3);   // Function is called, return value will end up in x

function myFunction(a, b) {
  return a * b;             // Function returns the product of a and b
}

function toCelsius(fahrenheit) {
    return (5/9) * (fahrenheit-32);
  }
  document.getElementById("demo").innerHTML = toCelsius(77);
  //Functions Used as Variable Values
  var x = toCelsius(77);

  

  //The this Keyword

//   In a function definition, this refers to the "owner" of the function.

// In the example above, this is the person object that "owns" the fullName function.

// In other words, this.firstName means the firstName property of this object.

// Read more about the this keyword at JS this Keyword.
name = person.fullName();
//If you access a method without the () parentheses, it will return the function definition:
name = person.fullName;
//Do Not Declare Strings, Numbers, and Booleans as Objects!
//When a JavaScript variable is declared with the keyword "new", the variable is created as an object:
//


//Strings Methods

var x = new String();        // Declares x as a String object
var y = new Number();        // Declares y as a Number object
var z = new Boolean();       // Declares z as a Boolean object
var txt = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
var sln = txt.length;

var str = "Please locate where 'locate' occurs!";
var pos = str.indexOf("locate");
var pos = str.lastIndexOf("locate");

var pos = str.indexOf("locate", 15);
var pos = str.search("locate");
//The two methods are NOT equal. These are the differences:

// The search() method cannot take a second start position argument.
// The indexOf() method cannot take powerful search values (regular expressions).

// slice(start, end)
// substring(start, end)
// substr(start, length)

var str = "Apple, Banana, Kiwi";
var res = str.slice(7, 13);

var str = "Apple, Banana, Kiwi";
var res = str.slice(-12, -6);

var res = str.slice(7);

// The difference is that substring() cannot accept negative indexes.
var str = "Apple, Banana, Kiwi";
var res = str.substring(7, 13);

//The difference is that the second parameter specifies the length of the extracted part.
var str = "Apple, Banana, Kiwi";
var res = str.substr(7, 6);

//The replace() method replaces a specified value with another value in a string:
//By default, the replace() method is case sensitive. Writing MICROSOFT (with upper-case) will not work:
str = "Please visit Microsoft and Microsoft!";
var n = str.replace("Microsoft", "W3Schools");

//To replace case insensitive, use a regular expression with an /i flag (insensitive):
str = "Please visit Microsoft!";
var n = str.replace(/MICROSOFT/i, "W3Schools");
var text1 = "Hello World!";       // String
var text2 = text1.toUpperCase();
var text2 = text1.toLocaleLowerCase();

//concatinate
var text1 = "Hello";
var text2 = "World";
var text3 = text1.concat(" ", text2);

// /The trim() method removes whitespace from both sides of a string:
var str = "       Hello World!        ";
alert(str.trim());

// The trim() method is not supported in Internet Explorer 8 or lower.

// If you need to support IE 8, you can use replace() with a regular expression instead:

var str = "       Hello World!        ";
alert(str.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, ''));

let str = "5";
str = str.padStart(4,0);
// result is 0005

let str = "5";
str = str.padEnd(4,0);
// result is 5000

//There are 3 methods for extracting string characters:
charAt(position)
charCodeAt(position)
//Property access [ ]

var str = "HELLO WORLD";
str.charAt(0);            // returns H

var str = "HELLO WORLD";

str.charCodeAt(0);         // returns 72

//ECMAScript 5 (2009) allows property access [ ] on strings:

var str = "HELLO WORLD";
str[0];                   // returns H


var txt = "a,b,c,d,e";   // String
txt.split(",");          // Split on commas
txt.split(" ");          // Split on spaces
txt.split("|");          // Split on pipe

//If the separator is omitted, the returned array will contain the whole string in index [0].

var txt = "Hello";       // String
txt.split("");           // Split in characters

//JS NUMBERS

//JavaScript Numbers are Always 64-bit Floating Point

//This format stores numbers in 64 bits, where the number (the fraction) is stored in bits 0 to 51, the exponent in bits 52 to 62, and the sign in bit 63:

var x = 0xFF;

var myNumber = 32;
myNumber.toString(10);  // returns 32
myNumber.toString(32);  // returns 10
myNumber.toString(16);  // returns 20
myNumber.toString(8);   // returns 40
myNumber.toString(2);   // returns 100000


// toFixed() returns a string, with the number written with a specified number of decimals:
var x = 9.656;
x.toFixed(0);           // returns 10
x.toFixed(2);           // returns 9.66
x.toFixed(4);           // returns 9.6560
x.toFixed(6);           // returns 9.656000

//valueOf() returns a number as a number.
var x = 123;
x.valueOf();            // returns 123 from variable x
(123).valueOf();        // returns 123 from literal 123
(100 + 23).valueOf();   // returns 123 from expression 100 + 23

//Number() can be used to convert JavaScript variables to numbers:

Number(true);          // returns 1
Number(false);         // returns 0
Number("10");          // returns 10
Number("  10");        // returns 10
Number("10  ");        // returns 10
Number(" 10  ");       // returns 10
Number("10.33");       // returns 10.33
Number("10,33");       // returns NaN
Number("10 33");       // returns NaN
Number("John");        // returns NaN

//number on date
Number(new Date("2017-09-30"));    // returns 1506729600000


//parseInt() parses a string and returns a whole number. Spaces are allowed. Only the first number is returned

parseInt("10");         // returns 10
parseInt("10.33");      // returns 10
parseInt("10 20 30");   // returns 10
parseInt("10 years");   // returns 10
parseInt("years 10");   // returns NaN 

parseFloat("10");        // returns 10
parseFloat("10.33");     // returns 10.33
parseFloat("10 20 30");  // returns 10
parseFloat("10 years");  // returns 10
parseFloat("years 10");  // returns NaN

//Number Properties

var x = Number.MAX_VALUE;
var x = Number.MIN_VALUE;

var x = Number.POSITIVE_INFINITY;







//Arrays

myArray[0] = Date.now;
myArray[1] = myFunction;
myArray[2] = myCars;

//Real Life Objects, Properties, and Methods
var car = {type:"Fiat", model:"500", color:"white"};
var person = {firstName:"John", lastName:"Doe", age:50, eyeColor:"blue"};
var person = {
  firstName: "John",
  lastName: "Doe",
  age: 50,
  eyeColor: "blue"
};
//You can access object properties in two ways:
person.lastName;
person["lastName"];

var person = {
  firstName: "John",
  lastName : "Doe",
  id       : 5566,
  fullName : function() {
    return this.firstName + " " + this.lastName;
  }
};
var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.pop();
fruits.push("Kiwi");   
var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.shift();            // Removes the first element "Banana" from fruits
var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.unshift("Lemon");    // Adds a new element "Lemon" to fruits
var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits[fruits.length] = "Kiwi"; 
var fruits = ["Banana", "Orange", "Apple", "Mango"];
delete fruits[0];  
var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.splice(2, 0, "Lemon", "Kiwi");
var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.splice(0, 1);        // Removes the first element of fruits
var myGirls = ["Cecilie", "Lone"];
var myBoys = ["Emil", "Tobias", "Linus"];
var myChildren = myGirls.concat(myBoys);   // Concatenates (joins) myGirls and myBoys
var arr1 = ["Cecilie", "Lone"];
var arr2 = ["Emil", "Tobias", "Linus"];
var arr3 = ["Robin", "Morgan"];
var myChildren = arr1.concat(arr2, arr3);   // Concatenates arr1 with arr2 and arr3
var citrus = fruits.slice(3);

var citrus = fruits.slice(1, 3);
var citrus = fruits.slice(2);
fruits.sort();        // First sort the elements of fruits
fruits.reverse();


var x = cars.length;   // The length property returns the number of elements
var y = cars.sort();   // The sort() method sorts arrays

var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.length;   // the length of fruits is 4

fruits = ["Banana", "Orange", "Apple", "Mango"];
var last = fruits[fruits.length - 1]; // accessing the last element

//looping through arrays

var a = ["a", "b", "c"];
a.forEach(function(entry) {
    console.log(entry);
});

var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.push("Lemon");    // adds a new element (Lemon) to fruits

var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits[fruits.length] = "Lemon";    // adds a new element (Lemon) to fruits

var fruits = ["Banana", "Orange", "Apple", "Mango"];

typeof fruits;    // returns object
Array.isArray(fruits);   // returns true

function isArray(x) {
  return x.constructor.toString().indexOf("Array") > -1;
}

//The instanceof operator returns true if an object is created by a given constructor

var fruits = ["Banana", "Orange", "Apple", "Mango"];

fruits instanceof Array;   // returns true

fruits.toString();

fruits.join(" * ");

var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.pop(); 
var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.push("Kiwi");       //  Adds a new element ("Kiwi") to fruits
var fruits = ["Banana", "Orange", "Apple", "Mango"];
var x = fruits.push("Kiwi");   //  the value of x is 5

var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.shift();            // Removes the first element "Banana" from fruits
var fruits = ["Banana", "Orange", "Apple", "Mango"];
var x = fruits.shift();    // the value of x is "Banana"

var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits[0] = "Kiwi";        // Changes the first element of fruits to "Kiwi"

//The length property provides an easy way to append a new element to an array:
var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits[fruits.length] = "Kiwi";          // Appends "Kiwi" to fruits

var fruits = ["Banana", "Orange", "Apple", "Mango"];
delete fruits[0];           // Changes the first element in fruits to undefined
var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.splice(2, 0, "Lemon", "Kiwi");

var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.splice(2, 2, "Lemon", "Kiwi");

var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.splice(0, 1);        // Removes the first element of fruits

var myGirls = ["Cecilie", "Lone"];
var myBoys = ["Emil", "Tobias", "Linus"];
var myChildren = myGirls.concat(myBoys);   // Concatenates (joins) myGirls and myBoys

var arr1 = ["Cecilie", "Lone"];
var arr2 = ["Emil", "Tobias", "Linus"];
var arr3 = ["Robin", "Morgan"];
var myChildren = arr1.concat(arr2, arr3);   // Concatenates arr1 with arr2 and arr3

var arr1 = ["Emil", "Tobias", "Linus"];
var myChildren = arr1.concat("Peter");

var fruits = ["Banana", "Orange", "Lemon", "Apple", "Mango"];
var citrus = fruits.slice(1);

var fruits = ["Banana", "Orange", "Lemon", "Apple", "Mango"];
var citrus = fruits.slice(1, 3);


var fruits = ["Banana", "Orange", "Lemon", "Apple", "Mango"];
var citrus = fruits.slice(2);

//SORT ARRAYS
var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.sort();        // Sorts the elements of fruits
fruits.reverse();     // Then reverse the order of the elements

//By default, the sort() function sorts values as strings.

var points = [40, 100, 1, 5, 25, 10];
points.sort(function(a, b){return a - b});

var points = [40, 100, 1, 5, 25, 10];
points.sort(function(a, b){return b - a});

//FISHER YATES

var points = [40, 100, 1, 5, 25, 10];

for (i = points.length -1; i > 0; i--) {
  j = Math.floor(Math.random() * i)
  k = points[i]
  points[i] = points[j]
  points[j] = k
}

var points = [40, 100, 1, 5, 25, 10];
points.sort(function(a, b){return a - b});
// now points[0] contains the lowest value
// and points[points.length-1] contains the highest value

//TO FIND the highes number in array

function myArrayMax(arr) {
  return Math.max.apply(null, arr);
  return Math.min.apply(null, arr);
}

var cars = [
  {type:"Volvo", year:2016},
  {type:"Saab", year:2001},
  {type:"BMW", year:2010}
];
cars.sort(function(a, b){return a.year - b.year});
cars.sort(function(a, b){
  var x = a.type.toLowerCase();
  var y = b.type.toLowerCase();
  if (x < y) {return -1;}
  if (x > y) {return 1;}
  return 0;
});

cars.sort(function(a, b){
  var x = a.type.toLowerCase();
  var y = b.type.toLowerCase();
  if (x < y) {return -1;}
  if (x > y) {return 1;}
  return 0;
});

//The every() method check if all array values pass a test.

var numbers = [45, 4, 9, 16, 25];
var allOver18 = numbers.every(myFunction);

function myFunction(value, index, array) {
  return value > 18;
}

//The some() method check if some array values pass a test.

var numbers = [45, 4, 9, 16, 25];
var someOver18 = numbers.some(myFunction);

function myFunction(value, index, array) {
  return value > 18;
}
//The indexOf() method searches an array for an element value and returns its position

var fruits = ["Apple", "Orange", "Apple", "Mango"];
var a = fruits.indexOf("Apple");
//array.indexOf(item, start)

//if the item is present more than once, it returns the position of the first occurrence

var fruits = ["Apple", "Orange", "Apple", "Mango"];
var a = fruits.lastIndexOf("Apple");

//The find() method returns the value of the first array element that passes a test function


var numbers = [4, 9, 16, 25, 29];
var first = numbers.find(myFunction);

function myFunction(value, index, array) {
  return value > 18;
}

//The findIndex() method returns the index of the first array element that passes a test function.
var numbers = [4, 9, 16, 25, 29];
var first = numbers.findIndex(myFunction);

function myFunction(value, index, array) {
  return value > 18;
}

// The reduce() method runs a function on each array element to produce (reduce it to) a single value.

// The reduce() method works from left-to-right in the array. See also reduceRight().

var numbers1 = [45, 4, 9, 16, 25];
var sum = numbers1.reduce(myFunction);

function myFunction(total, value, index, array) {
  return total + value;
}

// Note that the function takes 4 arguments:

// The total (the initial value / previously returned value)
// The item value
// The item index
// The array itself

//JavaScript Date Objects

new Date()
new Date(year, month, day, hours, minutes, seconds, milliseconds)
new Date(milliseconds)
new Date(date string)
var d = new Date();
var d = new Date();
document.getElementById("demo").innerHTML = d.toUTCString();
var d = new Date();
document.getElementById("demo").innerHTML = d.toDateString();

var msec = Date.parse("March 21, 2012");
var d = new Date(msec);
document.getElementById("demo").innerHTML = d;

var dateInMilli = Date.now(); //dateNow/1000;
var dateInMilli2 = new Date()/1000;

console.log(dateInMilli+ " "+ dateInMilli2);

console.log(new Date(dateInMilli2 * 1000).getFullYear());


//math
Math.round(4.9);    // returns 51

console.log(Math.PI);
console.log(Math.E);

Math.ceil(4.9);     // returns 5  //Math.ceil(x) returns the value of x rounded up to its nearest integer:

//Math.floor(x) returns the value of x rounded down to its nearest integer:

Math.floor(4.9);    // returns 4

Math.trunc(4.9);    // returns 4

//Math.sign(x) returns if x is negative, null or positive:

Math.sign(-4);    // returns -1
Math.sign(0);    // returns 0
Math.sign(4);    // returns 1

//Math.pow(x, y) returns the value of x to the power of y:
Math.pow(8, 2);      // returns 64
//Math.sqrt(x) returns the square root of x:

Math.sqrt(64);      // returns 8

//Math.abs(x) returns the absolute (positive) value of x:
Math.abs(-4.7);     // returns 4.7

//Math.sin(x) returns the sine (a value between -1 and 1) of the angle x (given in radians).
Math.sin(90 * Math.PI / 180);     // returns 1 (the sine of 90 degrees)
Math.min(0, 150, 30, 20, -8, -200);  // returns -200
Math.max(0, 150, 30, 20, -8, -200);  // returns 150

Math.random();     // returns a random number
Math.log(1);    // returns 0
Math.log(10);    // returns 2.302585092994046
Math.log2(8);    // returns 3
Math.log10(1000);    // returns 3

Math.random();              // returns a random number

Math.floor(Math.random() * 11);      // returns a random integer from 0 to 10
Math.floor(Math.random() * 10);     // returns a random integer from 0 to 9
Math.floor(Math.random() * 100);     // returns a random integer from 0 to 99
Math.floor(Math.random() * 101);     // returns a random integer from 0 to 100
Math.floor(Math.random() * 10) + 1;  // returns a random integer from 1 to 10
Math.floor(Math.random() * 100) + 1; // returns a random integer from 1 to 100
function getRndInteger(min, max) {
  return Math.floor(Math.random() * (max - min) ) + min;
}

function getRndInteger(min, max) {
  return Math.floor(Math.random() * (max - min + 1) ) + min;
}

//BOOLEAN
//Everything With a "Value" is True
//Everything Without a "Value" is False
//The Boolean value of -0 (minus zero) is false:
//The Boolean value of "" (empty string) is false:
//The Boolean value of undefined is false:
//The Boolean value of null is false:

//conditionsa

switch (new Date().getDay()) {
  case 0:
    day = "Sunday";
    break;
  case 1:
    day = "Monday";
    break;
  case 2:
     day = "Tuesday";
    break;
  case 3:
    day = "Wednesday";
    break;
  case 4:
    day = "Thursday";
    break;
  case 5:
    day = "Friday";
    break;
  case 6:
    day = "Saturday";
}


//LOOPS 

// for - loops through a block of code a number of times
// for/in - loops through the properties of an object
// for/of - loops through the values of an iterable object
// while - loops through a block of code while a specified condition is true
// do/while - also loops through a block of code while a specified condition is true

for (i = 0; i < 5; i++) {
  text += "The number is " + i + "<br>";
}

for (key in object) {
  // code block to be executed
}

var person = {fname:"John", lname:"Doe", age:25};

var text = "";
var x;
for (x in person) {
  text += person[x];
}

//The JavaScript for/in statement can also loop over the properties of an Array:
for (variable in array) {
  code
}

var numbers = [45, 4, 9, 16, 25];

var txt = "";
var x;
for (x in numbers) {
  txt += numbers[x] + "<br>";
}
document.getElementById("demo").innerHTML = txt;

//The JavaScript for/of statement loops through the values of an iterable object.
for (variable of iterable) {
  // code block to be executed
}
let cars = ["BMW", "Volvo", "Mini"];
let text = "";

for (let x of cars) {
  text += x + "<br>";
}

let language = "JavaScript";
let text = "";

for (let x of language) {
text += x + "<br>";
}


var str = '["YES","NO"]';
var array = str.split(',');
console.log(array)




