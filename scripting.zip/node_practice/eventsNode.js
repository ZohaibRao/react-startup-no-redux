var event = require("events");
var eventEmitter = new event.EventEmitter();

//create event handler
var myEventHandler = ()=>{
    console.log("i Hear a Scream");
}
var logger = ()=>{
    console.log("connection is successfull");
}
//rigister evetnt
eventEmitter.on("Scream",myEventHandler);
eventEmitter.on("connection",logger);
eventEmitter.on("connection",logger);
eventEmitter.on("connection",logger);
eventEmitter.addListener("connection",logger);
//fire an events
eventEmitter.emit("Scream");
var countListners = require("events").EventEmitter.listenerCount(eventEmitter,"connection");
console.log(countListners);




