// this is detail explanation of Events and linsterns
// following is the example of connection events and its listerns
// tutorials point example on --> to bind a handler function with event
// emit --> means to fire that event
// whenever new listner is added --> newListener event is fired and when listner is removed
// removedListner event is fired 
// following is example is for connection of clients

//For creating a new event
//var event=require('events');
//var eventEmitter=new event.EventEmitter();
//For assigning any function to events. So, when this event is fired, the function gets executed.
//eventEmitter.on(‘eventName’,functionName);
//For firing the events.
//eventEmitter.emit(‘eventName’);

var events = require("events");
var eventEmitter = new events.EventEmitter();

// 1st lisnter/ handler for Event
// eventlistener / handler is 1
var listener1 = function listener1( ){
    console.log("listner1 is executed");
}
// eventlistener / handler is 2
var listener2 = function listener2(){
    console.log("listerner2 is executed")
}

// 2nd event Handler/listner binding with events
// bind Connection Event with listeners

eventEmitter.addListener("connection",listener1);
eventEmitter.addListener("connection",listener2);
 
var countListeners = require("events").EventEmitter.listenerCount(eventEmitter,"connection");
console.log("total lisnters" + countListeners);

// 3rd  fire event

eventEmitter.emit("connection");

// remove the binding of lister1
eventEmitter.removeListener("connection",listener1);
console.log("lisntern1 will not listen now");

// fire the connection 
eventEmitter.emit("connection");

// detail how many listener is listening upon firing the event

var countListeners = require("events").EventEmitter.listenerCount(eventEmitter,"connection");
console.log("total lisnters" + countListeners);
console.log("Program ended");