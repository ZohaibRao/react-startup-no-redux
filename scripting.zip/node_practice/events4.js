//event4 and 2.6 example form Learning node 
// var event = require('events');
// const em = new event.EventEmitter();

var eventEmitter  = require('events').EventEmitter;
const em = new eventEmitter();
 var counter = 0;
 var  min =0;
 var hr = 0.0;
// setInterval( ()=>{ em.emit('timed', counter++); },  3000);

// em.on('timed', (data)=>{
//     console.log(' '+ data);
// })

setInterval(()=>{em.emit('timed', counter++);},100);

em.on('timed',(data)=>{
    
   console.log(' ' + data);
    // if(data == 60){
    //     counter = 0;
    //     min++;
    //     hr+= 0.1;
    // }
    // console.log( ' ' + hr + ' '+min +' '+ data +'sec ');
})
