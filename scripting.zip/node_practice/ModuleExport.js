// this module is to explain exporting module
exports.myDateTime = function(){
    return Date();
}

// var myDateTime = function(){
// return Date();
// }
// exports.myDateTime;

exports.abc = ()=>{
return console.log("this is second call from another module");
}