// 1. import required module
var http = require("http");
// 2.  create server
http.createServer(function (request , response){
    //sent the HTTP header
    // HTTP status : 200 OK
    // Content Type: text/plain
    response.writeHead(200, {'Content-Type' :'text/plain'});

    // send the response as Hello World
    response.end("hello world from Node Server \n");
}).listen(8081);

//console will print the message
console.log('Server running at 127.0.0.1:8081');