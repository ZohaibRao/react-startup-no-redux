
buf = Buffer.alloc(5);
buf.write("Hello");
