var events = require("events");
var counter = 0;
var em = new events.EventEmitter();

setInterval(()=>{em.emit('timed', counter++)},5000);
//firing the emits
em.on('timed', (data)=>{
    console.log('timed' + data);
});
// above mentioned exampel shows that every time event is registered and a counter will be incremented and it
// will be displyed when fired and processed it