const { map } = require("lodash");

let map1 = new Map();

const obj = {
    "firstName":"zohaib",
    "lastName":"nasir",
}

map1.set('1', obj);

for( let elem of map1.keys()){
    console.log(elem)
}