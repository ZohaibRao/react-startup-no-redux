const express = require('express');
//const uuid = require('uuid'); //randomaly id making from 3rd party library npm i uuid
//const router = express.Router(); // router for exporting all following routes
//const client = require('../middleware/connectMongo')
//db connections

const { MongoClient } = require('mongodb');
let client;


async function connectdb() {
    const uri = 'mongodb+srv://zohaib:zohaib.0007@cluster0.d2csz.mongodb.net/mim_v2?retryWrites=true&w=majority';
    client = new MongoClient(uri);
    try {
        // Connect to the MongoDB cluster
        await client.connect();
        console.log('connected with db')
        //await  listDatabases(client);
        // Make the appropriate DB calls
    } catch (e) {
        console.error(e);
    } finally {
        await client.close();
    }
}
connectdb().catch(console.error);

async function listDatabases() {
    try {
        databasesList = await client.db().admin().listDatabases();
        console.log("Databases:");
        databasesList.databases.forEach(db => console.log(` - ${db.name}`));

    } catch (err) {
        console.log('facing this error:', err)
    }
}

module.exports = {
    getUser,
    listDatabases
};